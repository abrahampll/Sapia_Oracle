package pe.com.claro.eai.ejecutatransferenciacontrato.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PropertiesExterno {
	
    @Value("${ws.envioemail.url}")
    public String wsUrlENVIOEMAIL;
    @Value("${ws.ejecutartransferenciacontrato.url}")
    public String wsUrlEJECUTARTRANSFERENCIACONTRATO;
    @Value("${db.timeai.timeout.connection.max.time}")
    public Integer dbTimeaiTimeoutCONNECTION;
    @Value("${db.timeai.jndi}")
    public String dbTimeaiJNDI;
    @Value("${db.timeai.owner}")
    public String dbTimeaiOWNER;
    @Value("${pkg.timeai.programacion.serv}")
    public String dbTIMEAIPKGPPPROGRAMACIONSERV;
    @Value("${sp.timeai.buscarprogramacion}")
    public String spTIMEAISPBUSCARPROGRAMACIONES;
    @Value("${sp.timeai.buscardetserviciomasivo}")
    public String spTIMEAISPBUSCARDETSERVICIOMASIVO;    

    @Value("${sp.timeai.actdetserviciomasivo}")
    public String spTIMEAISPACTUALIZARDETSERVICIOMASIVO;    
    @Value("${db.timeai.timeout.execution.max.time}")
    public Integer dbTimeaiTimeoutEXECUTION;
    
    @Value("${db.clarify.jndi}")
    public String dbClarifyJNDI;
    @Value("${db.clarify.owner}")
    public String dbClarifyOWNER;
    @Value("${db.clarify.timeout.connection.max.time}")
    public Integer dbClarifyTimeOutCONNECTION;
    @Value("${db.clarify.timeout.execution.max.time}")
    public Integer dbClarifyTimeOutEXECUTION;
    @Value("${pkg.clarify.pckinteractclfy}")
    public String pkgCLARIFYPCKINTERACTCLFY;
    @Value("${sp.clarify.spcreateinteract}")
    public String spCLARIFYSPCREATEINTERACT;
    @Value("${sp.clarify.spcreateplusinter}")
    public String spCLARIFYSPCREATEPLUSINTER;
    @Value("${pkg.clarify.customer}")
    public String pkgCLARIFYCUSTOMER;
    @Value("${sp.clarify.customer}")
    public String spCLARIFYSPCUSTOMER;
    
    @Value("${unionseparacionrecibos.servicod}")
    public String serviCOD;
    @Value("${interaccion.resultado.ninguno}")
    public String interaccionResultadoNinguno;
    @Value("${buscarprogramacion.limite}")
    public int limiteBuscarProgramacion;
    
    @Value("${estado.inicio.programacion}")
    public String estadoInicioProgramacion;
    
    @Value("${codigo.estandar.exito}")
    public String codigoEstandarExito;
    @Value("${mensaje.estandar.exito}")
    public String mensajeEstandarExito;
    @Value("${codigo.estandar.error}")
    public String codigoEstandarError;
    
    @Value("${procprog.codigo.respuesta.idf0}")
    public String procProgCodigoRESPUESTAIDF0;
    @Value("${procprog.mensaje.respuesta.idf0}")
    public String procProgMensajeRESPUESTAIDF0;
    
    @Value("${procprog.codigo.respuesta.idf1}")
    public String procProgCodigoRESPUESTAIDF1;
    @Value("${procprog.mensaje.respuesta.idf1}")
    public String procProgMensajeRESPUESTAIDF1;
    
    @Value("${realtran.codigo.respuesta.idf2}")
    public String realTranCodigoRESPUESTAIDF2;
    
    @Value("${procprog.codigo.respuesta.idt1}")
    public String procProgCodigoRESPUESTAIDT1;
    @Value("${procprog.mensaje.respuesta.idt1}")
    public String procProgMensajeRESPUESTAIDT1;
    
    @Value("${relaprog.codigo.respuesta.idf0}")
    public String relaProgCodigoRESPUESTAIDF0;
    @Value("${relaprog.mensaje.respuesta.idf0}")
    public String relaProgMensajeRESPUESTAIDF0;
    @Value("${relaprog.codigo.respuesta.idf1}")
    public String relaProgCodigoRESPUESTAIDF1;
    @Value("${relaprog.mensaje.respuesta.idf1}")
    public String relaProgMensajeRESPUESTAIDF1;
    
    @Value("${pkg.timeai.migracionplanpost}")
    public String dbTIMEAIPKGMIGRACIONPLANPOST;
    @Value("${sp.timeai.regmigracion}")
    public String spTIMEAISPREGISTRAMIGRACION;
    @Value("${pkg.timeai.serv.masivo}")
    public String dbTIMEAIPKGSERVMASIVO;
    @Value("${sp.timeai.buscreproceso}")
    public String spTIMEAISPBUSCARREPROCESO;
    @Value("${sp.timeai.regestadomigracion}")
    public String spTIMEAISPREGESTMIGRACION;
    @Value("${sp.timeai.trans.masiva}")
    public String spTIMEAISPTRANSMASIVA;
    @Value("${sp.timeai.actualiza.programacion}")
    public String spTIMEAISPACTUALIZAPROGRAMACION;
    @Value("${sp.timeai.actestadomigracion}")
    public String spTIMEAISPACTESTADOMIGRACION;
    
    @Value("${envioemail.remitente}")
    public String envioEmailRemitente;
    @Value("${envioemail.destinatario}")
    public String envioEmailDestinatario;
    @Value("${envioemail.asunto}")
    public String envioEmailAsunto;
    @Value("${envioemail.mensaje.exito}")
    public String envioEmailMensajeEXITO;
    @Value("${envioemail.mensaje.error}")
    public String envioEmailMensajeERROR;
    @Value("${envioemail.flagHTML}")
    public String envioEmailFlagHTML;
    
    @Value("${estado.trans.masiva.exito}")
    public String EstadoTransMasivaExito;
    @Value("${estado.trans.masiva.error}")
    public String EstadoTransMasivaError;
    @Value("${estado.trans.masiva.proceso}")
    public String EstadoTransMasivaProceso;
    
    @Value("${realtran.fase0}")
    public String realTranFASE0;
    @Value("${codigo.error.registro.programacion}")
    public String estadoRegistroProgramacionError;
    @Value("${procprog.codigo.respuesta.idt2}")
    public String procProgCodigoRESPUESTAIDT2;
    @Value("${procprog.mensaje.respuesta.idt2}")
    public String procProgMensajeRESPUESTAIDT2;
    @Value("${realtran.servicod}")
    public String realTranServiCod;
    @Value("${estado.error.programacion}")
    public String codigoEstadoErrorProgramacion;
    @Value("${codigo.error.actualiza.programacion}")
    public String codigoErrorActProgramacion;
    
    @Value("${interaccion.tipo}")
    public String interaccionTipo;
    @Value("${interaccion.metodo.contacto}")
    public String interaccionMetodoContacto;
    @Value("${interaccion.tipo.inter}")
    public String interaccionTipoInter;
    @Value("${interaccion.usr.proceso}")
    public String interaccionUsrProceso;
    @Value("${interaccion.hecho.en.uno}")
    public String interaccionHechoEnUno;
    @Value("${interaccion.flag.existe.sec}")
    public String interaccionFlagExisteSec;
    @Value("${interaccion.flag.no.existe.sec}")
    public String interaccionFlagNoExisteSec;
    @Value("${interaccion.descripcion.union.separacion.normal}")
    public String interaccionDescripcionUnionSeparacionNormal;
    @Value("${interaccion.descripcion.union.separacion.masiva}")
    public String interaccionDescripcionUnionSeparacionMasiva;
    @Value("${interaccion.descripcion.cambio.titularidad.masiva}")
    public String interaccionDescripcionCambioTitularidadMasiva;
    
    @Value("${clarify.customer.flagreg}")
    public String clarifyCustomerFlagReg;
    
    @Value("${realtran.fase1}")
    public String realizarFase1;
    
}
