PROCEDURE ADMPSI_CAMBTIT (K_TIP_CLI       IN VARCHAR2,
                          K_COD_CLIPROD   IN LISTA_CLI_PRODUCTO,
                          K_TIPODOC       IN VARCHAR2,
                          K_NUMDOC        IN VARCHAR2,
                          K_COD_CLIPROD_N IN LISTA_CLI_PRODUCTO,
                          K_TIPODOC_N     IN VARCHAR2,
                          K_NUMDOC_N      IN VARCHAR2,
                          K_NOMCLI        IN VARCHAR2,
                          K_APECLI        IN VARCHAR2,
                          K_SEXO          IN VARCHAR2,
                          K_ESTCIVIL      IN VARCHAR2,
                          K_EMAIL         IN VARCHAR2,
                          K_PROV          IN VARCHAR2,
                          K_DEPAR         IN VARCHAR2,
                          K_DIST          IN VARCHAR2,
                          K_CICLOFACT     IN VARCHAR2,
                          K_USUARIO       IN VARCHAR2,
                          K_CODERROR OUT     NUMBER,
                          K_DESCERROR OUT    VARCHAR2)
IS
        --****************************************************************
        -- Nombre SP           :  ADMPSI_CAMBTIT
        -- Prop�sito           :  Cambio de Titularidad HFC
        -- Input               :  K_COD_CLIPROD   - Lista de Cliente Productos de Cliente Actual - a cambiar Titular del Producto HFC
        --                        K_TIPODOC       - Tipo de Documento del Actual Titular
        --                        K_NUMDOC        - Numero de Documento del Actual Titular
        --                        K_COD_CLIPROD_N   - Lista de Cliente Productos Nuevo Cliente - a cambiar Titular del Producto HFC
        --                        K_TIPODOC_N     - Tipo de Documento del Nuevo Titular
        --                        K_NUMDOC_N      - Numero de Documento del Nuevo Titular
        --                        K_NOMCLI        - Nombres Nuevo Titular
        --                        K_APECLI        - Apellidos Nuevo Titular
        --                        K_SEXO          - Sexo Nuevo Titular
        --                        K_ESTCIVIL      - Estado Civil Nuevo Titular
        --                        K_EMAIL         - Email Nuevo Titular
        --                        K_PROV          - Provincia Residencia Nuevo Titular
        --                        K_DEPAR         - Departamento Residencia Nuevo Titular
        --                        K_DIST          - Distrito Residencia Nuevo Titular
        --                        K_CICLOFACT     - Cliclo de Facturacion Nuevo Titular
        --                        K_USUARIO       - Usuario de la Aplicacion
        -- Output              :  K_CODERROR Codigo de Error o Exito
        --                        K_DESCERROR Descripcion del Error (si se presento)
        -- Creado por          :  Susana Ramos
        -- Fec Creaci�n        :  15/05/2012
        -- Fec Actualizaci�n   :  22/05/2012
        --****************************************************************
        V_CODCLIENTE       VARCHAR2(40);
        V_CODCLIENTE_N     VARCHAR2(40);
        V_IDKARDEX         NUMBER;
        C_PUNTOS           NUMBER;
        V_CODIDCOSALDO     VARCHAR2(40);
        V_IDSALDO          NUMBER;
        V_COD_CPTO         VARCHAR2(2);
        V_ESTADO           VARCHAR2(2);
        V_REGCLIENTE       NUMBER;
        V_REG_CLIPROD      NUMBER;
        V_REGCLIFIJA       NUMBER;
        V_REGCLI           NUMBER;
        V_REGCLIPROD       NUMBER;
        V_REGCLIPROD_N     NUMBER;
        V_REGINDICEGRUPO   NUMBER;
        V_REGINDICEGRUPO_N NUMBER;
        V_CLI_PRODUCTO CLI_PRODUCTO;
        V_CLI_PRODUCTO_N CLI_PRODUCTO;
        V_SALDO_CC   NUMBER;
        V_TIPO_PUNTO CHAR (1);
        VCOD_TPDOC   VARCHAR2(2);
        VCOD_TPDOC_N VARCHAR2(2);
        COD_CLI_PROD PCLUB.ADMPT_CLIENTEPRODUCTO.ADMPV_COD_CLI_PROD%TYPE;
        COD_SERVI PCLUB.ADMPT_CLIENTEPRODUCTO.ADMPV_SERVICIO%TYPE;
        EX_ERROR      EXCEPTION;
        EX_SALDO      EXCEPTION;
        NO_EXISTE     EXCEPTION;
        V_CODERROR    NUMBER;
        V_DESCERROR   VARCHAR2(400);
        V_INDICEGRUPO VARCHAR2(2);
        K_CODERROR_1  NUMBER;
        K_DESCERROR_1 VARCHAR2(400);
        /*CUPONERAVIRTUAL - JCGT INI*/
        C_CODERROR  NUMBER;
        C_DESCERROR VARCHAR2(200);
        /*CUPONERAVIRTUAL - JCGT FIN*/
BEGIN
        K_CODERROR  := 0;
        K_DESCERROR := '';
        -- Solo podemos validar si enviaron datos en codigo de cliente
        IF K_TIP_CLI IS NULL THEN
                K_CODERROR :=4;
                K_DESCERROR:='Ingrese el Tipo de Cliente, es un campo obligatorio';
                RAISE EX_ERROR;
        END IF;
        IF K_TIPODOC IS NULL THEN
                K_CODERROR :=4;
                K_DESCERROR:='Ingrese el campo Tipo de Dcto., es un campo obligatorio';
                RAISE EX_ERROR;
        END IF;
        IF K_NUMDOC IS NULL THEN
                K_CODERROR :=4;
                K_DESCERROR:='Ingrese el campo Nro. de Dcto., es un campo obligatorio';
                RAISE EX_ERROR;
        END IF;
        IF K_COD_CLIPROD IS NULL THEN
                K_CODERROR :=4;
                K_DESCERROR:='Ingrese la Lista de Servicios a Cambiar de Titularidad, es un campo obligatorio';
                RAISE EX_ERROR;
        END IF;
        -------------------
        IF K_TIPODOC_N IS NULL THEN
                K_CODERROR :=4;
                K_DESCERROR:='Ingrese el campo Tipo de Dcto., es un campo obligatorio';
                RAISE EX_ERROR;
        END IF;
        IF K_NUMDOC_N IS NULL THEN
                K_CODERROR :=4;
                K_DESCERROR:='Ingrese el campo Nro. de Dcto., es un campo obligatorio';
                RAISE EX_ERROR;
        END IF;
        IF K_NOMCLI IS NULL
                OR
                K_APECLI IS NULL THEN
                K_CODERROR :=4;
                K_DESCERROR:='Ingrese el campo Nombres/Apellidos del Cliente, es un campo obligatorio';
                RAISE EX_ERROR;
        END IF;
        ------------------ Validaciones del Cliente Actual
        BEGIN
                SELECT
                        ADMPV_COD_TPDOC
                INTO
                        VCOD_TPDOC
                FROM
                        PCLUB.ADMPT_TIPO_DOC
                WHERE
                        ADMPV_EQU_FIJA = K_TIPODOC;
        
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
                K_CODERROR :=4;
                K_DESCERROR:='Ingrese un Tipo de documento v�lido';
                RAISE EX_ERROR;
        END;
        /*  IF VCOD_TPDOC='' OR VCOD_TPDOC IS NULL THEN
        RAISE NO_EXISTE;
        END IF ;*/
        SELECT
                COUNT(ROWID)
        INTO
                V_REGCLIENTE
        FROM
                PCLUB.ADMPT_CLIENTEFIJA CF
        WHERE
                CF.ADMPV_TIPO_DOC  = VCOD_TPDOC
        AND     CF.ADMPV_NUM_DOC   =K_NUMDOC
        AND     CF.ADMPV_COD_TPOCL = K_TIP_CLI;
        
        IF V_REGCLIENTE>0 THEN
                SELECT
                        C.ADMPV_COD_CLI,
                        C.ADMPC_ESTADO
                INTO
                        V_CODCLIENTE,
                        V_ESTADO
                FROM
                        PCLUB.ADMPT_CLIENTEFIJA C
                WHERE
                        C.ADMPV_TIPO_DOC  = VCOD_TPDOC
                AND     C.ADMPV_NUM_DOC   = K_NUMDOC
                AND     C.ADMPV_COD_TPOCL = K_TIP_CLI;
                
                IF V_ESTADO <> 'A' THEN
                        K_CODERROR := 6;
                        RAISE EX_ERROR;
                END IF;
                /***/
                ADMPSS_VLD_CAMTIT(K_TIP_CLI,K_COD_CLIPROD,VCOD_TPDOC,K_NUMDOC,K_CODERROR_1,K_DESCERROR_1);
                IF K_CODERROR_1=1 THEN
                        K_CODERROR := 31;
                        RAISE EX_ERROR;
                END IF;
                /***/
                --Verifica si Todos los Servicios del Cliente Actual esta en Baja
                SELECT
                        COUNT(*)
                INTO
                        V_REGCLIENTE
                FROM
                        PCLUB.ADMPT_CLIENTEPRODUCTO C
                WHERE
                        C.ADMPV_COD_CLI    =V_CODCLIENTE
                AND     C.ADMPV_ESTADO_SERV='A';
                
                IF V_REGCLIENTE=0 THEN
                        -- K_DESCERROR:='El Cliente No tiene Servicios Activos';
                        K_CODERROR := 31;
                        RAISE EX_ERROR;
                END IF;
        ELSE
                K_CODERROR := 6;
                RAISE EX_ERROR;
        END IF;
        BEGIN
                IF K_TIP_CLI='6' THEN
                        SELECT
                                ADMPV_COD_CPTO
                        INTO
                                V_COD_CPTO
                        FROM
                                PCLUB.ADMPT_concepto
                        WHERE
                                admpv_desc='CAMBIO TITULARIDAD DTH';
                
                ELSIF K_TIP_CLI='7' THEN
                        SELECT
                                ADMPV_COD_CPTO
                        INTO
                                V_COD_CPTO
                        FROM
                                PCLUB.ADMPT_concepto
                        WHERE
                                admpv_desc = 'CAMBIO TITULARIDAD HFC';
                
                END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
                V_COD_CPTO :=NULL;
                K_CODERROR := 9;
                RAISE EX_ERROR;
        END;
        /*-------Se Verifica Cuantos si hay otro Grupo(HFC)/Servicio(DTH) Activo Para el Traspaso de puntos---------*/
        IF K_TIP_CLI='6' THEN
                SELECT
                        COUNT(ADMPV_INDICEGRUPO)
                INTO
                        V_REGINDICEGRUPO
                FROM
                        PCLUB.ADMPT_CLIENTEPRODUCTO
                WHERE
                        ADMPV_COD_CLI    = V_CODCLIENTE
                AND     ADMPV_ESTADO_SERV='A';
        
        ELSE
                SELECT
                        COUNT(DISTINCT ADMPV_INDICEGRUPO)
                INTO
                        V_REGINDICEGRUPO
                FROM
                        PCLUB.ADMPT_CLIENTEPRODUCTO
                WHERE
                        ADMPV_COD_CLI    = V_CODCLIENTE
                AND     ADMPV_ESTADO_SERV='A';
        
        END IF;
        -------------Se recupera el Tipo de Doc--------------------------
        BEGIN
                SELECT
                        ADMPV_COD_TPDOC
                INTO
                        VCOD_TPDOC_N
                FROM
                        PCLUB.ADMPT_TIPO_DOC
                WHERE
                        ADMPV_EQU_FIJA = K_TIPODOC_N;
        
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
                K_CODERROR :=4;
                K_DESCERROR:='Ingrese un Tipo de documento v�lido';
                RAISE EX_ERROR;
        END;
        V_CODCLIENTE_N:=VCOD_TPDOC_N
        ||'.'
        ||K_NUMDOC_N
        ||'.'
        ||K_TIP_CLI;
        --V_ULT_CODSER := K_COD_CLIPROD.LAST;
        FOR I IN K_COD_CLIPROD.FIRST .. K_COD_CLIPROD.LAST
        LOOP
                V_REGCLI     :=0;
                V_REGCLIPROD :=0;
                --V_SALDO_CLI := 0;
                C_PUNTOS       :=0;
                V_SALDO_CC     := 0.00;
                V_CLI_PRODUCTO := K_COD_CLIPROD(I);
                IF K_TIP_CLI='7' THEN
                        SELECT
                                SUBSTR(V_CLI_PRODUCTO.COD_CLI_PROD,LENGTH(V_CLI_PRODUCTO.COD_CLI_PROD),1)
                        INTO
                                V_INDICEGRUPO
                        FROM
                                DUAL;
                
                ELSE
                        V_INDICEGRUPO :=1;
                END IF;
                SELECT
                        COUNT(ROWID)
                INTO
                        V_REGCLI
                FROM
                        PCLUB.ADMPT_CLIENTEPRODUCTO B
                WHERE
                        B.ADMPV_COD_CLI_PROD = V_CLI_PRODUCTO.COD_CLI_PROD
                AND     B.ADMPV_ESTADO_SERV  ='A';
                
                IF V_REGCLI>0 THEN
                        BEGIN
                                SELECT
                                        NVL(S.ADMPN_SALDO_CC,NULL)
                                INTO
                                        V_SALDO_CC
                                FROM
                                        PCLUB.ADMPT_SALDOS_CLIENTEFIJA S
                                WHERE
                                        S.ADMPV_COD_CLI_PROD = V_CLI_PRODUCTO.COD_CLI_PROD;
                        
                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                                V_SALDO_CC := 0.00;
                        END;
                        -- Insertamos en el Kardex el movimiento s�lo si el saldo es mayor que 0, Para la Salida de Puntos por Cambio de Titularidad
                        IF V_SALDO_CC > 0 THEN
                                V_TIPO_PUNTO := 'S';
                                /* genera secuencial de kardex*/
                                SELECT
                                        PCLUB.ADMPT_KARDEXFIJA_SQ.NEXTVAL
                                INTO
                                        V_IDKARDEX
                                FROM
                                        DUAL;
                                
                                INSERT INTO
                                        PCLUB.ADMPT_KARDEXFIJA
                                        (
                                                ADMPN_ID_KARDEX   ,
                                                ADMPN_COD_CLI_IB  ,
                                                ADMPV_COD_CLI_PROD,
                                                ADMPV_COD_CPTO    ,
                                                ADMPD_FEC_TRANS   ,
                                                ADMPN_PUNTOS      ,
                                                ADMPC_TPO_OPER    ,
                                                ADMPC_TPO_PUNTO   ,
                                                ADMPN_SLD_PUNTO   ,
                                                ADMPC_ESTADO      ,
                                                ADMPV_USU_REG
                                        )
                                        VALUES
                                        (
                                                V_IDKARDEX                 ,
                                                NULL                       ,
                                                V_CLI_PRODUCTO.COD_CLI_PROD,
                                                V_COD_CPTO                 ,
                                                SYSDATE                    ,
                                                V_SALDO_CC * -1            ,
                                                V_TIPO_PUNTO               ,
                                                'C'                        ,
                                                C_PUNTOS                   ,
                                                'A'                        ,
                                                K_USUARIO
                                        );
                        
                        END IF;
                        -- ACTUALIZAMOS EL SALDO DE LOS MOVIMIENTOS DE ENTRADA DEL KARDEX A 0 SEGUN CODIGO DEL CLIENTE SOLO SI ES MAYOR A 0
                        UPDATE
                                PCLUB.ADMPT_KARDEXFIJA
                        SET
                                ADMPN_SLD_PUNTO = C_PUNTOS ,
                                ADMPV_USU_MOD   = K_USUARIO
                        WHERE
                                ADMPV_COD_CLI_PROD = V_CLI_PRODUCTO.COD_CLI_PROD
                        AND     ADMPC_TPO_PUNTO IN ('C',
                                                    'L')
                        AND     ADMPN_SLD_PUNTO > 0
                        AND     ADMPC_TPO_OPER  = 'E';
                        
                        -- ACTUALIZAR EL SALDO CC DE LA TABLA SEGUN EL CODIGO DEL CLIENTE PROD (CLIENTE ANTERIOR)
                        UPDATE
                                PCLUB.ADMPT_SALDOS_CLIENTEFIJA S
                        SET
                                S.ADMPN_SALDO_CC = C_PUNTOS ,
                                S.ADMPV_USU_MOD  = K_USUARIO,
                                S.ADMPC_ESTPTO_CC='B'
                        WHERE
                                ADMPV_COD_CLI_PROD = V_CLI_PRODUCTO.COD_CLI_PROD;
                        
                        -- Servicio que se cambia de titularidad
                        /*---Se Verfica que haya mas productos de este mismo servicio---*/
                        SELECT
                                COUNT(*)
                        INTO
                                V_REG_CLIPROD
                        FROM
                                PCLUB.ADMPT_CLIENTEPRODUCTO
                        WHERE
                                ADMPV_COD_CLI    = V_CODCLIENTE
                        AND     ADMPV_ESTADO_SERV='A'
                        AND     ADMPV_SERVICIO   =V_CLI_PRODUCTO.DESC_PRODUCTO;
                        
                        /*-------Si Hay otro Grupo Activo Para el Traspaso de puntos---------*/
                        IF V_REGINDICEGRUPO=1 THEN
                                --Se actualiza el campo ADMPV_ESTADO_SERV  a (B) Baja  de la tabla PCLUB.ADMPT_CLIENTEPRODUCTO
                                UPDATE
                                        PCLUB.ADMPT_CLIENTEPRODUCTO CP
                                SET
                                        CP.ADMPV_ESTADO_SERV='B',
                                        CP.ADMPV_USU_MOD    =K_USUARIO
                                WHERE
                                        ADMPV_COD_CLI      = V_CODCLIENTE
                                AND     ADMPV_COD_CLI_PROD = V_CLI_PRODUCTO.COD_CLI_PROD;
                        
                        ELSIF V_REGINDICEGRUPO>1 THEN
                                UPDATE
                                        PCLUB.ADMPT_CLIENTEPRODUCTO CP
                                SET
                                        CP.ADMPV_ESTADO_SERV='B',
                                        CP.ADMPV_USU_MOD    =K_USUARIO
                                WHERE
                                        ADMPV_COD_CLI      = V_CODCLIENTE
                                AND     ADMPV_COD_CLI_PROD = V_CLI_PRODUCTO.COD_CLI_PROD;
                                
                                IF V_SALDO_CC           > 0 THEN
                                        IF V_REG_CLIPROD>1 THEN
                                                /*--Se ordena por Prioridad, para saber a quien pasa el saldo, En caso el Cliente HFC Tiene + de un Producto, pasara al + Antiguo --*/
                                                BEGIN
                                                        SELECT
                                                                CLIPROD,
                                                                SERVICIO
                                                        INTO
                                                                COD_CLI_PROD,
                                                                COD_SERVI
                                                        FROM
                                                                (
                                                                        SELECT
                                                                                A.ADMPV_COD_CLI_PROD CLIPROD,
                                                                                A.ADMPV_SERVICIO     SERVICIO
                                                                                --INTO COD_CLI_PROD, COD_SERVI
                                                                        FROM
                                                                                PCLUB.ADMPT_CLIENTEPRODUCTO A
                                                                        INNER JOIN
                                                                                PCLUB.ADMPT_CLIENTEFIJA B
                                                                        ON
                                                                                (
                                                                                        A.ADMPV_COD_CLI=B.ADMPV_COD_CLI)
                                                                        INNER JOIN
                                                                                PCLUB.ADMPT_TIPOSERV_DTH_HFC D
                                                                        ON
                                                                                (
                                                                                        B.ADMPV_COD_TPOCL=D.ADMPV_COD_TPOCL
                                                                                AND     D.ADMPV_SERVICIO =A.ADMPV_SERVICIO)
                                                                        WHERE
                                                                                B.ADMPV_COD_CLI    = V_CODCLIENTE
                                                                        AND     B.ADMPC_ESTADO     = 'A'
                                                                        AND     B.ADMPV_COD_TPOCL  S'A'
                                                                                /*AND ROWNUM=1 */
                                                                        AND     A.ADMPV_SERVICIO = V_CLI_PRODUCTO.DESC_PRODUCTO
                                                                        ORDER BY
                                                                                D.ADMPN_PRIORIDAD,
                                                                                A.ADMPD_FEC_REG  ,
                                                                                A.ADMPV_COD_CLI_PROD ASC)
                                                        WHERE
                                                                ROWNUM=1;
                                                        
                                                        IF V_SALDO_CC > 0 THEN
                                                                V_TIPO_PUNTO := 'E';
                                                                /* genera secuencial de kardex*/
                                                                SELECT
                                                                        PCLUB.ADMPT_KARDEXFIJA_SQ.NEXTVAL
                                                                INTO
                                                                        V_IDKARDEX
                                                                FROM
                                                                        DUAL;
                                                                
                                                                /*----Se le Pasa los ptos , en caso tenga mas de un producto(DTH/HFC)------*/
                                                                INSERT INTO
                                                                        PCLUB.ADMPT_KARDEXFIJA
                                                                        (
                                                                                ADMPN_ID_KARDEX   ,
                                                                                ADMPN_COD_CLI_IB  ,
                                                                                ADMPV_COD_CLI_PROD,
                                                                                ADMPV_COD_CPTO    ,
                                                                                ADMPD_FEC_TRANS   ,
                                                                                ADMPN_PUNTOS      ,
                                                                                ADMPC_TPO_OPER    ,
                                                                                ADMPC_TPO_PUNTO   ,
                                                                                ADMPN_SLD_PUNTO   ,
                                                                                ADMPC_ESTADO      ,
                                                                                ADMPV_USU_REG
                                                                        )
                                                                        VALUES
                                                                        (
                                                                                V_IDKARDEX  ,
                                                                                NULL        ,
                                                                                COD_CLI_PROD,
                                                                                V_COD_CPTO  ,
                                                                                SYSDATE     ,
                                                                                V_SALDO_CC  ,
                                                                                V_TIPO_PUNTO,
                                                                                'C'         ,
                                                                                V_SALDO_CC  ,
                                                                                'A'         ,
                                                                                K_USUARIO
                                                                        );
                                                                
                                                                UPDATE
                                                                        PCLUB.ADMPT_SALDOS_CLIENTEFIJA S
                                                                SET
                                                                        S.ADMPN_SALDO_CC = S.ADMPN_SALDO_CC + V_SALDO_CC ,
                                                                        ADMPV_USU_MOD    = K_USUARIO
                                                                WHERE
                                                                        ADMPV_COD_CLI_PROD = COD_CLI_PROD;
                                                        
                                                        END IF;
                                                END;
                                        ELSE
                                                BEGIN
                                                        SELECT
                                                                COD_CLI
                                                        INTO
                                                                COD_CLI_PROD
                                                        FROM
                                                                (
                                                                        SELECT
                                                                                P.ADMPV_COD_CLI_PROD COD_CLI
                                                                        FROM
                                                                                PCLUB.ADMPT_CLIENTEFIJA      F,
                                                                                PCLUB.ADMPT_CLIENTEPRODUCTO  P,
                                                                                PCLUB.ADMPT_TIPOSERV_DTH_HFC T
                                                                        WHERE
                                                                                F.ADMPV_COD_CLI       = V_CODCLIENTE
                                                                        AND     F.ADMPV_COD_CLI       = P.ADMPV_COD_CLI
                                                                        AND     P.ADMPV_COD_CLI_PROD <> V_CLI_PRODUCTO.COD_CLI_PROD
                                                                        AND     P.ADMPV_SERVICIO     <> V_CLI_PRODUCTO.DESC_PRODUCTO
                                                                        AND     P.ADMPV_INDICEGRUPO  <> V_INDICEGRUPO
                                                                        AND     F.ADMPV_COD_TPOCL     = K_TIP_CLI
                                                                        AND     F.ADMPC_ESTADO        = 'A'
                                                                        AND     P.ADMPV_ESTADO_SERV   = 'A'
                                                                        AND     P.ADMPV_SERVICIO      = T.ADMPV_SERVICIO
                                                                        ORDER BY
                                                                                T.ADMPN_PRIORIDAD )
                                                        WHERE
                                                                ROWNUM=1;
                                                        
                                                        IF V_SALDO_CC > 0 THEN
                                                                V_TIPO_PUNTO := 'E';
                                                                /* genera secuencial de kardex*/
                                                                SELECT
                                                                        PCLUB.ADMPT_KARDEXFIJA_SQ.NEXTVAL
                                                                INTO
                                                                        V_IDKARDEX
                                                                FROM
                                                                        DUAL;
                                                                
                                                                /*----Se le Pasa los ptos , en caso tenga mas de un producto(DTH/HFC)------*/
                                                                INSERT INTO
                                                                        PCLUB.ADMPT_KARDEXFIJA
                                                                        (
                                                                                ADMPN_ID_KARDEX   ,
                                                                                ADMPN_COD_CLI_IB  ,
                                                                                ADMPV_COD_CLI_PROD,
                                                                                ADMPV_COD_CPTO    ,
                                                                                ADMPD_FEC_TRANS   ,
                                                                                ADMPN_PUNTOS      ,
                                                                                ADMPC_TPO_OPER    ,
                                                                                ADMPC_TPO_PUNTO   ,
                                                                                ADMPN_SLD_PUNTO   ,
                                                                                ADMPC_ESTADO      ,
                                                                                ADMPV_USU_REG
                                                                        )
                                                                        VALUES
                                                                        (
                                                                                V_IDKARDEX  ,
                                                                                NULL        ,
                                                                                COD_CLI_PROD,
                                                                                V_COD_CPTO  ,
                                                                                SYSDATE     ,
                                                                                V_SALDO_CC  ,
                                                                                V_TIPO_PUNTO,
                                                                                'C'         ,
                                                                                V_SALDO_CC  ,
                                                                                'A'         ,
                                                                                K_USUARIO
                                                                        );
                                                                
                                                                UPDATE
                                                                        PCLUB.ADMPT_SALDOS_CLIENTEFIJA S
                                                                SET
                                                                        S.ADMPN_SALDO_CC = S.ADMPN_SALDO_CC + V_SALDO_CC ,
                                                                        ADMPV_USU_MOD    = K_USUARIO
                                                                WHERE
                                                                        ADMPV_COD_CLI_PROD = COD_CLI_PROD;
                                                        
                                                        END IF;
                                                END;
                                        END IF;
                                END IF;
                        END IF;
                        --Validar si el cliente existe EN TABLA PCLUB.ADMPT_CLIENTEFIJA
                        SELECT
                                COUNT(*)
                        INTO
                                V_REGCLIFIJA
                        FROM
                                PCLUB.ADMPT_CLIENTEFIJA C
                        WHERE
                                C.ADMPV_COD_CLI = V_CODCLIENTE_N
                        AND     C.ADMPC_ESTADO  = 'A';
                        
                        ---VALIDACION DE CLIENTE EXISTE O NO  EN CC, Y ADEMAS EL ESTADO ACTIVO O BAJA
                        IF V_REGCLIFIJA=0 THEN
                                -- Debemos insertar los clientes en la tabla de Clientes
                                INSERT INTO
                                        PCLUB.ADMPT_CLIENTEFIJA H
                                        (
                                                H.ADMPV_COD_CLI   ,
                                                H.ADMPV_COD_SEGCLI,
                                                H.ADMPN_COD_CATCLI,
                                                H.ADMPV_TIPO_DOC  ,
                                                H.ADMPV_NUM_DOC   ,
                                                H.ADMPV_NOM_CLI   ,
                                                H.ADMPV_APE_CLI   ,
                                                H.ADMPC_SEXO      ,
                                                H.ADMPV_EST_CIVIL ,
                                                H.ADMPV_EMAIL     ,
                                                H.ADMPV_PROV      ,
                                                H.ADMPV_DEPA      ,
                                                H.ADMPV_DIST      ,
                                                H.ADMPD_FEC_ACTIV ,
                                                /*H.ADMPV_CICL_FACT,*/
                                                H.ADMPC_ESTADO   ,
                                                H.ADMPV_COD_TPOCL,
                                                H.ADMPV_USU_REG
                                        )
                                        VALUES
                                        (
                                                V_CODCLIENTE_N,
                                                NULL          ,
                                                '2'           ,
                                                VCOD_TPDOC_N  ,
                                                K_NUMDOC_N    ,
                                                K_NOMCLI      ,
                                                K_APECLI      ,
                                                K_SEXO        ,
                                                K_ESTCIVIL    ,
                                                K_EMAIL       ,
                                                K_PROV        ,
                                                K_DEPAR       ,
                                                K_DIST        ,
                                                SYSDATE       ,
                                                /*K_CICLOFACT,*/
                                                'A'      ,
                                                K_TIP_CLI,
                                                K_USUARIO
                                        );
                        
                        END IF;
                        /*----Recorreremos la Lista de Productos del nuevo titular----------*/
                        FOR J IN K_COD_CLIPROD_N.FIRST .. K_COD_CLIPROD_N.LAST
                        LOOP
                                V_CLI_PRODUCTO_N := K_COD_CLIPROD_N(J);
                                IF V_CLI_PRODUCTO.DESC_PRODUCTO = V_CLI_PRODUCTO_N.DESC_PRODUCTO THEN
                                        /*-----Verificar si el Servicio Existe en PCLUB.ADMPT_CLIENTEPRODUCTO esta Activo---------*/
                                        SELECT
                                                COUNT(*)
                                        INTO
                                                V_REGCLIPROD_N
                                        FROM
                                                PCLUB.ADMPT_CLIENTEPRODUCTO C
                                        WHERE
                                                C.ADMPV_COD_CLI      =V_CODCLIENTE_N
                                        AND     C.ADMPV_COD_CLI_PROD = V_CLI_PRODUCTO_N.COD_CLI_PROD
                                        AND     C.ADMPV_ESTADO_SERV  = 'A';
                                        
                                        IF V_REGCLIPROD_N   =0 THEN
                                                IF K_TIP_CLI='6' THEN
                                                        V_REGINDICEGRUPO_N := 1;
                                                ELSIF K_TIP_CLI='7' THEN
                                                        V_REGINDICEGRUPO_N := SUBSTR(V_CLI_PRODUCTO_N.COD_CLI_PROD,LENGTH(V_CLI_PRODUCTO_N.COD_CLI_PROD),1);
                                                END IF;
                                                IF K_TIP_CLI            ='6' THEN
                                                        IF V_REG_CLIPROD=1 THEN
                                                                ADMPSS_BAJA(K_TIP_CLI,V_CODCLIENTE,'C',V_CLI_PRODUCTO_N.COD_CLI_PROD ,K_USUARIO,V_CODERROR, V_DESCERROR);
                                                        ELSIF V_REG_CLIPROD>1 THEN
                                                                ADMPSS_BAJA(K_TIP_CLI,V_CODCLIENTE,'P',V_CLI_PRODUCTO_N.COD_CLI_PROD ,K_USUARIO,V_CODERROR, V_DESCERROR);
                                                        END IF;
                                                END IF;
                                                INSERT INTO
                                                        PCLUB.ADMPT_CLIENTEPRODUCTO H
                                                        (
                                                                H.ADMPV_COD_CLI_PROD,
                                                                H.ADMPV_COD_CLI     ,
                                                                H.ADMPV_SERVICIO    ,
                                                                H.ADMPV_ESTADO_SERV ,
                                                                H.ADMPV_FEC_ULTANIV ,
                                                                H.ADMPV_USU_REG     ,
                                                                H.ADMPV_INDICEGRUPO
                                                        )
                                                        VALUES
                                                        (
                                                                V_CLI_PRODUCTO_N.COD_CLI_PROD ,
                                                                V_CODCLIENTE_N                ,
                                                                V_CLI_PRODUCTO_N.DESC_PRODUCTO,
                                                                'A'                           ,
                                                                SYSDATE                       ,
                                                                K_USUARIO                     ,
                                                                V_REGINDICEGRUPO_N
                                                        );
                                                
                                                -- Debemos verificar si el cliente tiene algun saldo asociado
                                                BEGIN
                                                        SELECT
                                                                G.ADMPV_COD_CLI_PROD
                                                        INTO
                                                                V_CODIDCOSALDO
                                                        FROM
                                                                PCLUB.ADMPT_SALDOS_CLIENTEFIJA G
                                                        WHERE
                                                                ADMPV_COD_CLI_PROD = V_CLI_PRODUCTO_N.COD_CLI_PROD;
                                                        
                                                        K_DESCERROR := 'El Nuevo cliente tiene registrado saldos en el servicio: '
                                                        || V_CODIDCOSALDO;
                                                        RAISE EX_SALDO;
                                                EXCEPTION
                                                WHEN NO_DATA_FOUND THEN
                                                        /**Generar secuencial de Saldo*/
                                                        SELECT
                                                                PCLUB.ADMPT_SLD_CLFIJA_SQ.NEXTVAL
                                                        INTO
                                                                V_IDSALDO
                                                        FROM
                                                                DUAL;
                                                        
                                                        INSERT INTO
                                                                PCLUB.ADMPT_SALDOS_CLIENTEFIJA
                                                                (
                                                                        ADMPN_ID_SALDO    ,
                                                                        ADMPV_COD_CLI_PROD,
                                                                        ADMPN_SALDO_CC    ,
                                                                        ADMPN_SALDO_IB    ,
                                                                        ADMPC_ESTPTO_CC   ,
                                                                        ADMPC_ESTPTO_IB   ,
                                                                        ADMPV_USU_REG
                                                                )
                                                                VALUES
                                                                (
                                                                        V_IDSALDO                    ,
                                                                        V_CLI_PRODUCTO_N.COD_CLI_PROD,
                                                                        0.00                         ,
                                                                        0.00                         ,
                                                                        'A'                          ,
                                                                        NULL                         ,
                                                                        K_USUARIO
                                                                );
                                                
                                                WHEN EX_SALDO THEN
                                                        RAISE EX_ERROR;
                                                END;
                                        ELSE
                                                UPDATE
                                                        PCLUB.ADMPT_SALDOS_CLIENTEFIJA S
                                                SET
                                                        S.ADMPN_SALDO_CC = 0.00 ,
                                                        ADMPV_USU_MOD    = K_USUARIO
                                                WHERE
                                                        ADMPV_COD_CLI_PROD = V_CLI_PRODUCTO_N.COD_CLI_PROD;
                                        
                                        END IF;
                                END IF;
                        END LOOP;
                END IF;
        END LOOP;
        -----------SE DARA DE BAJA AL CLIENTE------------
        IF V_REGINDICEGRUPO=1
                AND
                K_TIP_CLI='7' THEN
                ADMPSS_BAJA(K_TIP_CLI,V_CODCLIENTE,'C','',K_USUARIO,V_CODERROR, V_DESCERROR);
        END IF;
        /*CUPONERAVIRTUAL - JCGT INI*/
        PKG_CC_CUPONERA.ADMPSI_CAMBIOTITULAR(VCOD_TPDOC,K_NUMDOC,K_TIPODOC_N,K_NUMDOC_N,K_NOMCLI,K_APECLI,K_EMAIL,'CMBTIT', K_USUARIO,C_CODERROR,C_DESCERROR);
        /*CUPONERAVIRTUAL - JCGT FIN*/
        COMMIT;
        --MANEJO DE ERRORES
        BEGIN
                SELECT
                        ADMPV_DES_ERROR
                                || K_DESCERROR
                INTO
                        K_DESCERROR
                FROM
                        PCLUB.ADMPT_ERRORES_CC
                WHERE
                        ADMPN_COD_ERROR=K_CODERROR;
        
        EXCEPTION
        WHEN OTHERS THEN
                K_DESCERROR:='';
        END;
EXCEPTION
WHEN EX_ERROR THEN
        ROLLBACK;
        BEGIN
                SELECT
                        ADMPV_DES_ERROR
                                || K_DESCERROR
                INTO
                        K_DESCERROR
                FROM
                        PCLUB.ADMPT_ERRORES_CC
                WHERE
                        ADMPN_COD_ERROR=K_CODERROR;
        
        EXCEPTION
        WHEN OTHERS THEN
                K_DESCERROR:='ERROR';
        END;
WHEN OTHERS THEN
        ROLLBACK;
        K_CODERROR  :=1;
        K_DESCERROR := SUBSTR(SQLERRM, 1, 250);
END ADMPSI_CAMBTIT;