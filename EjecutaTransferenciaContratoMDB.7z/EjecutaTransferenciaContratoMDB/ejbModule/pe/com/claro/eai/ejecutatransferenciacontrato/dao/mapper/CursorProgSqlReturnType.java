package pe.com.claro.eai.ejecutatransferenciacontrato.dao.mapper;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlReturnType;

import pe.com.claro.eai.ejecutatransferenciacontrato.dto.CursorBuscarReProceso;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.Constantes;

public class CursorProgSqlReturnType implements SqlReturnType{
    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());

    @SuppressWarnings("rawtypes")
    private RowMapper rowMapper = new RowMapper<CursorBuscarReProceso>() {

        public CursorBuscarReProceso mapRow(ResultSet rs, int numeroFila) throws SQLException {

        	CursorBuscarReProceso objBean = new CursorBuscarReProceso();

            objBean.setIdProceso(rs.getString(Constantes.IDPROCESO));
            objBean.setFechaEjecucion(rs.getString(Constantes.FECHAEJECUCION));
            objBean.setEstadoProceso(rs.getString(Constantes.ESTADOPROCESO));
            objBean.setReintento(rs.getString(Constantes.REINTENTO));
            objBean.setServiCod(rs.getString(Constantes.SERVICOD));
            objBean.setServvXmlEntrada(rs.getString(Constantes.SERVVXMLENTRADA));

            return objBean;
        }
    };

    @SuppressWarnings( { "rawtypes", "unchecked" })
    @Override
    public Object getTypeValue(CallableStatement cs, int ix, int sqlType, String typeName) throws SQLException {

        ResultSet rs = null;
        try {
            rs = (ResultSet)cs.getObject(ix);
            List lista = new ArrayList();

            for (int i = 0; rs.next(); i++) {
                lista.add(rowMapper.mapRow(rs, i));
            }
            return lista;
        } catch (SQLException e) {
            LOGGER.error("ERROR [SQLException]: " + e.getMessage());
            if ((e.getMessage() != null) && (e.getMessage().startsWith(Constantes.EXCEPTIONBDEJECUCION03))) {

                LOGGER.error("[Cursor is closed]: ");
                return new ArrayList();
            } else {
                throw e;
            }
        } finally {
            if (rs != null)
                rs.close();
        }
    }
}
