package pe.com.claro.eai.ejecutatransferenciacontrato.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.com.claro.eai.ebs.ejecutatransferenciacontrato.ws.types.RealizarTransaccionRequest;
import pe.com.claro.eai.ejecutatransferenciacontrato.dao.ClarifyDAO;
import pe.com.claro.eai.ejecutatransferenciacontrato.dao.TimEaiDao;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.BuscarReProcesoBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.CursorBuscarReProceso;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.CursorCustomer;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.CursorServpro;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.InteraccionPlusRequestBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.InteraccionRequestBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.InteraccionResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPBuscarDetServicioMasivo;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPBuscarProgramacionesResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPObtenerCustomerBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPRegistraMigracionResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.TramaInteraccion;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.TransfereciaContratoMessageBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.proxy.EjecutarTransferenciaContrato;
import pe.com.claro.eai.ejecutatransferenciacontrato.service.recursos.RealizaTransaccion;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.Constantes;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.EaiUtil;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.PropertiesExterno;

@Service
public class TransferenciaContratoClientImpl implements TransferenciaContratoClient {

	private final Logger logger = Logger.getLogger(this.getClass().getName());

	@Autowired
	private EaiUtil eaiUtil;
	@Autowired
	private TimEaiDao timeaiDAO;
	@Autowired
	private RealizaTransaccion realizaTransaccion;
	@Autowired
	private EjecutarTransferenciaContrato ejecutaTranContrato;
	@Autowired
	private ClarifyDAO clarifyDAO;
	@Autowired
	private PropertiesExterno propExterno;
	
	int totalExito,totalError;

	private List[] listaProgramaciones;
	
	@Override
	public ResponseBean procesarTransferencia(String men, TransfereciaContratoMessageBean request) throws Exception{
		String mensaje = men + "[procesarTransferencia] - ";
		this.logger.info(mensaje + "[INICIO] - METODO: [procesarTransferencia] ");

		long tiempoInicio = System.currentTimeMillis();
		ResponseBean response = new ResponseBean();
		String CodigoRespuesta="";
		String MensajeRespuesta="";
		totalExito=0;totalError=0;
		java.util.Date fechaHoy = new Date();
		ResponseBean responseRealizar = new ResponseBean();
		SPObtenerCustomerBean obtenerCustomerResponse = new SPObtenerCustomerBean();
		try {
			String fechaEjecucion = request.getFechaEjecucion();
			logger.info(men + "1. Buscar Programacion");
			SPBuscarProgramacionesResponseBean buscarProgrRespBean = this.timeaiDAO.buscarProgramaciones(mensaje,
					request.getIdTransacccion(), this.propExterno.serviCOD, fechaEjecucion,this.propExterno.limiteBuscarProgramacion,
					this.propExterno.estadoInicioProgramacion);
			if (buscarProgrRespBean != null) {
				if (this.propExterno.codigoEstandarExito.equals(buscarProgrRespBean.getCodError())) {
					if (buscarProgrRespBean.getListaServpro().size() > Constantes.INT0) {
						TramaInteraccion trama = new TramaInteraccion();
						List<String> lineasErrorTrama= new ArrayList<>();
						List<String> lineasExitoTrama= new ArrayList<>();
						for (int i = Constantes.INT0; i < buscarProgrRespBean.getListaServpro().size(); i++) {

							CursorServpro beanCur = buscarProgrRespBean.getListaServpro().get(i);
							logger.info(mensaje + "XML_ENTRADA=" + beanCur.getServvXmslEntrada());
							RealizarTransaccionRequest bean = null;
							
							try {
								bean = (RealizarTransaccionRequest) this.eaiUtil
										.xmlTextToJaxB(beanCur.getServvXmslEntrada(), RealizarTransaccionRequest.class);

							} catch (JAXBException jaxbe) {
								logger.error(mensaje + "[reg:" + i + " JAXBException. " + jaxbe.getMessage());
								throw new Exception("[reg:" + i
										+ "] Valor del campo SERVV_XMLENTRADA obtenido de la base de datos de EAI"
										+ "no es del tipo RealizarReactivacionPlanRequest");
							}
							
							logger.info(mensaje + "2.	Registrar Transferencia de Contratos");
							
							SPRegistraMigracionResponseBean registrMigracionRespBean = timeaiDAO.registrarMigracion(
									mensaje, bean.getAudit().getIdTransaccion(), bean.getCoId(), bean.getMsisdn(),
									request.getFechaEjecucion(),bean.getEscenario(), propExterno.codigoEstandarExito);

							if (registrMigracionRespBean != null) {
								logger.info(mensaje + "3.	Encolar mensaje");
								responseRealizar= this.EncolarMensaje(mensaje, request.getIdTransacccion(), beanCur.getServcEstado(),bean);
								if (responseRealizar.getCodeRes().equals(propExterno.codigoEstandarExito)) {
									totalExito++;
									lineasExitoTrama.add(bean.getMsisdn());
									
									
								}else{
									totalError++;
									lineasErrorTrama.add(bean.getMsisdn());
									}
								}
							}
						String fechaString = this.eaiUtil.formatDateObject(Constantes.FORMATDATE,fechaHoy);
						SPBuscarDetServicioMasivo sprBuscarDetRequest = new SPBuscarDetServicioMasivo();
						sprBuscarDetRequest = timeaiDAO.buscarDetServicioMasivo(mensaje, fechaString);
						
						logger.info(mensaje + "3. Generar tipificacion Clarify");
						
						if(sprBuscarDetRequest.getCodError().equals(Constantes.CERO)){
							for(int i = 0;i<listaProgramaciones.length;i++){
								List<CursorBuscarReProceso> buscarReProcesos = listaProgramaciones[i];
								RealizarTransaccionRequest beanReproceso = null;
								beanReproceso = (RealizarTransaccionRequest) this.eaiUtil
										.xmlTextToJaxB(buscarReProcesos.get(0).getServvXmlEntrada(), RealizarTransaccionRequest.class);
							
								obtenerCustomerResponse = clarifyDAO.obtenerCustomer(mensaje, beanReproceso.getMsisdn(), Integer.parseInt(propExterno.clarifyCustomerFlagReg));
								
								List<CursorCustomer> lsCustomer = obtenerCustomerResponse.getListaCustomer();
								InteraccionRequestBean interaccionRequestBean = new InteraccionRequestBean();
								InteraccionResponseBean interResponseBean = new InteraccionResponseBean();
								interaccionRequestBean.setP_contactobjid_1(lsCustomer.get(0).getObjid_contacto());
								interaccionRequestBean.setP_siteobjid_1(lsCustomer.get(0).getObjid_site());
								interaccionRequestBean.setP_account(lsCustomer.get(0).getCuenta());
								interaccionRequestBean.setP_phone(beanReproceso.getMsisdn());
								interaccionRequestBean.setP_tipo(propExterno.interaccionTipo);	
								interaccionRequestBean.setP_clase(sprBuscarDetRequest.getDetalleMasivo().getClase());
								interaccionRequestBean.setP_subclase(sprBuscarDetRequest.getDetalleMasivo().getSubClase());						
								interaccionRequestBean.setP_metodo_contacto(propExterno.interaccionMetodoContacto);
								interaccionRequestBean.setP_tipo_inter(propExterno.interaccionTipoInter);
								interaccionRequestBean.setP_agente(beanReproceso.getAudit().getUsuarioAplicacion());
								interaccionRequestBean.setP_usr_proceso(propExterno.interaccionUsrProceso);
								interaccionRequestBean.setP_hecho_en_uno(propExterno.interaccionHechoEnUno);
								interaccionRequestBean.setP_notas(Constantes.VACIO);
								interaccionRequestBean.setP_flag_caso(propExterno.interaccionFlagExisteSec);
								interaccionRequestBean.setP_resultado(propExterno.interaccionResultadoNinguno);
								
								interResponseBean = clarifyDAO.crearInteraccion(mensaje, interaccionRequestBean);
								
								InteraccionPlusRequestBean interPlusRequestBean = new InteraccionPlusRequestBean();
								interPlusRequestBean.setP_nro_interaccion(interResponseBean.getId_interaccion());
								interPlusRequestBean.setP_inter_1(lsCustomer.get(0).getNombres() + " " +lsCustomer.get(0).getApellidos());
								interPlusRequestBean.setP_inter_2(buscarReProcesos.get(0).getFechaEjecucion());
								interPlusRequestBean.setP_inter_3(fechaHoy.toString());
								interPlusRequestBean.setP_inter_4(lsCustomer.get(0).getNombres() + " " +lsCustomer.get(0).getApellidos());
								interPlusRequestBean.setP_inter_5(Constantes.VACIO);
								interPlusRequestBean.setP_inter_6(Constantes.VACIO);
								interPlusRequestBean.setP_inter_7(String.valueOf(totalExito));
								interPlusRequestBean.setP_inter_8(String.valueOf(totalError));
								interPlusRequestBean.setP_inter_9(String.valueOf(totalExito+totalError));
								interPlusRequestBean.setP_inter_10(CalcularProrrateo(beanReproceso.getCicloFacturacion(), beanReproceso.getPlanTarifario()));//prorrateo
								interPlusRequestBean.setP_inter_11(Constantes.VACIO);
								interPlusRequestBean.setP_inter_12(Constantes.VACIO);
								interPlusRequestBean.setP_inter_13(Constantes.VACIO);
								interPlusRequestBean.setP_inter_14(Constantes.VACIO);
								interPlusRequestBean.setP_inter_15(lsCustomer.get(0).getCuenta());
								interPlusRequestBean.setP_inter_16(sprBuscarDetRequest.getDetalleMasivo().getSEC());
								interPlusRequestBean.setP_inter_17(Constantes.VACIO);
								interPlusRequestBean.setP_inter_18(Constantes.VACIO);
								interPlusRequestBean.setP_inter_19(Constantes.VACIO);
								interPlusRequestBean.setP_inter_20(Constantes.VACIO);
								interPlusRequestBean.setP_inter_21(Constantes.VACIO);
								if(sprBuscarDetRequest.getDetalleMasivo().getSEC().equals(Constantes.VACIO)){
									interPlusRequestBean.setP_inter_22(Constantes.CERO);
								}else{
									interPlusRequestBean.setP_inter_22(Constantes.UNO);
								}
								interPlusRequestBean.setP_inter_23(Constantes.VACIO);
								interPlusRequestBean.setP_inter_24(Constantes.VACIO);
								interPlusRequestBean.setP_inter_25(Constantes.VACIO);
								interPlusRequestBean.setP_inter_26(Constantes.VACIO);
								interPlusRequestBean.setP_inter_27(Constantes.VACIO);
								interPlusRequestBean.setP_inter_28(Constantes.VACIO);
								interPlusRequestBean.setP_inter_29(sprBuscarDetRequest.getDetalleMasivo().getDescripcionProceso());
								trama.setLineasExito(lineasExitoTrama);
								trama.setLineasError(lineasErrorTrama);
								trama.setCuentaDestino(lsCustomer.get(0).getCuenta());
								String tramaXml = this.eaiUtil.jaxBToXmlText(trama);
								interPlusRequestBean.setP_inter_30(tramaXml);
								interPlusRequestBean.setP_plus_inter2interact(Constantes.VACIO);
								interPlusRequestBean.setP_adjustment_amount(Constantes.VACIO);
								interPlusRequestBean.setP_adjustment_reason(Constantes.VACIO);
								interPlusRequestBean.setP_address(Constantes.VACIO);
								interPlusRequestBean.setP_amount_unit(Constantes.VACIO);
								interPlusRequestBean.setP_birthday(fechaHoy);
								interPlusRequestBean.setP_clarify_interaction(Constantes.VACIO);
								interPlusRequestBean.setP_claro_ldn1(Constantes.VACIO);
								interPlusRequestBean.setP_claro_ldn2(Constantes.VACIO);
								interPlusRequestBean.setP_claro_ldn3(Constantes.VACIO);
								interPlusRequestBean.setP_claro_ldn4(Constantes.VACIO);
								interPlusRequestBean.setP_clarolocal1(beanReproceso.getCac());
								interPlusRequestBean.setP_clarolocal2(Constantes.VACIO);
								interPlusRequestBean.setP_clarolocal3(Constantes.VACIO);
								interPlusRequestBean.setP_clarolocal4(Constantes.VACIO);
								interPlusRequestBean.setP_clarolocal5(Constantes.VACIO);
								interPlusRequestBean.setP_clarolocal6(Constantes.VACIO);
								interPlusRequestBean.setP_contact_phone(Constantes.VACIO);
								interPlusRequestBean.setP_dni_legal_rep(Constantes.VACIO);
								interPlusRequestBean.setP_document_number(lsCustomer.get(0).getNro_doc());
								interPlusRequestBean.setP_email(Constantes.VACIO);
								interPlusRequestBean.setP_first_name(lsCustomer.get(0).getNombres());
								interPlusRequestBean.setP_fixed_number(Constantes.VACIO);
								interPlusRequestBean.setP_flag_change_user(Constantes.VACIO);
								interPlusRequestBean.setP_flag_legal_rep(Constantes.VACIO);
								interPlusRequestBean.setP_flag_other(Constantes.VACIO);
								interPlusRequestBean.setP_flag_titular(Constantes.VACIO);
								interPlusRequestBean.setP_imei(Constantes.VACIO);
								interPlusRequestBean.setP_last_name(lsCustomer.get(0).getApellidos());
								interPlusRequestBean.setP_lastname_rep(sprBuscarDetRequest.getDetalleMasivo().getApellidoRepresentanteLeg());
								interPlusRequestBean.setP_ldi_number(Constantes.VACIO);
								interPlusRequestBean.setP_name_legal_rep(sprBuscarDetRequest.getDetalleMasivo().getNombreRepresentanteLeg());
								interPlusRequestBean.setP_old_claro_ldn1(Constantes.VACIO);
								interPlusRequestBean.setP_old_claro_ldn2(Constantes.VACIO);
								interPlusRequestBean.setP_old_claro_ldn3(Constantes.VACIO);
								interPlusRequestBean.setP_old_claro_ldn4(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal1(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal2(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal3(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal4(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal5(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal6(Constantes.VACIO);
								interPlusRequestBean.setP_old_doc_number(Constantes.VACIO);
								interPlusRequestBean.setP_old_first_name(Constantes.VACIO);
								interPlusRequestBean.setP_old_fixed_phone(Constantes.VACIO);
								interPlusRequestBean.setP_old_last_name(Constantes.VACIO);
								interPlusRequestBean.setP_old_ldi_number(Constantes.VACIO);
								interPlusRequestBean.setP_fixed_number(Constantes.VACIO);
								interPlusRequestBean.setP_operation_type(Constantes.VACIO);
								interPlusRequestBean.setP_other_doc_number(Constantes.VACIO);
								interPlusRequestBean.setP_other_first_name(Constantes.VACIO);
								interPlusRequestBean.setP_other_last_name(Constantes.VACIO);
								interPlusRequestBean.setP_other_phone(Constantes.VACIO);
								interPlusRequestBean.setP_phone_legal_rep(Constantes.VACIO);
								interPlusRequestBean.setP_reference_phone(Constantes.VACIO);
								interPlusRequestBean.setP_reason(Constantes.VACIO);
								interPlusRequestBean.setP_model(Constantes.VACIO);
								interPlusRequestBean.setP_lot_code(Constantes.VACIO);
								interPlusRequestBean.setP_flag_registered(Constantes.VACIO);
								interPlusRequestBean.setP_registration_reason(Constantes.VACIO);
								interPlusRequestBean.setP_claro_number(Constantes.VACIO);
								interPlusRequestBean.setP_month(Constantes.VACIO);
								interPlusRequestBean.setP_ost_number(Constantes.VACIO);
								interPlusRequestBean.setP_basket(Constantes.VACIO);
								interPlusRequestBean.setP_expire_date(fechaHoy);
								interPlusRequestBean.setP_ADDRESS5(Constantes.VACIO);
								interPlusRequestBean.setP_CHARGE_AMOUNT(Constantes.VACIO);
								interPlusRequestBean.setP_CITY(Constantes.VACIO);
								interPlusRequestBean.setP_CONTACT_SEX(Constantes.VACIO);
								interPlusRequestBean.setP_DEPARTMENT(Constantes.VACIO);
								interPlusRequestBean.setP_DISTRICT(Constantes.VACIO);
								interPlusRequestBean.setP_EMAIL_CONFIRMATION(Constantes.VACIO);
								interPlusRequestBean.setP_FAX(Constantes.VACIO);
								interPlusRequestBean.setP_FLAG_CHARGE(Constantes.VACIO);
								interPlusRequestBean.setP_MARITAL_STATUS(Constantes.VACIO);
								interPlusRequestBean.setP_OCCUPATION(Constantes.VACIO);
								interPlusRequestBean.setP_POSITION(Constantes.VACIO);
								interPlusRequestBean.setP_REFERENCE_ADDRESS(Constantes.VACIO);
								interPlusRequestBean.setP_TYPE_DOCUMENT(lsCustomer.get(0).getTipo_doc());
								interPlusRequestBean.setP_ZIPCODE(Constantes.VACIO);
								interPlusRequestBean.setP_iccid(Constantes.VACIO);
								
								
								clarifyDAO.crearInteraccionPlus(men, interPlusRequestBean);
							}
						}else{
						logger.info(mensaje+"No se genero Tipificacion");
						}
						logger.info(mensaje + "EXITO IDF0");
						logger.info(mensaje + "Codigo:" + this.propExterno.procProgCodigoRESPUESTAIDF0);
						logger.info(mensaje + "Mensaje:" + this.propExterno.procProgMensajeRESPUESTAIDF0);
						CodigoRespuesta=this.propExterno.procProgCodigoRESPUESTAIDF0;
						MensajeRespuesta=this.propExterno.procProgMensajeRESPUESTAIDF0;
					} else {
						logger.info(mensaje + "Error  Lista vacia IDF1");
						logger.info(mensaje + "Codigo:" + this.propExterno.procProgCodigoRESPUESTAIDF1);
						logger.info(mensaje + "Mensaje:" + this.propExterno.procProgMensajeRESPUESTAIDF1);
						CodigoRespuesta=this.propExterno.procProgCodigoRESPUESTAIDF1;
						MensajeRespuesta=this.propExterno.procProgMensajeRESPUESTAIDF1;
					}
				} else {
					logger.info(mensaje + "Error  con el SP");
					logger.info(mensaje + "Codigo:" + this.propExterno.procProgCodigoRESPUESTAIDF1);
					logger.info(mensaje + "Mensaje:" + this.propExterno.procProgMensajeRESPUESTAIDF1);
					CodigoRespuesta=this.propExterno.procProgCodigoRESPUESTAIDF1;
					MensajeRespuesta=this.propExterno.procProgMensajeRESPUESTAIDF1;
				}
			} else {
				logger.info(mensaje + "Error  con el SP");
				logger.info(mensaje + "Codigo: " + this.propExterno.procProgCodigoRESPUESTAIDT1);
				logger.info(mensaje + "Mensaje: "
						+ this.propExterno.procProgMensajeRESPUESTAIDT1
								.replace(Constantes.JNDI, this.propExterno.dbTimeaiJNDI)
								.replace(Constantes.OBJETO, this.propExterno.dbTIMEAIPKGPPPROGRAMACIONSERV
										+ Constantes.PUNTO + this.propExterno.spTIMEAISPBUSCARPROGRAMACIONES));
				CodigoRespuesta=this.propExterno.procProgCodigoRESPUESTAIDT1;
				MensajeRespuesta=this.propExterno.procProgMensajeRESPUESTAIDT1;
			}
		} catch (Exception e) {
			logger.error(mensaje + "Error Generico: " + e.getMessage());
		} finally {
			response.setCodeRes(CodigoRespuesta);
			response.setMsgRes(MensajeRespuesta);		

			logger.info(mensaje + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			logger.info(mensaje + "<<< Fin del proceso procesarProgramacion >>>");
		}

		return response;
	}
	
	@Override
	public void relanzarTransferencia(String men, TransfereciaContratoMessageBean request) throws Exception{

		String Mensaje = men + "[relanzarProgramacion IdTx:" + request.getIdTransacccion() + "]-";
		logger.info(Mensaje + "<<< Inicio del proceso de relanzarProgramacion >>>");
		Long ini = System.currentTimeMillis();
		totalExito=0;totalError=0;
		java.util.Date fechaHoy = new Date();
		ResponseBean responseRealizar = new ResponseBean();
		SPObtenerCustomerBean obtenerCustomerResponse = new SPObtenerCustomerBean();
		try {
			String fechaEjecucion = request.getFechaEjecucion();
			if (!eaiUtil.validarFecha(fechaEjecucion, Constantes.FORMATDATE)) {
				logger.info(Mensaje + "Formato de fecha ingresado incorrecto");
				return;
			}
			logger.info(Mensaje + "1. Buscar Reproceso");
			BuscarReProcesoBean beanBusRep = this.timeaiDAO.buscarReProceso(Mensaje, this.propExterno.serviCOD,
					fechaEjecucion);
			if (beanBusRep != null) {
				if (this.propExterno.codigoEstandarExito.equals(beanBusRep.getResultado())) {
					if (beanBusRep.getCursorSalida().size() > Constantes.INT0) {
						TramaInteraccion trama = new TramaInteraccion();
						List<String> lineasErrorTrama= new ArrayList<>();
						List<String> lineasExitoTrama= new ArrayList<>();
						for (int i = Constantes.INT0; i < beanBusRep.getCursorSalida().size(); i++) {
							CursorBuscarReProceso beanCur = beanBusRep.getCursorSalida().get(i);
							logger.info(Mensaje + "XML_ENTRADA=" + beanCur.getServvXmlEntrada());
							RealizarTransaccionRequest bean = null;
							agruparProgramacionesRelanzar(beanCur);
							
							try {
								bean = (RealizarTransaccionRequest) this.eaiUtil
										.xmlTextToJaxB(beanCur.getServvXmlEntrada(), RealizarTransaccionRequest.class);

							} catch (JAXBException jaxbe) {
								logger.error(Mensaje + "[reg:" + i + " JAXBException. " + jaxbe.getMessage());
								throw new Exception("[reg:" + i
										+ "] Valor del campo SERVV_XMLENTRADA obtenido de la base de datos de EAI"
										+ "no es del tipo RealizarTransaccionRequest");
							}
							logger.info(Mensaje + "2. Encolar Mensaje");
							responseRealizar= this.EncolarMensaje(Mensaje, request.getIdTransacccion(), beanCur.getEstadoProceso(), bean);
							if (responseRealizar.getCodeRes().equals(propExterno.codigoEstandarExito)) {
								totalExito++;
								lineasExitoTrama.add(bean.getMsisdn());
							}else{
								totalError++;
								lineasErrorTrama.add(bean.getMsisdn());
							}
						}
						
						String fechaString = this.eaiUtil.formatDateObject(Constantes.FORMATDATE,fechaHoy);
						SPBuscarDetServicioMasivo sprBuscarDetRequest = new SPBuscarDetServicioMasivo();
						logger.info(Mensaje + "3. Buscar Detalle Servicio Masivo");
						sprBuscarDetRequest = timeaiDAO.buscarDetServicioMasivo(Mensaje, fechaString);
						
						logger.info(Mensaje + "4. Generar tipificacion Clarify");
						if(sprBuscarDetRequest.getCodError().equals(Constantes.CERO)){
							for(int i = 0;i<listaProgramaciones.length;i++){
								List<CursorBuscarReProceso> buscarReProcesos = listaProgramaciones[i];
								RealizarTransaccionRequest beanReproceso = null;
								beanReproceso = (RealizarTransaccionRequest) this.eaiUtil
										.xmlTextToJaxB(buscarReProcesos.get(0).getServvXmlEntrada(), RealizarTransaccionRequest.class);
							
								obtenerCustomerResponse = clarifyDAO.obtenerCustomer(Mensaje, beanReproceso.getMsisdn(), Integer.parseInt(propExterno.clarifyCustomerFlagReg));
								
								List<CursorCustomer> lsCustomer = obtenerCustomerResponse.getListaCustomer();
								InteraccionRequestBean interaccionRequestBean = new InteraccionRequestBean();
								InteraccionResponseBean interResponseBean = new InteraccionResponseBean();
								interaccionRequestBean.setP_contactobjid_1(lsCustomer.get(0).getObjid_contacto());
								interaccionRequestBean.setP_siteobjid_1(lsCustomer.get(0).getObjid_site());
								interaccionRequestBean.setP_account(lsCustomer.get(0).getCuenta());
								interaccionRequestBean.setP_phone(beanReproceso.getMsisdn());
								interaccionRequestBean.setP_tipo(propExterno.interaccionTipo);	
								interaccionRequestBean.setP_clase(sprBuscarDetRequest.getDetalleMasivo().getClase());
								interaccionRequestBean.setP_subclase(sprBuscarDetRequest.getDetalleMasivo().getSubClase());						
								interaccionRequestBean.setP_metodo_contacto(propExterno.interaccionMetodoContacto);
								interaccionRequestBean.setP_tipo_inter(propExterno.interaccionTipoInter);
								interaccionRequestBean.setP_agente(beanReproceso.getAudit().getUsuarioAplicacion());
								interaccionRequestBean.setP_usr_proceso(propExterno.interaccionUsrProceso);
								interaccionRequestBean.setP_hecho_en_uno(propExterno.interaccionHechoEnUno);
								interaccionRequestBean.setP_notas(Constantes.VACIO);
								interaccionRequestBean.setP_flag_caso(propExterno.interaccionFlagExisteSec);
								interaccionRequestBean.setP_resultado(propExterno.interaccionResultadoNinguno);
								
								interResponseBean = clarifyDAO.crearInteraccion(Mensaje, interaccionRequestBean);
								
								logger.info(Mensaje + "5. Generar Detalle Interaccion");
								InteraccionPlusRequestBean interPlusRequestBean = new InteraccionPlusRequestBean();
								interPlusRequestBean.setP_nro_interaccion(interResponseBean.getId_interaccion());
								interPlusRequestBean.setP_inter_1(lsCustomer.get(0).getNombres() + " " +lsCustomer.get(0).getApellidos());
								interPlusRequestBean.setP_inter_2(buscarReProcesos.get(0).getFechaEjecucion());
								interPlusRequestBean.setP_inter_3(fechaHoy.toString());
								interPlusRequestBean.setP_inter_4(lsCustomer.get(0).getNombres() + " " +lsCustomer.get(0).getApellidos());
								interPlusRequestBean.setP_inter_5(Constantes.VACIO);
								interPlusRequestBean.setP_inter_6(Constantes.VACIO);
								interPlusRequestBean.setP_inter_7(String.valueOf(totalExito));
								interPlusRequestBean.setP_inter_8(String.valueOf(totalError));
								interPlusRequestBean.setP_inter_9(String.valueOf(totalExito+totalError));
								interPlusRequestBean.setP_inter_10(CalcularProrrateo(beanReproceso.getCicloFacturacion(), beanReproceso.getPlanTarifario()));
								interPlusRequestBean.setP_inter_11(Constantes.VACIO);
								interPlusRequestBean.setP_inter_12(Constantes.VACIO);
								interPlusRequestBean.setP_inter_13(Constantes.VACIO);
								interPlusRequestBean.setP_inter_14(Constantes.VACIO);
								interPlusRequestBean.setP_inter_15(lsCustomer.get(0).getCuenta());
								interPlusRequestBean.setP_inter_16(sprBuscarDetRequest.getDetalleMasivo().getSEC());
								interPlusRequestBean.setP_inter_17(Constantes.VACIO);
								interPlusRequestBean.setP_inter_18(Constantes.VACIO);
								interPlusRequestBean.setP_inter_19(Constantes.VACIO);
								interPlusRequestBean.setP_inter_20(Constantes.VACIO);
								interPlusRequestBean.setP_inter_21(Constantes.VACIO);
								if(sprBuscarDetRequest.getDetalleMasivo().getSEC().equals(Constantes.VACIO)){
									interPlusRequestBean.setP_inter_22(Constantes.CERO);
								}else{
									interPlusRequestBean.setP_inter_22(Constantes.UNO);
								}
								interPlusRequestBean.setP_inter_23(Constantes.VACIO);
								interPlusRequestBean.setP_inter_24(Constantes.VACIO);
								interPlusRequestBean.setP_inter_25(Constantes.VACIO);
								interPlusRequestBean.setP_inter_26(Constantes.VACIO);
								interPlusRequestBean.setP_inter_27(Constantes.VACIO);
								interPlusRequestBean.setP_inter_28(Constantes.VACIO);
								interPlusRequestBean.setP_inter_29(sprBuscarDetRequest.getDetalleMasivo().getDescripcionProceso());
								trama.setLineasExito(lineasExitoTrama);
								trama.setLineasError(lineasErrorTrama);
								trama.setCuentaDestino(lsCustomer.get(0).getCuenta());
								String tramaXml = this.eaiUtil.jaxBToXmlText(trama);
								interPlusRequestBean.setP_inter_30(tramaXml);
								interPlusRequestBean.setP_plus_inter2interact(Constantes.VACIO);
								interPlusRequestBean.setP_adjustment_amount(Constantes.VACIO);
								interPlusRequestBean.setP_adjustment_reason(Constantes.VACIO);
								interPlusRequestBean.setP_address(Constantes.VACIO);
								interPlusRequestBean.setP_amount_unit(Constantes.VACIO);
								interPlusRequestBean.setP_birthday(fechaHoy);
								interPlusRequestBean.setP_clarify_interaction(Constantes.VACIO);
								interPlusRequestBean.setP_claro_ldn1(Constantes.VACIO);
								interPlusRequestBean.setP_claro_ldn2(Constantes.VACIO);
								interPlusRequestBean.setP_claro_ldn3(Constantes.VACIO);
								interPlusRequestBean.setP_claro_ldn4(Constantes.VACIO);
								interPlusRequestBean.setP_clarolocal1(beanReproceso.getCac());
								interPlusRequestBean.setP_clarolocal2(Constantes.VACIO);
								interPlusRequestBean.setP_clarolocal3(Constantes.VACIO);
								interPlusRequestBean.setP_clarolocal4(Constantes.VACIO);
								interPlusRequestBean.setP_clarolocal5(Constantes.VACIO);
								interPlusRequestBean.setP_clarolocal6(Constantes.VACIO);
								interPlusRequestBean.setP_contact_phone(Constantes.VACIO);
								interPlusRequestBean.setP_dni_legal_rep(Constantes.VACIO);
								interPlusRequestBean.setP_document_number(lsCustomer.get(0).getNro_doc());
								interPlusRequestBean.setP_email(Constantes.VACIO);
								interPlusRequestBean.setP_first_name(lsCustomer.get(0).getNombres());
								interPlusRequestBean.setP_fixed_number(Constantes.VACIO);
								interPlusRequestBean.setP_flag_change_user(Constantes.VACIO);
								interPlusRequestBean.setP_flag_legal_rep(Constantes.VACIO);
								interPlusRequestBean.setP_flag_other(Constantes.VACIO);
								interPlusRequestBean.setP_flag_titular(Constantes.VACIO);
								interPlusRequestBean.setP_imei(Constantes.VACIO);
								interPlusRequestBean.setP_last_name(lsCustomer.get(0).getApellidos());
								interPlusRequestBean.setP_lastname_rep(sprBuscarDetRequest.getDetalleMasivo().getApellidoRepresentanteLeg());
								interPlusRequestBean.setP_ldi_number(Constantes.VACIO);
								interPlusRequestBean.setP_name_legal_rep(sprBuscarDetRequest.getDetalleMasivo().getNombreRepresentanteLeg());
								interPlusRequestBean.setP_old_claro_ldn1(Constantes.VACIO);
								interPlusRequestBean.setP_old_claro_ldn2(Constantes.VACIO);
								interPlusRequestBean.setP_old_claro_ldn3(Constantes.VACIO);
								interPlusRequestBean.setP_old_claro_ldn4(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal1(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal2(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal3(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal4(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal5(Constantes.VACIO);
								interPlusRequestBean.setP_old_clarolocal6(Constantes.VACIO);
								interPlusRequestBean.setP_old_doc_number(Constantes.VACIO);
								interPlusRequestBean.setP_old_first_name(Constantes.VACIO);
								interPlusRequestBean.setP_old_fixed_phone(Constantes.VACIO);
								interPlusRequestBean.setP_old_last_name(Constantes.VACIO);
								interPlusRequestBean.setP_old_ldi_number(Constantes.VACIO);
								interPlusRequestBean.setP_fixed_number(Constantes.VACIO);
								interPlusRequestBean.setP_operation_type(Constantes.VACIO);
								interPlusRequestBean.setP_other_doc_number(Constantes.VACIO);
								interPlusRequestBean.setP_other_first_name(Constantes.VACIO);
								interPlusRequestBean.setP_other_last_name(Constantes.VACIO);
								interPlusRequestBean.setP_other_phone(Constantes.VACIO);
								interPlusRequestBean.setP_phone_legal_rep(Constantes.VACIO);
								interPlusRequestBean.setP_reference_phone(Constantes.VACIO);
								interPlusRequestBean.setP_reason(Constantes.VACIO);
								interPlusRequestBean.setP_model(Constantes.VACIO);
								interPlusRequestBean.setP_lot_code(Constantes.VACIO);
								interPlusRequestBean.setP_flag_registered(Constantes.VACIO);
								interPlusRequestBean.setP_registration_reason(Constantes.VACIO);
								interPlusRequestBean.setP_claro_number(Constantes.VACIO);
								interPlusRequestBean.setP_month(Constantes.VACIO);
								interPlusRequestBean.setP_ost_number(Constantes.VACIO);
								interPlusRequestBean.setP_basket(Constantes.VACIO);
								interPlusRequestBean.setP_expire_date(fechaHoy);
								interPlusRequestBean.setP_ADDRESS5(Constantes.VACIO);
								interPlusRequestBean.setP_CHARGE_AMOUNT(Constantes.VACIO);
								interPlusRequestBean.setP_CITY(Constantes.VACIO);
								interPlusRequestBean.setP_CONTACT_SEX(Constantes.VACIO);
								interPlusRequestBean.setP_DEPARTMENT(Constantes.VACIO);
								interPlusRequestBean.setP_DISTRICT(Constantes.VACIO);
								interPlusRequestBean.setP_EMAIL_CONFIRMATION(Constantes.VACIO);
								interPlusRequestBean.setP_FAX(Constantes.VACIO);
								interPlusRequestBean.setP_FLAG_CHARGE(Constantes.VACIO);
								interPlusRequestBean.setP_MARITAL_STATUS(Constantes.VACIO);
								interPlusRequestBean.setP_OCCUPATION(Constantes.VACIO);
								interPlusRequestBean.setP_POSITION(Constantes.VACIO);
								interPlusRequestBean.setP_REFERENCE_ADDRESS(Constantes.VACIO);
								interPlusRequestBean.setP_TYPE_DOCUMENT(lsCustomer.get(0).getTipo_doc());
								interPlusRequestBean.setP_ZIPCODE(Constantes.VACIO);
								interPlusRequestBean.setP_iccid(Constantes.VACIO);
								clarifyDAO.crearInteraccionPlus(men, interPlusRequestBean);						
							}
						}else{ 
							logger.info(men+"No se genero Tipificacion");
						}
						logger.info(men + "Exito IDF0 ");
						logger.info(men + "Codigo:" + this.propExterno.relaProgCodigoRESPUESTAIDF0);
						logger.info(men + "Mensaje:" + this.propExterno.relaProgMensajeRESPUESTAIDF0);
					} else {
						logger.info(men + "Error Lista vacia IDF1");
						logger.info(men + "Codigo:" + this.propExterno.relaProgCodigoRESPUESTAIDF1);
						logger.info(men + "Mensaje:" + this.propExterno.relaProgMensajeRESPUESTAIDF1);
					}
				} else {
					logger.info(men + "Error  con el SP");
					logger.info(men + "Codigo:" + this.propExterno.relaProgCodigoRESPUESTAIDF1);
					logger.info(men + "Mensaje:" + this.propExterno.relaProgMensajeRESPUESTAIDF1);
				}
			} else {
				logger.info(men + "Error  con el SP");
				logger.info(men + "Codigo: " + this.propExterno.procProgCodigoRESPUESTAIDT1);
				logger.info(men + "Mensaje: "
						+ this.propExterno.procProgMensajeRESPUESTAIDT1
								.replace(Constantes.JNDI, this.propExterno.dbTimeaiJNDI)
								.replace(Constantes.OBJETO, this.propExterno.dbTIMEAIPKGMIGRACIONPLANPOST
										+ Constantes.PUNTO + this.propExterno.spTIMEAISPBUSCARREPROCESO));
			}
		} catch (Exception e) {
			logger.error(men + "Error Generico: " + e.getMessage());
		} finally {
			logger.info(men + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - ini) + " milisegundos ]");
			logger.info(men + "<<< Fin del proceso relanzarProgramacion >>>");
		}
	}

	private ResponseBean EncolarMensaje(String msgTxId, String idTx, String idEstado, RealizarTransaccionRequest bean) {

		ResponseBean responseBean = new ResponseBean();
		ResponseBean responseEjecutaContrato = new ResponseBean();
		ResponseBean response = new ResponseBean();
		bean.setFase(propExterno.realizarFase1);
		try {
			logger.info(msgTxId + "3.1. Actualizar Transaccion Masiva ");
			
			responseBean = timeaiDAO.actualizarTransMasiva(msgTxId, bean.getMsisdn(),
					propExterno.EstadoTransMasivaProceso,bean.getEscenario());
			if (!responseBean.getCodeRes().equals(propExterno.codigoEstandarExito)) {
				logger.info(msgTxId + "Codigo: " + responseBean.getCodeRes());
				logger.info(msgTxId + "Mensaje: " + responseBean.getMsgRes());
				return responseBean;
			}

			logger.info(msgTxId + "3.2. Realizar Transferencia ");
			RealizarTransaccionRequest requestRealizaTrans = bean;
			responseEjecutaContrato = ejecutaTranContrato.realizarTransferencia(msgTxId, requestRealizaTrans);

			if (responseEjecutaContrato.getCodeRes().equals(propExterno.codigoEstandarExito)) {
				logger.info(msgTxId + "3.3. Registrar Exito ");
				realizaTransaccion.registrarExito(msgTxId, bean.getAudit().getIdTransaccion(), bean.getCoId(),
						bean.getMsisdn(), propExterno.realTranFASE0, propExterno.codigoEstandarExito,
						propExterno.mensajeEstandarExito,bean.getEscenario());
			} else {
				logger.info(msgTxId + "3.4. Registrar Error ");
				realizaTransaccion.registrarError(msgTxId, bean.getAudit().getIdTransaccion(), bean.getCoId(),
						bean.getMsisdn(), propExterno.realTranFASE0, propExterno.estadoRegistroProgramacionError,
						propExterno.procProgMensajeRESPUESTAIDT2.replace(Constantes.WSDL,
								propExterno.wsUrlEJECUTARTRANSFERENCIACONTRATO),
						propExterno.realTranServiCod, bean.getFechaProgramacion().toGregorianCalendar().getTime(), idTx,
						new Date(), propExterno.codigoEstadoErrorProgramacion, propExterno.realTranCodigoRESPUESTAIDF2,
						propExterno.procProgMensajeRESPUESTAIDT2.replace(Constantes.WSDL,
								propExterno.wsUrlEJECUTARTRANSFERENCIACONTRATO),
						propExterno.codigoErrorActProgramacion,
						propExterno.procProgMensajeRESPUESTAIDT2.replace(Constantes.WSDL,
								propExterno.wsUrlEJECUTARTRANSFERENCIACONTRATO),
						bean.getAudit().getIpAplicacion(), bean.getAudit().getUsuarioAplicacion(),bean.getEscenario());
			}
			response.setCodeRes(responseEjecutaContrato.getCodeRes());
			response.setMsgRes(responseEjecutaContrato.getMsgRes());
			
		} catch (Exception e) {
			logger.error(msgTxId + "Error Generico: " + e.getMessage());
		}
		return response;
	}

	private void agruparProgramacionesProcesar(CursorServpro cursorServpro, RealizarTransaccionRequest request) {

		if (listaProgramaciones.length < 1) {
			List<CursorServpro> listCursorServpro = new ArrayList<CursorServpro>();
			listCursorServpro.add(cursorServpro);
			listaProgramaciones[0] = listCursorServpro;
		} else {
			int flagBusqueda = 0;
			for (int i = 0; i < listaProgramaciones.length; i++) {
				List<CursorServpro> listCursorServpro = listaProgramaciones[i];
				if (cursorServpro.getServvIdEeaiSw().equals(listCursorServpro.get(0).getServvIdEeaiSw())) {
					listCursorServpro.add(cursorServpro);
					flagBusqueda = 1;
					listaProgramaciones[i] = listCursorServpro;
				}
			}
			if(flagBusqueda == 0){
				List<CursorServpro> listCursorServpro = new ArrayList<CursorServpro>();
				listCursorServpro.add(cursorServpro);
				listaProgramaciones[listaProgramaciones.length] = listCursorServpro;
			}
		}
	}

	private void agruparProgramacionesRelanzar(CursorBuscarReProceso cursorServpro) {

		if (listaProgramaciones.length < 1) {
			List<CursorBuscarReProceso> listCursorServpro = new ArrayList<CursorBuscarReProceso>();
			listCursorServpro.add(cursorServpro);
			listaProgramaciones[0] = listCursorServpro;
		} else {
			int flagBusqueda = 0;
			for (int i = 0; i < listaProgramaciones.length; i++) {
				List<CursorBuscarReProceso> listCursorServpro = listaProgramaciones[i];
				if (cursorServpro.getIdProceso().equals(listCursorServpro.get(0).getIdProceso())) {
					listCursorServpro.add(cursorServpro);
					flagBusqueda = 1;
					listaProgramaciones[i] = listCursorServpro;
				}
			}
			if(flagBusqueda == 0){
				List<CursorBuscarReProceso> listCursorServpro = new ArrayList<CursorBuscarReProceso>();
				listCursorServpro.add(cursorServpro);
				listaProgramaciones[listaProgramaciones.length] = listCursorServpro;
			}
		}
	}
	
	private String CalcularProrrateo(String cicloFacturacion,long pagoMensual ){
		java.util.Date fechaHoy = new Date();
		long diferenciaDias =0;
		
		Date fechaCicloFacturacion = eaiUtil.stringToDate(cicloFacturacion, Constantes.FORMATDATE);
		diferenciaDias = (fechaHoy.getTime() - fechaCicloFacturacion.getTime())/Constantes.MILLSECS_PER_DAY;
		
		long prorrateo = diferenciaDias*(pagoMensual/Constantes.DIASMES);
		return String.valueOf(prorrateo);
	}

	

}
