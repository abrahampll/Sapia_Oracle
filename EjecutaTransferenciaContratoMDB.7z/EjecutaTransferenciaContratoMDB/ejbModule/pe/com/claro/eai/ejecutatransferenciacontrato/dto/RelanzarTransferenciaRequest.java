package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import javax.xml.datatype.XMLGregorianCalendar;

public class RelanzarTransferenciaRequest {
    private String idTransaccion;
    private String ipAplicacion;
    private String nombreAplicacion;
    private String usuarioAplicacion;
    private XMLGregorianCalendar fechaEjecucion;
    
	public String getIdTransaccion() {
		return idTransaccion;
	}
	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}
	public String getIpAplicacion() {
		return ipAplicacion;
	}
	public void setIpAplicacion(String ipAplicacion) {
		this.ipAplicacion = ipAplicacion;
	}
	public String getNombreAplicacion() {
		return nombreAplicacion;
	}
	public void setNombreAplicacion(String nombreAplicacion) {
		this.nombreAplicacion = nombreAplicacion;
	}
	public String getUsuarioAplicacion() {
		return usuarioAplicacion;
	}
	public void setUsuarioAplicacion(String usuarioAplicacion) {
		this.usuarioAplicacion = usuarioAplicacion;
	}
	public XMLGregorianCalendar getFechaEjecucion() {
		return fechaEjecucion;
	}
	public void setFechaEjecucion(XMLGregorianCalendar fechaEjecucion) {
		this.fechaEjecucion = fechaEjecucion;
	}
}
