package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.io.Serializable;

public class SPBuscarDetServicioMasivo implements Serializable  {
	private static final long serialVersionUID = 1L;
    private DetalleMasivo detalleMasivo;
    private String codError;
    private String menError;
    
	public DetalleMasivo getDetalleMasivo() {
		return detalleMasivo;
	}
	public void setDetalleMasivo(DetalleMasivo detalleMasivo) {
		this.detalleMasivo = detalleMasivo;
	}
	public String getCodError() {
		return codError;
	}
	public void setCodError(String codError) {
		this.codError = codError;
	}
	public String getMenError() {
		return menError;
	}
	public void setMenError(String menError) {
		this.menError = menError;
	}
	
    
}
