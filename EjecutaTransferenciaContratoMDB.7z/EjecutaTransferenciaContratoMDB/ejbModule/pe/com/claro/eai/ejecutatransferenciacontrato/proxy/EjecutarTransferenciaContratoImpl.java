package pe.com.claro.eai.ejecutatransferenciacontrato.proxy;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.com.claro.eai.ebs.ejecutatransferenciacontrato.ws.EbsEjecutaTransferenciaContrato;
import pe.com.claro.eai.ebs.ejecutatransferenciacontrato.ws.types.AudiTypeResponse;
import pe.com.claro.eai.ebs.ejecutatransferenciacontrato.ws.types.RealizarTransaccionRequest;
import pe.com.claro.eai.ebs.ejecutatransferenciacontrato.ws.types.RealizarTransaccionResponse;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.Constantes;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.EaiUtil;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.PropertiesExterno;

@Service
public class EjecutarTransferenciaContratoImpl implements EjecutarTransferenciaContrato {
	private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
	
    @Autowired
    private EbsEjecutaTransferenciaContrato ejecutaTransferencia;
    @Autowired
    private PropertiesExterno propExterno;
    @Autowired
    private EaiUtil eaiUtil;
    
	@Override
	public ResponseBean realizarTransferencia(String mensajeTransaccion,RealizarTransaccionRequest request) {
        String cadenaMensaje = mensajeTransaccion + "[realizarTransferencia]";
        LOGGER.info(cadenaMensaje + "[INICIO] - METODO: [realizarTransferencia] ");

        ResponseBean outResponseBean = new ResponseBean();
        
        try {

        	RealizarTransaccionRequest requestRealizaTrans = request;
        	RealizarTransaccionResponse response = null;

            LOGGER.info(cadenaMensaje + "CONSUMIENDO WS: [" + this.propExterno.wsUrlEJECUTARTRANSFERENCIACONTRATO + Constantes.CLOSECORCHETE);
            LOGGER.info(cadenaMensaje + "XML [REQUEST]: " + this.eaiUtil.jaxBToXmlText(requestRealizaTrans));
            response = this.ejecutaTransferencia.realizarTransaccion(requestRealizaTrans);

            LOGGER.info(cadenaMensaje + "XML [RESPONSE]: " + this.eaiUtil.jaxBToXmlText(response));
            String codigoRespuesta = response.getAuditResponse().getCodigoRespuesta();
            String mensajeRespuesta = response.getAuditResponse().getMensajeRespuesta();

            outResponseBean.setCodeRes(codigoRespuesta);
            outResponseBean.setMsgRes(mensajeRespuesta);
            outResponseBean.setObjetoRespuesta(response);

        } catch (Exception e) {
            LOGGER.error(cadenaMensaje + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE);
            throw e;
        } finally {

            LOGGER.info(cadenaMensaje + "codigoRespuesta : [" + outResponseBean.getCodeRes() + Constantes.CLOSECORCHETE);
            LOGGER.info(cadenaMensaje + "mensajeRespuesta : [" + outResponseBean.getMsgRes() + Constantes.CLOSECORCHETE);
            LOGGER.info(cadenaMensaje + "[FIN] - METODO: [realizarTransferencia] ");
        }
        return outResponseBean;
	}

}
