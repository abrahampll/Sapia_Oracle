package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.io.Serializable;
import java.util.List;

public class SPBuscarProgramacionesResponseBean implements Serializable {
    
	@SuppressWarnings("compatibility:-6205102999141269259")
    private static final long serialVersionUID = 1L;
    private List<CursorServpro> listaServpro;
    private String codError;
    private String menError;
    
	public List<CursorServpro> getListaServpro() {
		return listaServpro;
	}
	public void setListaServpro(List<CursorServpro> listaServpro) {
		this.listaServpro = listaServpro;
	}
	public String getCodError() {
		return codError;
	}
	public void setCodError(String codError) {
		this.codError = codError;
	}
	public String getMenError() {
		return menError;
	}
	public void setMenError(String menError) {
		this.menError = menError;
	}
    
}
