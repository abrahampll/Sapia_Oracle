package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.util.List;

public class SPObtenerCustomerBean {
	@SuppressWarnings("compatibility:-6205102999141269259")
    private static final long serialVersionUID = 1L;
    private List<CursorCustomer> listaCustomer;
    private String flag_Consulta;
    private String mentext;
	public List<CursorCustomer> getListaCustomer() {
		return listaCustomer;
	}
	public void setListaCustomer(List<CursorCustomer> listaCustomer) {
		this.listaCustomer = listaCustomer;
	}
	public String getFlag_Consulta() {
		return flag_Consulta;
	}
	public void setFlag_Consulta(String flag_Consulta) {
		this.flag_Consulta = flag_Consulta;
	}
	public String getMentext() {
		return mentext;
	}
	public void setMentext(String mentext) {
		this.mentext = mentext;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
}
