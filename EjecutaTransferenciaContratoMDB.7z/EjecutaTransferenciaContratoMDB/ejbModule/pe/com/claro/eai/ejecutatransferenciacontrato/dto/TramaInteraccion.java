package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement (name="TramaInteraccion")
public class TramaInteraccion implements Serializable{
	private static final long serialVersionUID = 1L;
	private List<String> lineasError;
	private List<String> lineasExito;
	private String CuentaDestino;
	
	public List<String> getLineasError() {
		return lineasError;
	}
	@XmlElement(name = "lineasError")
	public void setLineasError(List<String> lineasError) {
		this.lineasError = lineasError;
	}
	public List<String> getLineasExito() {
		return lineasExito;
	}
	@XmlElement(name = "lineasExito")
	public void setLineasExito(List<String> lineasExito) {
		this.lineasExito = lineasExito;
	}
	public String getCuentaDestino() {
		return CuentaDestino;
	}
	@XmlElement(name = "cuentaDestino")
	public void setCuentaDestino(String cuentaDestino) {
		CuentaDestino = cuentaDestino;
	}

	
}
