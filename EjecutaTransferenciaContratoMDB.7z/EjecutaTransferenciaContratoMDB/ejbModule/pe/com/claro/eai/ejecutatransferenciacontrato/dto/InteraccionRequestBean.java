package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

public class InteraccionRequestBean {

	private String p_contactobjid_1;
	private String p_siteobjid_1;
	private String p_account;
	private String p_phone;
	private String p_tipo;
	private String p_clase;
	private String p_subclase;
	private String p_metodo_contacto;
	private String p_tipo_inter;
	private String p_agente;
	private String p_usr_proceso;
	private String p_hecho_en_uno;
	private String p_notas;
	private String p_flag_caso;
	private String p_resultado;
	
	public String getP_contactobjid_1() {
		return p_contactobjid_1;
	}
	public void setP_contactobjid_1(String p_contactobjid_1) {
		this.p_contactobjid_1 = p_contactobjid_1;
	}
	public String getP_siteobjid_1() {
		return p_siteobjid_1;
	}
	public void setP_siteobjid_1(String p_siteobjid_1) {
		this.p_siteobjid_1 = p_siteobjid_1;
	}
	public String getP_account() {
		return p_account;
	}
	public void setP_account(String p_account) {
		this.p_account = p_account;
	}
	public String getP_phone() {
		return p_phone;
	}
	public void setP_phone(String p_phone) {
		this.p_phone = p_phone;
	}
	public String getP_tipo() {
		return p_tipo;
	}
	public void setP_tipo(String p_tipo) {
		this.p_tipo = p_tipo;
	}
	public String getP_clase() {
		return p_clase;
	}
	public void setP_clase(String p_clase) {
		this.p_clase = p_clase;
	}
	public String getP_subclase() {
		return p_subclase;
	}
	public void setP_subclase(String p_subclase) {
		this.p_subclase = p_subclase;
	}
	public String getP_metodo_contacto() {
		return p_metodo_contacto;
	}
	public void setP_metodo_contacto(String p_metodo_contacto) {
		this.p_metodo_contacto = p_metodo_contacto;
	}
	public String getP_tipo_inter() {
		return p_tipo_inter;
	}
	public void setP_tipo_inter(String p_tipo_inter) {
		this.p_tipo_inter = p_tipo_inter;
	}
	public String getP_agente() {
		return p_agente;
	}
	public void setP_agente(String p_agente) {
		this.p_agente = p_agente;
	}
	public String getP_usr_proceso() {
		return p_usr_proceso;
	}
	public void setP_usr_proceso(String p_usr_proceso) {
		this.p_usr_proceso = p_usr_proceso;
	}
	public String getP_hecho_en_uno() {
		return p_hecho_en_uno;
	}
	public void setP_hecho_en_uno(String p_hecho_en_uno) {
		this.p_hecho_en_uno = p_hecho_en_uno;
	}
	public String getP_notas() {
		return p_notas;
	}
	public void setP_notas(String p_notas) {
		this.p_notas = p_notas;
	}
	public String getP_flag_caso() {
		return p_flag_caso;
	}
	public void setP_flag_caso(String p_flag_caso) {
		this.p_flag_caso = p_flag_caso;
	}
	public String getP_resultado() {
		return p_resultado;
	}
	public void setP_resultado(String p_resultado) {
		this.p_resultado = p_resultado;
	}
	
}
