package pe.com.claro.eai.ejecutatransferenciacontrato.util;

public class Constantes {
	
	public static final String PROCESARTRANSFERENCIA = "procesarTransferenciaContrato";
	public static final String RELANZARTRANSFERENCIA = "relanzarTransferenciaContrato";
	public static final String PROCESARTRANSFERENCIASELECT = "1";
	public static final String RELANZARTRANSFERENCIASELECT = "2";
	public static final String PROCESONOENCONTRADO = "proceso no encontrado";

	public static final String CLOSECORCHETE = "] ";
	public static final String PUNTO = ".";
	public static final String UTF8="UTF-8";
	public static final String VACIO="";
	public static final String SIMBDIERESIS = "'"; 
	public static final String CARACTERCOMILLASIMPLE = "'";
	public static final String CARACTERCOMILLADOBLE = "\"";
	public static final long MILLSECS_PER_DAY = 24 * 60 * 60 * 1000; //Milisegundos al día
	public static final long DIASMES = 30;
	public static final String PALOTE = "|";
			
    public static final int INT0=0;
    public static final int INT1=1;
    public static final int INT2=2;
    public static final int INT3=3;
    public static final int INT15=15;
    public static final int INT99=99;
    public static final int INT100=100;
    
    public static final String ESCENARIOUS = "UnionSeparacion";
	
	public static final String FORMATDATE="yyyy-MM-dd";
	
    public static final String OPENCORCHETE = " ["; 
	public static final String PARAMETROIN = "PARAMETROS [INPUT]: ";
	public static final String PARAMETROOUT = "PARAMETROS [OUPUT]: ";
	
	public static final String PIDPROCESO = "p_id_proceso";
	public static final String PSERVICOD = "p_servi_cod";
	public static final String PFECHAPROG = "p_fecha_prog";
	public static final String PLIMITE = "p_limite";
	public static final String PSERVCESTADO = "p_servc_estado";
	public static final String PCURSORSERVPRO = "p_cursorservpro";
    public static final String PCODERROR = "p_cod_error";
    public static final String PMENERROR = "p_men_error";
	
	public static final String SERVVMSISDN = "SERVV_MSISDN";
    public static final String SERVDFECHAPROG = "SERVD_FECHAPROG";
    public static final String COID = "CO_ID";
    public static final String SERVVIDEAISW = "SERVV_ID_EAI_SW";
    public static final String SERVVUSUARIOAPLICACION = "SERVV_USUARIO_APLICACION";
    public static final String SERVVEMAILUSUARIOAPP = "SERVV_EMAIL_USUARIO_APP";
    public static final String SERVVUSUARIOSISTEMA = "SERVV_USUARIO_SISTEMA";
    public static final String SERVDFECHAREG = "SERVD_FECHA_REG";
    public static final String SERVDFECHAEJEC = "SERVD_FECHA_EJEC";
    public static final String SERVCESTADO = "SERVC_ESTADO";
    public static final String SERVCESBATCH = "SERVC_ESBATCH";
    public static final String SERVVIDBATCH = "SERVV_ID_BATCH";
    public static final String SERVVMENERROR = "SERVV_MEN_ERROR";
    public static final String SERVVCODERROR = "SERVV_COD_ERROR";
    public static final String SERVVXMLENTRADA="SERVV_XMLENTRADA";
    
    public static final String EXCEPTIONBDEJECUCION03     = "Cursor is closed";
    

    public static final String JNDI="jndi";
    public static final String OBJETO="objeto";
    public static final String WSDL="wsdl";
            
	public static final String RELANZAR_PSERVICOD = "p_servi_cod";
	public static final String RELANZAR_PSERVFECHAEJEC = "p_servd_fecha_ejec";
	public static final String RELANZAR_PRESULTADO = "p_resultado";
	public static final String RELANZAR_PMENSAJE = "p_mensaje";
	public static final String RELANZAR_PCURSORPROG = "p_cursor_prog";
	
    public static final String IDPROCESO="id_proceso";
    public static final String FECHAEJECUCION="fecha_ejecucion";
    public static final String ESTADOPROCESO="estado_proceso";
    public static final String REINTENTO="reintento";
    public static final String SERVICOD="servi_cod";
    
    public static final String PMSISDN = "p_msisdn";
    public static final String PCOID = "p_co_id";
    public static final String PESTADO = "p_estado";
    public static final String PSERVICOD2 = "p_servicod";
    public static final String PCODIGOERROR = "p_codigo_error";
    public static final String PMENSAJEERROR = "p_mensaje_error";
    public static final String PRESULTADO = "p_resultado";
    public static final String PMENSAJE = "p_mensaje";
    public static final String PFECHAPROGRAMACION2 = "p_fechaprogramacion";
    public static final String PESCENARIOMIGRACION = "p_escenario_migracion";
    
    public static final String PISPMRNIDSERVPROGMA ="PI_SPMRN_IDSERV_PROGMA";
    public static final String PITACONIDESTADO  ="PI_TACON_IDESTADO";
    public static final String PIFLAGOPERACION  ="PI_FLAG_OPERACION";
    public static final String PITACOVIDINTERACT="PI_TACOV_IDINTERACT";
    public static final String PITACOCMSJRESPROG="PI_TACOC_MSJRES_PROG";
    public static final String PITACOCTRACE="PI_TACOC_TRACE";
    public static final String POCODERROR="PO_COD_ERROR";
    public static final String PODESERROR="PO_DES_ERROR";
    
    public static final String PSERVVMSISDN = "p_servv_msisdn";   
    public static final String PSERVDFECHAPROG = "p_servd_fecha_prog"; 
    public static final String PSERVVIDBATCH = "p_servv_id_batch";
    public static final String PSERVDFECHAEJEC = "p_servd_fecha_ejec";
    public static final String PSERVVMENERROR = "p_servv_men_error";
    public static final String PSERVVCODERROR = "p_servv_cod_error";
    
    public static final String PITACOVCAMPO1 ="pi_tacov_campo1";
    
    public static final String PNROTELEFONO = "p_nro_telefono";
    public static final String PTMCODEMEN = "p_tmcode_men";
    public static final String PNUMFACT = "p_num_fact";
    public static final String PCARGOFIJOACT = "p_cargo_fijo_act";
    public static final String PCARGOFIJOMEN = "p_cargo_fijo_men";
    
    public static final String CERO = "0";
    public static final String UNO = "1";
    public static final String OK="OK";
    
    public static final String EJBSPRING = "classpath*:beanRefContext.xml";
}
