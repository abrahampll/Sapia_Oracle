package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.io.Serializable;

public class CursorBuscarReProceso implements Serializable{
    @SuppressWarnings("compatibility:8430380264495298953")
    private static final long serialVersionUID = 1L;
	private String idProceso;
	private String fechaEjecucion;
	private String estadoProceso;
	private String reintento;
	private String serviCod;
	private String servvXmlEntrada;
	public String getIdProceso() {
		return idProceso;
	}
	public void setIdProceso(String idProceso) {
		this.idProceso = idProceso;
	}
	public String getFechaEjecucion() {
		return fechaEjecucion;
	}
	public void setFechaEjecucion(String fechaEjecucion) {
		this.fechaEjecucion = fechaEjecucion;
	}
	public String getEstadoProceso() {
		return estadoProceso;
	}
	public void setEstadoProceso(String estadoProceso) {
		this.estadoProceso = estadoProceso;
	}
	public String getReintento() {
		return reintento;
	}
	public void setReintento(String reintento) {
		this.reintento = reintento;
	}
	public String getServiCod() {
		return serviCod;
	}
	public void setServiCod(String serviCod) {
		this.serviCod = serviCod;
	}
	public String getServvXmlEntrada() {
		return servvXmlEntrada;
	}
	public void setServvXmlEntrada(String servvXmlEntrada) {
		this.servvXmlEntrada = servvXmlEntrada;
	}
}
