package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.io.Serializable;
import java.util.List;

public class BuscarReProcesoBean implements Serializable{
	private static final long serialVersionUID = 1L;

	private String resultado;
	private String mensaje;
	private List<CursorBuscarReProceso> cursorSalida;
	
	public String getResultado() {
		return resultado;
	}
	public void setResultado(String resultado) {
		this.resultado = resultado;
	}
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public List<CursorBuscarReProceso> getCursorSalida() {
		return cursorSalida;
	}
	public void setCursorSalida(List<CursorBuscarReProceso> cursorSalida) {
		this.cursorSalida = cursorSalida;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
