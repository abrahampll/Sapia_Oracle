package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

public class ProcesarTransferenciaResponse {

}
