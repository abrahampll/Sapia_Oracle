package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement (name="TransfereciaContratoMessageBean")
public class TransfereciaContratoMessageBean implements Serializable{

	private static final long serialVersionUID = 1L;
	private String idTransacccion;
	private String flagProceso;
	private String fechaEjecucion;
	
	public String getIdTransacccion() {
		return idTransacccion;
	}
	@XmlElement(name = "idTransacccion")
	public void setIdTransacccion(String idTransacccion) {
		this.idTransacccion = idTransacccion;
	}
	
	public String getFlagProceso() {
		return flagProceso;
	}
	@XmlElement(name = "flagProceso")
	public void setFlagProceso(String flagProceso) {
		this.flagProceso = flagProceso;
	}
	public String getFechaEjecucion() {
		return fechaEjecucion;
	}
	@XmlElement(name = "fechaEjecucion")
	public void setFechaEjecucion(String fechaEjecucion) {
		this.fechaEjecucion = fechaEjecucion;
	}
	
}
