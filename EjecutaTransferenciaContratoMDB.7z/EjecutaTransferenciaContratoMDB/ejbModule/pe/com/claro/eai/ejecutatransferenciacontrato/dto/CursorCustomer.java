package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.io.Serializable;
import java.util.Date;

public class CursorCustomer implements Serializable{
	//@SuppressWarnings("compatibility:-3731418951957465822")
    private static final long serialVersionUID = 1L;
	private String objid_contacto;
	private String objid_site;
	private String telefono;
	private String cuenta;
	private String modalidad;
	private String segmento;
	private String rol_contacto;
	private String estado_contacto;
	private String estado_contrato;
	private String estado_site;
	private String s_nombre;
	private String s_apellidos;
	private String nombres;
	private String apellidos;
	private String domicilio;
	private String urbanizacion;
	private String referencia;
	private String ciudad;
	private String distrito;
	private String departamento;
	private String zipcode;
	private String email;
	private String telef_referencia;
	private String fax;
	private Date fecha_nac;
	private String sexo;
	private String estado_civil;
	private String tipo_doc;
	private String nro_doc;
	private Date fecha_act;
	private String punto_venta;
	private int flag_registrado;
	private String ocupacion;
	private String cant_reg;
	private String flag_email;
	private String motivo_registro;
	private String funcion;
	private String cargo;
	private String lugar_nac;
	
	public String getFlag_email() {
		return flag_email;
	}
	public void setFlag_email(String flag_email) {
		this.flag_email = flag_email;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getCuenta() {
		return cuenta;
	}
	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}
	public String getModalidad() {
		return modalidad;
	}
	public void setModalidad(String modalidad) {
		this.modalidad = modalidad;
	}
	public String getSegmento() {
		return segmento;
	}
	public void setSegmento(String segmento) {
		this.segmento = segmento;
	}
	public String getRol_contacto() {
		return rol_contacto;
	}
	public void setRol_contacto(String rol_contacto) {
		this.rol_contacto = rol_contacto;
	}
	public String getEstado_contacto() {
		return estado_contacto;
	}
	public void setEstado_contacto(String estado_contacto) {
		this.estado_contacto = estado_contacto;
	}
	public String getEstado_contrato() {
		return estado_contrato;
	}
	public void setEstado_contrato(String estado_contrato) {
		this.estado_contrato = estado_contrato;
	}
	public String getEstado_site() {
		return estado_site;
	}
	public void setEstado_site(String estado_site) {
		this.estado_site = estado_site;
	}
	public String getS_nombre() {
		return s_nombre;
	}
	public void setS_nombre(String s_nombre) {
		this.s_nombre = s_nombre;
	}
	public String getS_apellidos() {
		return s_apellidos;
	}
	public void setS_apellidos(String s_apellidos) {
		this.s_apellidos = s_apellidos;
	}
	public String getNombres() {
		return nombres;
	}
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getDomicilio() {
		return domicilio;
	}
	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}
	public String getUrbanizacion() {
		return urbanizacion;
	}
	public void setUrbanizacion(String urbanizacion) {
		this.urbanizacion = urbanizacion;
	}
	public String getReferencia() {
		return referencia;
	}
	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}
	public String getCiudad() {
		return ciudad;
	}
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	public String getDistrito() {
		return distrito;
	}
	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelef_referencia() {
		return telef_referencia;
	}
	public void setTelef_referencia(String telef_referencia) {
		this.telef_referencia = telef_referencia;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public String getEstado_civil() {
		return estado_civil;
	}
	public void setEstado_civil(String estado_civil) {
		this.estado_civil = estado_civil;
	}
	public String getTipo_doc() {
		return tipo_doc;
	}
	public void setTipo_doc(String tipo_doc) {
		this.tipo_doc = tipo_doc;
	}
	public String getNro_doc() {
		return nro_doc;
	}
	public void setNro_doc(String nro_doc) {
		this.nro_doc = nro_doc;
	}
	public String getPunto_venta() {
		return punto_venta;
	}
	public void setPunto_venta(String punto_venta) {
		this.punto_venta = punto_venta;
	}
	public String getOcupacion() {
		return ocupacion;
	}
	public void setOcupacion(String ocupacion) {
		this.ocupacion = ocupacion;
	}
	public String getCant_reg() {
		return cant_reg;
	}
	public void setCant_reg(String cant_reg) {
		this.cant_reg = cant_reg;
	}
	public String getMotivo_registro() {
		return motivo_registro;
	}
	public void setMotivo_registro(String motivo_registro) {
		this.motivo_registro = motivo_registro;
	}
	public String getFuncion() {
		return funcion;
	}
	public void setFuncion(String funcion) {
		this.funcion = funcion;
	}
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	public String getLugar_nac() {
		return lugar_nac;
	}
	public void setLugar_nac(String lugar_nac) {
		this.lugar_nac = lugar_nac;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getObjid_contacto() {
		return objid_contacto;
	}
	public void setObjid_contacto(String i) {
		this.objid_contacto = i;
	}
	public String getObjid_site() {
		return objid_site;
	}
	public void setObjid_site(String objid_site) {
		this.objid_site = objid_site;
	}
	public Date getFecha_nac() {
		return fecha_nac;
	}
	public void setFecha_nac(Date fecha_nac) {
		this.fecha_nac = fecha_nac;
	}
	public Date getFecha_act() {
		return fecha_act;
	}
	public void setFecha_act(Date fecha_act) {
		this.fecha_act = fecha_act;
	}
	public int getFlag_registrado() {
		return flag_registrado;
	}
	public void setFlag_registrado(int flag_registrado) {
		this.flag_registrado = flag_registrado;
	}
	
		
}
