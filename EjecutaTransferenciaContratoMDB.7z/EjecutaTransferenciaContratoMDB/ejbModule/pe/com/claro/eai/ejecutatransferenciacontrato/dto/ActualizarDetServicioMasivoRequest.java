package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

public class ActualizarDetServicioMasivoRequest {

	private String FechaProceso;
	private int serviCod;
	private int idEstado;
	private String lineaLogeo;
	private String estadoProgramacion;
	public String getFechaProceso() {
		return FechaProceso;
	}
	public void setFechaProceso(String fechaProceso) {
		FechaProceso = fechaProceso;
	}
	public int getServiCod() {
		return serviCod;
	}
	public void setServiCod(int serviCod) {
		this.serviCod = serviCod;
	}
	public int getIdEstado() {
		return idEstado;
	}
	public void setIdEstado(int idEstado) {
		this.idEstado = idEstado;
	}
	public String getLineaLogeo() {
		return lineaLogeo;
	}
	public void setLineaLogeo(String lineaLogeo) {
		this.lineaLogeo = lineaLogeo;
	}
	public String getEstadoProgramacion() {
		return estadoProgramacion;
	}
	public void setEstadoProgramacion(String estadoProgramacion) {
		this.estadoProgramacion = estadoProgramacion;
	}
	
	
}
