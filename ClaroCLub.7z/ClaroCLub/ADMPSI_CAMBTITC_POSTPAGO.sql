PROCEDURE ADMPSI_CAMBTITC (K_FECHAOPER IN  DATE,
                           K_CODERROR OUT  NUMBER,
                           K_DESCERROR OUT VARCHAR2,
                           K_NUMREGTOT OUT NUMBER,
                           K_NUMREGPRO OUT NUMBER,
                           K_NUMREGERR OUT NUMBER)
IS
        --****************************************************************
        -- Nombre SP           :  ADMPSI_CAMBTITC
        -- Prop�sito           :  Actualizacion de los saldos de puntos por cambio de Titularidad
        --
        -- Input               :  K_FECHAOPER
        --
        -- Output              :  K_CODERROR Codigo de Error o Exito
        --                        K_DESCERROR Descripcion del Error (si se presento)
        --
        -- Fec Creaci�n        :  14/09/2010
        -- Fec Actualizaci�n   :
        --****************************************************************
        V_REGCLI       NUMBER;
        C_PUNTOS       NUMBER;
        V_CODCONCEPTO  VARCHAR2(2);
        V_IDKARDEX     NUMBER;
        C_CODCLIENTEIB NUMBER;
        C_TIPODOC      VARCHAR2(20);
        C_NUMDOC       VARCHAR2(20);
        C_NOMBRE_CLI   VARCHAR2(80);
        C_APELLIDO     VARCHAR2(80);
        C_SEXO         CHAR(1);
        C_EST_CIVIL    VARCHAR2(20);
        C_CODCLIENTE   VARCHAR2(40);
        C_EMAIL        VARCHAR2(80);
        C_PROV         VARCHAR2(30);
        C_DEPA         VARCHAR2(40);
        C_DISTR        VARCHAR2(200);
        C_FEC_ACT      DATE;
        C_CICL_FACT    VARCHAR2(2);
        C_NOMARCHIVO   VARCHAR2(150);
        C_FECOPER      DATE;
        V_IDSALDO      NUMBER;
        V_SALDO_CC     NUMBER;
        V_SALDO_CI     NUMBER;
        V_SALDO_ALMAC  NUMBER;
        V_TIPO_PUNTO   CHAR (1);
        V_COD_SALDO    VARCHAR(40);
        V_COD_NUEVO    NUMBER;
        V_COD_CLINUE   VARCHAR(40);
        V_REG          NUMBER;
        V_COD_ERROR    NUMBER;
        /*CUPONERAVIRTUAL - JCGT INI*/
        C_CODERROR  NUMBER;
        C_DESCERROR VARCHAR2(200);
        K_TIPODOC   VARCHAR2(20);
        K_NUMDOC    VARCHAR2(20);
        /*CUPONERAVIRTUAL - JCGT FIN*/
        CURSOR CAMBIO_TITULARIDAD IS
                SELECT
                        C.ADMPV_TIPO_DOC ,
                        C.ADMPV_NUM_DOC  ,
                        C.ADMPV_NOM_CLI  ,
                        C.ADMPV_APE_CLI  ,
                        C.ADMPC_SEXO     ,
                        C.ADMPV_EST_CIVIL,
                        C.ADMPV_COD_CLI  ,
                        C.ADMPV_EMAIL    ,
                        C.ADMPV_PROV     ,
                        C.ADMPV_DEPA     ,
                        C.ADMPV_DIST     ,
                        C.ADMPD_FEC_ACT  ,
                        C.ADMPV_CICL_FACT,
                        C.ADMPV_NOM_ARCH ,
                        C.ADMPD_FEC_OPER
                FROM
                        PCLUB.admpt_tmp_cmbtit_cc C
                WHERE
                        ADMPD_FEC_OPER=K_FECHAOPER
                AND     (
                                ADMPV_MSJE_ERROR IS NULL
                        OR      ADMPV_MSJE_ERROR       ='');
        
        CURSOR CUR_VALIDA_SALKARDEX IS
                SELECT
                        C.ADMPV_COD_CLI
                FROM
                        PCLUB.admpt_tmp_cmbtit_cc C
                WHERE
                        ADMPD_FEC_OPER=K_FECHAOPER
                AND     (
                                ADMPV_MSJE_ERROR IS NULL
                        OR      ADMPV_MSJE_ERROR       ='');

BEGIN
        -- Solo podemos validar si el cliente existe
        UPDATE
                PCLUB.admpt_tmp_cmbtit_cc
        SET
                ADMPC_COD_ERROR  = '12',
                ADMPV_MSJE_ERROR = 'El codigo de cliente es obligatorio.'
        WHERE
                ADMPV_COD_CLI       = ''
        OR      ADMPV_COD_CLI IS NULL;
        
        -- Solo podemos validar si el cliente existe
        /*UPDATE PCLUB.admpt_tmp_cmbtit_cc
        SET ADMPC_COD_ERROR = '16',
        ADMPV_MSJE_ERROR = 'El cliente no existe, no se le puede cambiar el Titular.'
        WHERE ADMPV_COD_CLI NOT IN (SELECT ADMPV_COD_CLI FROM PCLUB.ADMPT_CLIENTE);*/
        UPDATE
                PCLUB.admpt_tmp_cmbtit_cc TC
        SET
                ADMPC_COD_ERROR  = '16',
                ADMPV_MSJE_ERROR = 'El cliente no existe, no se le puede cambiar el Titular.'
        WHERE
                NOT EXISTS
                (
                        SELECT
                                1
                        FROM
                                PCLUB.ADMPT_CLIENTE C
                        WHERE
                                C.ADMPV_COD_CLI=TC.ADMPV_COD_CLI);
        
        /*JCGT SD27112012*/
        UPDATE
                PCLUB.admpt_tmp_cmbtit_cc TC
        SET
                ADMPC_COD_ERROR  = '17',
                ADMPV_MSJE_ERROR = 'El cliente tiene saldo negativo.'
        WHERE
                EXISTS
                (
                        SELECT
                                1
                        FROM
                                ADMPT_SALDOS_CLIENTE C
                        WHERE
                                C.ADMPV_COD_CLI =TC.ADMPV_COD_CLI
                        AND     C.ADMPN_SALDO_CC<0);
        
        UPDATE
                PCLUB.admpt_tmp_cmbtit_cc TC
        SET
                ADMPC_COD_ERROR  = '6',
                ADMPV_MSJE_ERROR = 'El cliente Actual esta de Baja, no se puede cambiar el Titular'
        WHERE
                EXISTS
                (
                        SELECT
                                1
                        FROM
                                PCLUB.ADMPT_CLIENTE C
                        WHERE
                                C.ADMPV_COD_CLI=TC.ADMPV_COD_CLI
                        AND     ADMPC_ESTADO   ='B' );
        
        /* Actualizar admpt_tmp_cmbtit_cc por Desalineacion de Puntos*/
        OPEN CUR_VALIDA_SALKARDEX;
        FETCH
                CUR_VALIDA_SALKARDEX
        INTO
                C_CODCLIENTE;
        
        WHILE CUR_VALIDA_SALKARDEX %FOUND
        LOOP
                PCLUB.PKG_CC_TRANSACCION.ADMPSS_VALIDASALDOKDX(C_CODCLIENTE, '2', V_COD_ERROR);
                IF V_COD_ERROR = 1 THEN
                        UPDATE
                                PCLUB.admpt_tmp_cmbtit_cc
                        SET
                                ADMPC_COD_ERROR  = '33',
                                ADMPV_MSJE_ERROR = 'Los Puntos No se encuentran Alineados'
                        WHERE
                                ADMPV_COD_CLI =C_CODCLIENTE;
                
                END IF;
                FETCH
                        CUR_VALIDA_SALKARDEX
                INTO
                        C_CODCLIENTE;
        
        END LOOP;
        COMMIT;
        ---Asignar el codigo de concepto ------
        BEGIN
                SELECT
                        NVL(ADMPV_COD_CPTO,NULL)
                INTO
                        V_CODCONCEPTO
                FROM
                        PCLUB.ADMPT_CONCEPTO
                WHERE
                        UPPER(ADMPV_DESC) LIKE 'CAMBIO TITULARIDAD';
        
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
                V_CODCONCEPTO := NULL;
        END;
        OPEN CAMBIO_TITULARIDAD;
        FETCH
                CAMBIO_TITULARIDAD
        INTO
                C_TIPODOC   ,
                C_NUMDOC    ,
                C_NOMBRE_CLI,
                C_APELLIDO  ,
                C_SEXO      ,
                C_EST_CIVIL ,
                C_CODCLIENTE,
                C_EMAIL     ,
                C_PROV      ,
                C_DEPA      ,
                C_DISTR     ,
                C_FEC_ACT   ,
                C_CICL_FACT ,
                C_NOMARCHIVO,
                C_FECOPER;
        
        WHILE CAMBIO_TITULARIDAD %FOUND
        LOOP
                V_REGCLI :=0;
                C_PUNTOS :=0;
                SELECT
                        COUNT(1)
                INTO
                        V_REGCLI
                FROM
                        PCLUB.admpt_aux_cmbtit_cc D
                WHERE
                        D.ADMPV_TIPO_DOC        = C_TIPODOC
                AND     D.ADMPV_NUM_DOC         = C_NUMDOC
                AND     D.ADMPV_NOM_CLI         = C_NOMBRE_CLI
                AND     D.ADMPV_APE_CLI         = C_APELLIDO
                AND     D.ADMPC_SEXO            = C_SEXO
                AND     D.ADMPV_EST_CIVIL       = C_EST_CIVIL
                AND     D.ADMPV_COD_CLI         = C_CODCLIENTE
                AND     D.ADMPV_EMAIL           = C_EMAIL
                AND     D.ADMPV_PROV            = C_PROV
                AND     D.ADMPV_DEPA            = C_DEPA
                AND     D.ADMPV_DIST            = C_DISTR
                AND     D.ADMPD_FEC_ACT         = C_FEC_ACT
                AND     D.ADMPV_CICL_FACT       =C_CICL_FACT
                AND     D.ADMPD_FEC_OPER        = C_FECOPER
                AND     NVL(ADMPV_NOM_ARCH,NULL)=C_NOMARCHIVO;
                
                IF (V_REGCLI=0) THEN
                        /* Se obtiene el saldo del cliente cc*/
                        BEGIN
                                V_SALDO_CC := 0.00;
                                SELECT
                                        NVL(S.ADMPN_SALDO_CC,NULL)
                                INTO
                                        V_SALDO_CC
                                FROM
                                        PCLUB.ADMPT_SALDOS_CLIENTE S
                                WHERE
                                        S.ADMPV_COD_CLI = C_CODCLIENTE;
                        
                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                                V_SALDO_CC := 0.00;
                        END;
                        IF V_SALDO_CC < 0 THEN
                                V_SALDO_ALMAC := V_SALDO_CC;
                                V_TIPO_PUNTO  := 'E';
                        ELSE
                                V_SALDO_ALMAC := V_SALDO_CC * -1;
                                V_TIPO_PUNTO  := 'S';
                        END IF;
                        /* Se obtiene el codigo del cliente IB si es diferente a nulo*/
                        BEGIN
                                SELECT
                                        D.ADMPN_COD_CLI_IB
                                INTO
                                        C_CODCLIENTEIB
                                FROM
                                        PCLUB.ADMPT_SALDOS_CLIENTE D
                                WHERE
                                        D.ADMPN_SALDO_IB IS NOT NULL
                                AND     D.ADMPV_COD_CLI            = C_CODCLIENTE;
                        
                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                                C_CODCLIENTEIB := NULL;
                        END;
                        /* Se obtiene el saldo del cliente IB*/
                        IF C_CODCLIENTEIB IS NOT NULL
                                AND
                                C_CODCLIENTEIB > 0 THEN
                                BEGIN
                                        SELECT
                                                NVL(S.ADMPN_SALDO_IB,NULL)
                                        INTO
                                                V_SALDO_CI
                                        FROM
                                                PCLUB.ADMPT_SALDOS_CLIENTE S
                                        WHERE
                                                S.ADMPN_COD_CLI_IB = C_CODCLIENTEIB;
                                
                                EXCEPTION
                                WHEN NO_DATA_FOUND THEN
                                        V_SALDO_CI := NULL;
                                END;
                                /*Con el cliente IB obtenido actualizar la tabla de ADMPT_CLIENTEIB en los campos ADMPV_COD_CLI y ADMPV_NUM_LINEA con nulos.*/
                                UPDATE
                                        PCLUB.ADMPT_CLIENTEIB F
                                SET
                                        F.ADMPV_COD_CLI   =NULL,
                                        F.ADMPV_NUM_LINEA = NULL
                                WHERE
                                        F.ADMPN_COD_CLI_IB=C_CODCLIENTEIB;
                                
                                /*Actualizar la tabla de saldo en los campos ADMPN_COD_CLI_IB, ADMPN_SALDO_IB y ADMPC_ESTPTO_IB, con nulo, cero y nulo respectivamente*/
                                UPDATE
                                        PCLUB.ADMPT_SALDOS_CLIENTE d
                                SET
                                        D.ADMPN_COD_CLI_IB= NULL,
                                        D.ADMPN_SALDO_IB  =0    ,
                                        D.ADMPC_ESTPTO_IB =NULL
                                WHERE
                                        D.ADMPN_COD_CLI_IB=C_CODCLIENTEIB;
                                
                                /* INSERTAMOS EN LA TABLA SALDO_CLIENTE*/
                                SELECT
                                        PCLUB.admpt_sld_cl_sq.NEXTVAL
                                INTO
                                        V_IDSALDO
                                FROM
                                        DUAL;
                                
                                INSERT INTO
                                        PCLUB.ADMPT_SALDOS_CLIENTE
                                        (
                                                ADMPN_ID_SALDO  ,
                                                ADMPV_COD_CLI   ,
                                                ADMPN_COD_CLI_IB,
                                                ADMPN_SALDO_CC  ,
                                                ADMPN_SALDO_IB  ,
                                                ADMPC_ESTPTO_CC ,
                                                ADMPC_ESTPTO_IB
                                        )
                                        VALUES
                                        (
                                                V_IDSALDO     ,
                                                NULL          ,
                                                C_CODCLIENTEIB,
                                                0.00          ,
                                                V_SALDO_CI    ,
                                                NULL          ,
                                                'A'
                                        );
                                
                                -- Los puntos IB que tienen aun saldo deben romper la relacion con el cliente Claro
                                UPDATE
                                        PCLUB.ADMPT_KARDEX
                                SET
                                        ADMPV_COD_CLI = NULL
                                WHERE
                                        ADMPN_COD_CLI_IB = C_CODCLIENTEIB
                                AND     ADMPC_TPO_PUNTO  = 'I'
                                AND     ADMPN_SLD_PUNTO  > 0
                                AND     ADMPC_TPO_OPER   = 'E';
                                
                                -- Los puntos CC en el kardex debe romperse la relaci�n con los puntos IB
                                UPDATE
                                        PCLUB.ADMPT_KARDEX
                                SET
                                        ADMPN_COD_CLI_IB = NULL
                                WHERE
                                        ADMPV_COD_CLI    = C_CODCLIENTE
                                AND     ADMPC_TPO_PUNTO <> 'I';
                        
                        END IF;
                        IF V_SALDO_CC <> 0 THEN
                                /* genera secuencial de kardex*/
                                SELECT
                                        PCLUB.admpt_kardex_sq.NEXTVAL
                                INTO
                                        V_IDKARDEX
                                FROM
                                        DUAL;
                                
                                INSERT INTO
                                        PCLUB.ADMPT_KARDEX
                                        (
                                                ADMPN_ID_KARDEX ,
                                                ADMPN_COD_CLI_IB,
                                                ADMPV_COD_CLI   ,
                                                ADMPV_COD_CPTO  ,
                                                ADMPD_FEC_TRANS ,
                                                ADMPN_PUNTOS    ,
                                                ADMPV_NOM_ARCH  ,
                                                ADMPC_TPO_OPER  ,
                                                ADMPC_TPO_PUNTO ,
                                                ADMPN_SLD_PUNTO ,
                                                ADMPC_ESTADO
                                        )
                                        VALUES
                                        (
                                                V_IDKARDEX                                         ,
                                                NULL                                               ,
                                                C_CODCLIENTE                                       ,
                                                V_CODCONCEPTO                                      ,
                                                TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY'),
                                                V_SALDO_ALMAC                                      ,
                                                C_NOMARCHIVO                                       ,
                                                V_TIPO_PUNTO                                       ,
                                                'C'                                                ,
                                                C_PUNTOS                                           ,
                                                'A'
                                        );
                        
                        END IF;
                        -- ACTUALIZAMOS EL SALDO DE LOS MOVIMIENTOS DE ENTRADA DEL KARDEX A 0 SEGUN CODIGO DEL CLIENTE Y EL TIPO DE CLIENTE (NO AFECTARA A INTERBANK)
                        UPDATE
                                PCLUB.ADMPT_KARDEX
                        SET
                                ADMPN_SLD_PUNTO = C_PUNTOS
                        WHERE
                                ADMPV_COD_CLI = C_CODCLIENTE
                        AND     ADMPC_TPO_PUNTO IN ('C',
                                                    'L')
                        AND     ADMPN_SLD_PUNTO > 0
                        AND     ADMPC_TPO_OPER  = 'E';
                        
                        -- ACTUALIZAR EL SALDO CC DE LA TABLA SEGUN EL CODIGO DEL CLIENTE
                        UPDATE
                                PCLUB.ADMPT_SALDOS_CLIENTE S
                        SET
                                S.ADMPN_SALDO_CC = C_PUNTOS
                        WHERE
                                ADMPV_COD_CLI = C_CODCLIENTE;
                        
                        -- Insertamos en la auxiliar para los reprocesos
                        INSERT INTO
                                PCLUB.ADMPT_AUX_CMBTIT_CC cc
                                (
                                        cc.admpv_tipo_doc ,
                                        cc.admpv_num_doc  ,
                                        cc.admpv_nom_cli  ,
                                        cc.admpv_ape_cli  ,
                                        cc.admpc_sexo     ,
                                        cc.admpv_est_civil,
                                        cc.admpv_email    ,
                                        cc.admpv_prov     ,
                                        cc.admpv_depa     ,
                                        cc.admpv_dist     ,
                                        cc.admpd_fec_act  ,
                                        cc.admpv_cicl_fact,
                                        cc.admpd_fec_oper ,
                                        cc.admpv_cod_cli  ,
                                        cc.admpv_nom_arch
                                )
                                VALUES
                                (
                                        C_TIPODOC   ,
                                        C_NUMDOC    ,
                                        C_NOMBRE_CLI,
                                        C_APELLIDO  ,
                                        C_SEXO      ,
                                        C_EST_CIVIL ,
                                        C_EMAIL     ,
                                        C_PROV      ,
                                        C_DEPA      ,
                                        C_DISTR     ,
                                        C_FEC_ACT   ,
                                        C_CICL_FACT ,
                                        C_FECOPER   ,
                                        C_CODCLIENTE,
                                        C_NOMARCHIVO
                                );
                        
                        /*---------------------------Ahora obtenemos el nuevo c�digo del cliente origen----------------------------*/
                        V_COD_NUEVO  := 1;
                        V_COD_CLINUE := '';
                        WHILE V_COD_NUEVO > 0
                        LOOP
                                V_COD_CLINUE := TRIM(C_CODCLIENTE)
                                || '-'
                                || TO_CHAR(V_COD_NUEVO);
                                V_REG := 0;
                                BEGIN
                                        SELECT
                                                COUNT(*)
                                        INTO
                                                V_REG
                                        FROM
                                                PCLUB.ADMPT_CLIENTE
                                        WHERE
                                                ADMPV_COD_CLI = V_COD_CLINUE;
                                
                                EXCEPTION
                                WHEN NO_DATA_FOUND THEN
                                        V_REG := 0;
                                END;
                                IF V_REG > 0 THEN
                                        V_COD_NUEVO := V_COD_NUEVO + 1;
                                ELSE
                                        V_COD_NUEVO := 0;
                                END IF;
                        END LOOP;
                        /*---------------------------Fin de Cliente Origen----------------------------*/
                        -- Debido a la FK primero se debe insertar el registro
                        INSERT INTO
                                PCLUB.ADMPT_CLIENTE
                                (
                                        ADMPV_COD_CLI
                                )
                                VALUES
                                (
                                        '999999999999999999999'
                                );
                        
                        UPDATE
                                PCLUB.ADMPT_CANJE
                        SET
                                ADMPV_COD_CLI = '999999999999999999999'
                        WHERE
                                ADMPV_COD_CLI = C_CODCLIENTE;
                        
                        -- Ahora actualizamos los movimientos, saldos y c�digo de cliente con el c�digo obtenido
                        UPDATE
                                PCLUB.ADMPT_KARDEX
                        SET
                                ADMPV_COD_CLI = V_COD_CLINUE
                        WHERE
                                ADMPV_COD_CLI = C_CODCLIENTE;
                        
                        UPDATE
                                PCLUB.ADMPT_SALDOS_CLIENTE
                        SET
                                ADMPV_COD_CLI  = V_COD_CLINUE,
                                ADMPN_SALDO_CC = 0           ,
                                ADMPC_ESTPTO_CC='B'
                        WHERE
                                ADMPV_COD_CLI = C_CODCLIENTE;
                        
                        UPDATE
                                PCLUB.ADMPT_CLIENTE
                        SET
                                ADMPV_COD_CLI = V_COD_CLINUE,
                                ADMPC_ESTADO  = 'B'         ,
                                ADMPV_USU_MOD = 'USRCTITPOST'
                        WHERE
                                ADMPV_COD_CLI = C_CODCLIENTE;
                        
                        UPDATE
                                PCLUB.ADMPT_CANJE
                        SET
                                ADMPV_COD_CLI = V_COD_CLINUE
                        WHERE
                                ADMPV_COD_CLI = '999999999999999999999';
                        
                        DELETE
                        FROM
                                PCLUB.ADMPT_CLIENTE
                        WHERE
                                ADMPV_COD_CLI = '999999999999999999999';
                        
                        DELETE
                        FROM
                                PCLUB.ADMPT_CLIENTE
                        WHERE
                                ADMPV_COD_CLI = C_CODCLIENTE;
                        
                        /*ACTUALIZAR LA TABLA DE CLIENTES*/
                        /*-------------------------------------------INSERTAMOS EL NUEVO CLIENTE------------------------------------------*/
                        -- Debemos insertar los clientes en la tabla de Clientes
                        INSERT INTO
                                PCLUB.ADMPT_CLIENTE H
                                (
                                        H.ADMPV_COD_CLI   ,
                                        H.ADMPV_COD_SEGCLI,
                                        H.ADMPN_COD_CATCLI,
                                        H.ADMPV_TIPO_DOC  ,
                                        H.ADMPV_NUM_DOC   ,
                                        H.ADMPV_NOM_CLI   ,
                                        H.ADMPV_APE_CLI   ,
                                        H.ADMPC_SEXO      ,
                                        H.ADMPV_EST_CIVIL ,
                                        H.ADMPV_EMAIL     ,
                                        H.ADMPV_PROV      ,
                                        H.ADMPV_DEPA      ,
                                        H.ADMPV_DIST      ,
                                        H.ADMPD_FEC_ACTIV ,
                                        H.ADMPV_CICL_FACT ,
                                        H.ADMPC_ESTADO    ,
                                        H.ADMPV_COD_TPOCL ,
                                        ADMPV_USU_REG
                                )
                                VALUES
                                (
                                        C_CODCLIENTE                                           ,
                                        NULL                                                   ,
                                        '2'                                                    ,
                                        C_TIPODOC                                              ,
                                        C_NUMDOC                                               ,
                                        C_NOMBRE_CLI                                           ,
                                        C_APELLIDO                                             ,
                                        C_SEXO                                                 ,
                                        C_EST_CIVIL                                            ,
                                        C_EMAIL                                                ,
                                        C_PROV                                                 ,
                                        C_DEPA                                                 ,
                                        C_DISTR                                                ,
                                        TO_DATE(TO_CHAR(C_FEC_ACT, 'DD/MM/YYYY'), 'DD/MM/YYYY'),
                                        C_CICL_FACT                                            ,
                                        'A'                                                    ,
                                        '2'                                                    ,
                                        'USRCTITPOST'
                                );
                        
                        BEGIN
                                SELECT
                                        ADMPV_COD_CLI
                                INTO
                                        V_COD_SALDO
                                FROM
                                        PCLUB.ADMPT_SALDOS_CLIENTE
                                WHERE
                                        ADMPV_COD_CLI = C_CODCLIENTE;
                        
                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                                /**Generar secuencial de Saldo*/
                                SELECT
                                        PCLUB.admpt_sld_cl_sq.nextval
                                INTO
                                        V_IDSALDO
                                FROM
                                        DUAL;
                                
                                INSERT INTO
                                        PCLUB.ADMPT_SALDOS_CLIENTE
                                        (
                                                admpn_id_saldo  ,
                                                admpv_cod_cli   ,
                                                admpn_cod_cli_ib,
                                                admpn_saldo_cc  ,
                                                admpn_saldo_ib  ,
                                                admpc_estpto_cc ,
                                                admpc_estpto_ib
                                        )
                                        VALUES
                                        (
                                                V_IDSALDO   ,
                                                C_CODCLIENTE,
                                                NULL        ,
                                                0.00        ,
                                                0.00        ,
                                                'A'         ,
                                                NULL
                                        );
                        
                        END;
                        /*--------------------------------------------------------------------------------------------------------------------------------*/
                        /*   BEGIN
                        UPDATE PCLUB.admpt_cliente F
                        SET F.ADMPV_TIPO_DOC=C_TIPODOC,
                        F.ADMPV_NUM_DOC=C_NUMDOC,
                        F.ADMPV_NOM_CLI=C_NOMBRE_CLI,
                        F.ADMPV_APE_CLI=C_APELLIDO,
                        F.ADMPC_SEXO=C_SEXO,
                        F.ADMPV_EST_CIVIL=C_EST_CIVIL,
                        F.ADMPV_EMAIL=C_EMAIL,
                        F.ADMPV_PROV=C_PROV,
                        F.ADMPV_DEPA=C_DEPA,
                        F.ADMPV_DIST=C_DISTR,
                        F.ADMPD_FEC_ACTIV=C_FEC_ACT,
                        F.ADMPV_CICL_FACT=C_CICL_FACT
                        WHERE F.ADMPV_COD_CLI=C_CODCLIENTE;
                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN C_CODCLIENTE := null;
                        END;
                        */
                        /*CUPONERAVIRTUAL - JCGT INI*/
                        PCLUB.PKG_CC_CUPONERA.ADMPSI_CAMBIOTITULAR(K_TIPODOC,K_NUMDOC,C_TIPODOC,C_NUMDOC,C_NOMBRE_CLI,C_APELLIDO,C_EMAIL,'CMBTIT', 'USRPOST',C_CODERROR,C_DESCERROR);
                        /*CUPONERAVIRTUAL - JCGT FIN*/
                END IF;
                --COMMIT;
                FETCH
                        CAMBIO_TITULARIDAD
                INTO
                        C_TIPODOC   ,
                        C_NUMDOC    ,
                        C_NOMBRE_CLI,
                        C_APELLIDO  ,
                        C_SEXO      ,
                        C_EST_CIVIL ,
                        C_CODCLIENTE,
                        C_EMAIL     ,
                        C_PROV      ,
                        C_DEPA      ,
                        C_DISTR     ,
                        C_FEC_ACT   ,
                        C_CICL_FACT ,
                        C_NOMARCHIVO,
                        C_FECOPER;
        
        END LOOP;
        -- Obtenemos los registros totales, procesados y con error
        SELECT
                COUNT (1)
        INTO
                K_NUMREGTOT
        FROM
                PCLUB.admpt_tmp_cmbtit_cc
        WHERE
                ADMPD_FEC_OPER=K_FECHAOPER; --TOTALES
        SELECT
                COUNT (1)
        INTO
                K_NUMREGERR
        FROM
                PCLUB.admpt_tmp_cmbtit_cc
        WHERE
                ADMPD_FEC_OPER=K_FECHAOPER
        AND     (
                        admpc_cod_error IS NOT NULL);-- PROCESADOS
        SELECT
                COUNT (1)
        INTO
                K_NUMREGPRO
        FROM
                PCLUB.admpt_aux_cmbtit_cc
        WHERE
                ADMPD_FEC_OPER=K_FECHAOPER; -- CON ERROR
        -- Insertamos de la tabla temporal a la final
        INSERT INTO
                PCLUB.admpt_imp_cmbtit_cc
        SELECT
                PCLUB.ADMPT_CAMBIOTT_SQ.nextval,
                v.admpv_tipo_doc               ,
                v.admpv_num_doc                ,
                v.admpv_nom_cli                ,
                v.admpv_ape_cli                ,
                v.admpc_sexo                   ,
                v.admpv_est_civil              ,
                v.admpv_cod_cli                ,
                v.admpv_email                  ,
                v.admpv_prov                   ,
                v.admpv_depa                   ,
                v.admpv_dist                   ,
                v.admpd_fec_act                ,
                v.admpv_cicl_fact              ,
                v.admpd_fec_oper               ,
                v.admpv_nom_arch               ,
                V.ADMPC_COD_ERROR              ,
                V.ADMPV_MSJE_ERROR             ,
                SYSDATE                        ,
                v.admpn_seq
        FROM
                PCLUB.admpt_tmp_cmbtit_cc v
        WHERE
                V.ADMPD_FEC_OPER=K_FECHAOPER;
        
        -- Eliminamos los registros de la tabla temporal y auxiliar
        DELETE
                PCLUB.admpt_aux_cmbtit_cc
        WHERE
                ADMPD_FEC_OPER=K_FECHAOPER;
        
        DELETE
                PCLUB.admpt_tmp_cmbtit_cc
        WHERE
                ADMPD_FEC_OPER=K_FECHAOPER;
        
        COMMIT;
        K_CODERROR := '0';
        K_DESCERROR:= '';
EXCEPTION
WHEN OTHERS THEN
        K_CODERROR := SQLCODE;
        K_DESCERROR:= SUBSTR(SQLERRM,1,250);
END ADMPSI_CAMBTITC;