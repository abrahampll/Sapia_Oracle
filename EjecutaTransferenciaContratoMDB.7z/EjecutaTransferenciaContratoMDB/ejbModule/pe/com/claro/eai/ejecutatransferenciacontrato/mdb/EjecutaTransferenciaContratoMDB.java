package pe.com.claro.eai.ejecutatransferenciacontrato.mdb;

import javax.ejb.MessageDriven;
import javax.interceptor.Interceptors;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import javax.annotation.Resource;
import javax.ejb.MessageDrivenContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.TransfereciaContratoMessageBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.service.TransferenciaContratoClient;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.Constantes;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.EaiUtil;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.SpringBeanInterceptor;

/**
 * Message-Driven Bean implementation class for: EjecutaTransferenciaContratoMDB
 */
@MessageDriven
@Interceptors(SpringBeanInterceptor.class)
public class EjecutaTransferenciaContratoMDB implements MessageListener {

	private static Logger logger = Logger.getLogger(EjecutaTransferenciaContratoMDB.class.getName());

    @Resource
    private MessageDrivenContext context;
    
	@Autowired
	private TransferenciaContratoClient client;
	
	@Autowired
	private EaiUtil eaiUtil;

	/**
	 * Default constructor.
	 */
	public EjecutaTransferenciaContratoMDB() {
		logger.info("*** 'MDB' [EjecutaTransferenciaContratoMDB] - Inicializado ... ***");
	}

	/**
	 * @see MessageListener#onMessage(Message)
	 */
	public void onMessage(Message message) {
		long tiempoInicio = System.currentTimeMillis();
		String men = "[onMessage] ";
		TransfereciaContratoMessageBean messageBean;
		String msjTx = Constantes.VACIO;

		try {
			if (message instanceof TextMessage) {
				logger.info(men + "tipo de mensaje: [ObjectMessage] ----");

				TextMessage text = (TextMessage) message;
				logger.info("Mensaje recibido: " + text.getText());
				messageBean = (TransfereciaContratoMessageBean)eaiUtil.getJaxBFromXmlText(text.getText(), TransfereciaContratoMessageBean.class);
				String idTransaccionConcat = messageBean.getIdTransacccion();
				msjTx = men +  "[idTx=" + idTransaccionConcat + "] ";
//				if (messageBean == null) {
//					logger.info(men + " El objeto recibido es null");
//					return;
//				}
				logger.info(men + "Datos de entrada: " + eaiUtil.anyObjectToXmlText(messageBean));
				
				if (messageBean.getFlagProceso().equals(Constantes.PROCESARTRANSFERENCIASELECT)) {
					logger.info(msjTx + "Flag: " + messageBean.getFlagProceso());
					logger.info(msjTx + "Ejecutando: " + Constantes.PROCESARTRANSFERENCIA);

					ResponseBean response = client.procesarTransferencia(msjTx, messageBean);
					logger.info(msjTx + "Ejecucion con exito, datos devuelto: " + eaiUtil.anyObjectToXmlText(response));

				} else if (messageBean.getFlagProceso().equals(Constantes.RELANZARTRANSFERENCIASELECT)) {
					logger.info(msjTx + "Flag: " + messageBean.getFlagProceso());
					logger.info(msjTx + "Ejecutando: " + Constantes.RELANZARTRANSFERENCIA);

					client.relanzarTransferencia(msjTx, messageBean);
				} else {
					logger.info(msjTx + "Flag: " + messageBean.getFlagProceso());
					logger.info(msjTx + "Ejecutando: " + Constantes.PROCESONOENCONTRADO);
					return;
				}

			} else {
				logger.info(msjTx + " El objeto recibido es null o no es un ObjectMessage");
			}
		} catch (Exception e) {
			logger.error(msjTx + "Excepcion generada: " + e.getMessage());
			logger.error(msjTx + "Se regresara el JMS message a la cola...");
			context.setRollbackOnly();
		} finally {
			logger.info(msjTx + "=== Fin de la transaccion onMessage para procesar EjecutaTransferenciaContratoMDB");
			logger.info(
					msjTx + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio) + " milisegundos ]");
		}
	}

}
