package pe.com.claro.eai.ejecutatransferenciacontrato.dao;

import java.sql.Types;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import pe.com.claro.eai.ejecutatransferenciacontrato.dao.mapper.CursorProgSqlReturnType;
import pe.com.claro.eai.ejecutatransferenciacontrato.dao.mapper.CursorServproSqlReturnType;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ActualizarDetServicioMasivoRequest;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.BuscarReProcesoBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.CursorBuscarReProceso;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.CursorServpro;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.DetalleMasivo;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPActualizarDetServicioMasivo;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPBuscarDetServicioMasivo;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPBuscarProgramacionesResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPRegistraMigracionResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.Constantes;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.EaiUtil;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.PropertiesExterno;

@Repository
public class TimEaiDaoImpl implements TimEaiDao {

	private final Logger LOGGER = Logger.getLogger(this.getClass().getName());

	@Autowired
	@Qualifier(value = "timeaiDS")
	private DataSource timeaiDS;

	private SimpleJdbcCall objJdbcCall;
	
	@Autowired
	private EaiUtil eaiUtil;

	@Autowired
	private PropertiesExterno propExterno;

	@Override
	public SPBuscarProgramacionesResponseBean buscarProgramaciones(String msgTxId, String idProceso, String serviCod,
			String fechaProg,int limite, String servcEstado) {

		String cadMensaje = msgTxId + "[buscarProgramaciones]";

		LOGGER.info(cadMensaje + "[INICIO] - METODO: [buscarProgramaciones - DAO] ");

		JdbcTemplate objJdbcTemplate = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;
		long tiempoInicio = System.currentTimeMillis();
		SPBuscarProgramacionesResponseBean response = new SPBuscarProgramacionesResponseBean();
		try {

			this.timeaiDS.setLoginTimeout(this.propExterno.dbTimeaiTimeoutCONNECTION);
			LOGGER.info(
					cadMensaje + "DATA SOURCE (JNDI): [" + this.propExterno.dbTimeaiJNDI + Constantes.CLOSECORCHETE);

			OWNER = this.propExterno.dbTimeaiOWNER;
			PAQUETE = this.propExterno.dbTIMEAIPKGSERVMASIVO;
			PROCEDURE = this.propExterno.spTIMEAISPBUSCARPROGRAMACIONES;

			LOGGER.info(cadMensaje + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO + PROCEDURE
					+ Constantes.CLOSECORCHETE);

			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue(Constantes.PIDPROCESO, idProceso, Types.VARCHAR)
					.addValue(Constantes.PSERVICOD, serviCod, Types.VARCHAR)
					.addValue(Constantes.PFECHAPROG, fechaProg, Types.VARCHAR)
					.addValue(Constantes.PLIMITE, limite, Types.NUMERIC)
					.addValue(Constantes.PSERVCESTADO, servcEstado, Types.VARCHAR);

			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_id_proceso: [" + idProceso + Constantes.CLOSECORCHETE);
			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_servi_cod: [" + serviCod + Constantes.CLOSECORCHETE);
			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_fecha_prog: [" + fechaProg + Constantes.CLOSECORCHETE);
			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "PLIMITE: [" + limite + Constantes.CLOSECORCHETE);
			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_servc_estado: [" + servcEstado + Constantes.CLOSECORCHETE);

			this.objJdbcCall = new SimpleJdbcCall(this.timeaiDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbTimeaiTimeoutEXECUTION);

			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(new SqlParameter(Constantes.PIDPROCESO, Types.VARCHAR),
							new SqlParameter(Constantes.PSERVICOD, Types.VARCHAR),
							new SqlParameter(Constantes.PFECHAPROG, Types.VARCHAR),
							new SqlParameter(Constantes.PLIMITE, Types.NUMERIC),
							new SqlParameter(Constantes.PSERVCESTADO, Types.VARCHAR),
							new SqlOutParameter(Constantes.PCURSORSERVPRO, oracle.jdbc.OracleTypes.CURSOR, null,
									new CursorServproSqlReturnType()),
							new SqlOutParameter(Constantes.PCODERROR, Types.VARCHAR),
							new SqlOutParameter(Constantes.PMENERROR, Types.VARCHAR))
					.execute(objParametrosIN);
			LOGGER.info(cadMensaje + "PARAMETROS [OUPUT]: ");

			response.setCodError(objParametrosOUT.get(Constantes.PCODERROR).toString());
			LOGGER.info(cadMensaje + "p_cod_error: [" + response.getCodError() + Constantes.CLOSECORCHETE);
			response.setMenError(objParametrosOUT.get(Constantes.PMENERROR).toString());
			LOGGER.info(cadMensaje + "p_men_error: [" + response.getMenError() + Constantes.CLOSECORCHETE);
			response.setListaServpro((List<CursorServpro>) objParametrosOUT.get(Constantes.PCURSORSERVPRO));
			if (response.getListaServpro() != null)
				LOGGER.info(cadMensaje + "p_cursorservpro [TAMANO]: [" + response.getListaServpro().size()
						+ Constantes.CLOSECORCHETE);
		} catch (Exception e) {
			response = null;
			LOGGER.error(cadMensaje + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE);
		} finally {
			LOGGER.info(cadMensaje + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(cadMensaje + "[FIN] - METODO: [buscarProgramaciones - DAO] ");
		}
		return response;
	}

	@Override
	public BuscarReProcesoBean buscarReProceso(String msgTxId, String serviCod, String servFechaEjec) {
		String cadMensaje = msgTxId + "[buscarProgramaciones]";

		LOGGER.info(cadMensaje + "[INICIO] - METODO: [buscarReProceso - DAO] ");

		JdbcTemplate objJdbcTemplate = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;
		long tiempoInicio = System.currentTimeMillis();
		BuscarReProcesoBean response = new BuscarReProcesoBean();
		try {

			this.timeaiDS.setLoginTimeout(this.propExterno.dbTimeaiTimeoutCONNECTION);
			LOGGER.info(cadMensaje + "DATA SOURCE (JNDI): [" + this.propExterno.dbTimeaiJNDI + Constantes.CLOSECORCHETE);

			OWNER = this.propExterno.dbTimeaiOWNER;
			PAQUETE = this.propExterno.dbTIMEAIPKGSERVMASIVO;
			PROCEDURE = this.propExterno.spTIMEAISPBUSCARREPROCESO;

			LOGGER.info(cadMensaje + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO + PROCEDURE
					+ Constantes.CLOSECORCHETE);

			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue(Constantes.RELANZAR_PSERVICOD, serviCod, Types.VARCHAR)
					.addValue(Constantes.RELANZAR_PSERVFECHAEJEC, servFechaEjec, Types.VARCHAR);

			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_servi_cod: [" + serviCod + Constantes.CLOSECORCHETE);
			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_servd_fecha_ejec: [" + servFechaEjec
					+ Constantes.CLOSECORCHETE);

			this.objJdbcCall = new SimpleJdbcCall(this.timeaiDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbTimeaiTimeoutEXECUTION);

			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(new SqlParameter(Constantes.RELANZAR_PSERVICOD, Types.VARCHAR),
							new SqlParameter(Constantes.RELANZAR_PSERVFECHAEJEC, Types.VARCHAR),
							new SqlOutParameter(Constantes.RELANZAR_PRESULTADO, Types.VARCHAR),
							new SqlOutParameter(Constantes.RELANZAR_PMENSAJE, Types.VARCHAR),
							new SqlOutParameter(Constantes.RELANZAR_PCURSORPROG, oracle.jdbc.OracleTypes.CURSOR, null,
									new CursorProgSqlReturnType()))
					.execute(objParametrosIN);
			LOGGER.info(cadMensaje + "PARAMETROS [OUPUT]: ");

			response.setResultado(objParametrosOUT.get(Constantes.RELANZAR_PRESULTADO).toString());
			LOGGER.info(cadMensaje + "p_resultado: [" + response.getResultado() + Constantes.CLOSECORCHETE);
			response.setMensaje(objParametrosOUT.get(Constantes.RELANZAR_PMENSAJE).toString());
			LOGGER.info(cadMensaje + "p_mensaje: [" + response.getMensaje() + Constantes.CLOSECORCHETE);
			response.setCursorSalida(
					(List<CursorBuscarReProceso>) objParametrosOUT.get(Constantes.RELANZAR_PCURSORPROG));
			if (response.getCursorSalida() != null) {
				LOGGER.info(cadMensaje + "p_cursor_prog [TAMANO]: [" + response.getCursorSalida().size()
						+ Constantes.CLOSECORCHETE);

				for (CursorBuscarReProceso cursor : response.getCursorSalida()) {

					LOGGER.info(cadMensaje + "idProceso: " + cursor.getIdProceso());
					LOGGER.info(cadMensaje + "fechaEjecucion: " + cursor.getFechaEjecucion());
					LOGGER.info(cadMensaje + "estadoProceso: " + cursor.getEstadoProceso());
					LOGGER.info(cadMensaje + "reintento: " + cursor.getReintento());
					LOGGER.info(cadMensaje + "serviCod: " + cursor.getServiCod());
					LOGGER.info(cadMensaje + "servvXmlentrada: " + cursor.getServvXmlEntrada());
				}

			}
		} catch (Exception e) {
			response = null;
			LOGGER.error(cadMensaje + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE);
		} finally {
			LOGGER.info(cadMensaje + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(cadMensaje + "[FIN] - METODO: [buscarReproceso - DAO] ");
		}
		return response;
	}

	@Override
	public ResponseBean registrarEstadoMigracion(String msgTxId, String p_id_proceso, String p_co_id, String p_msisdn,
			String p_estado, String p_codigo_error, String p_mensaje_error) throws Exception {

		String msgMet = msgTxId + "[registrarEstadoMigracion]";

		LOGGER.info(msgMet + "[INICIO] - METODO: [registrarEstadoMigracion - DAO] ");

		JdbcTemplate objJdbcTemplate = null;
		ResponseBean objResponseBean = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;
		long tiempoInicio = System.currentTimeMillis();

		try {
			this.timeaiDS.setLoginTimeout(this.propExterno.dbTimeaiTimeoutCONNECTION);
			LOGGER.info(msgMet + "DATA SOURCE (JNDI): [" + this.propExterno.dbTimeaiJNDI + Constantes.CLOSECORCHETE);

			OWNER = this.propExterno.dbTimeaiOWNER;
			PAQUETE = this.propExterno.dbTIMEAIPKGMIGRACIONPLANPOST;
			PROCEDURE = this.propExterno.spTIMEAISPREGESTMIGRACION;

			LOGGER.info(msgMet + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO + PROCEDURE
					+ Constantes.CLOSECORCHETE);

			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue(Constantes.PIDPROCESO, p_id_proceso, Types.VARCHAR)
					.addValue(Constantes.PCOID, p_co_id, Types.VARCHAR)
					.addValue(Constantes.PMSISDN, p_msisdn, Types.VARCHAR)
					.addValue(Constantes.PESTADO, p_estado, Types.VARCHAR)
					.addValue(Constantes.PCODIGOERROR, p_codigo_error, Types.VARCHAR)
					.addValue(Constantes.PMENSAJEERROR, p_mensaje_error, Types.VARCHAR);

			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_id_proceso: [" + p_id_proceso + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_co_id: [" + p_co_id + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_msisdn: [" + p_msisdn + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_estado: [" + p_estado + Constantes.CLOSECORCHETE);
			LOGGER.info(
					msgMet + Constantes.PARAMETROIN + "p_codigo_error: [" + p_codigo_error + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_mensaje_error: [" + p_mensaje_error
					+ Constantes.CLOSECORCHETE);

			this.objJdbcCall = new SimpleJdbcCall(this.timeaiDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbTimeaiTimeoutEXECUTION);

			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(new SqlParameter(Constantes.PIDPROCESO, Types.VARCHAR),
							new SqlParameter(Constantes.PCOID, Types.VARCHAR),
							new SqlParameter(Constantes.PMSISDN, Types.VARCHAR),
							new SqlParameter(Constantes.PESTADO, Types.VARCHAR),
							new SqlParameter(Constantes.PCODIGOERROR, Types.VARCHAR),
							new SqlParameter(Constantes.PMENSAJEERROR, Types.VARCHAR),
							new SqlOutParameter(Constantes.PRESULTADO, Types.VARCHAR),
							new SqlOutParameter(Constantes.PMENSAJE, Types.VARCHAR))
					.execute(objParametrosIN);

			LOGGER.info(msgMet + Constantes.PARAMETROOUT + Constantes.OPENCORCHETE + objParametrosOUT
					+ Constantes.CLOSECORCHETE);

			String codeResOUT = (String) objParametrosOUT.get(Constantes.PRESULTADO);
			String msgResOUT = (String) objParametrosOUT.get(Constantes.PMENSAJE);

			LOGGER.info(msgMet + Constantes.PARAMETROOUT + "p_resultado : [" + codeResOUT + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROOUT + "p_mensaje : [" + msgResOUT + Constantes.CLOSECORCHETE);

			objResponseBean = new ResponseBean();
			objResponseBean.setCodeRes(codeResOUT);
			objResponseBean.setMsgRes(msgResOUT);

		} catch (Exception e) {
			LOGGER.error(msgMet + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE);
			throw e;
		} finally {
			LOGGER.info(msgMet + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(msgMet + "[FIN] - METODO: [registrarEstadoMigracion - DAO] ");
		}

		return objResponseBean;
	}

	@Override
	public ResponseBean actualizarTransMasiva(String msgTxId, String numCliente, String idEstado,String flagOperacion) throws Exception {
		String msgMet = msgTxId + "[actualizarTransMasiva]";
		
		LOGGER.info(msgMet + "[INICIO] - METODO: [actualizarTransMasiva - DAO] ");

		JdbcTemplate objJdbcTemplate = null;
		ResponseBean objResponseBean = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;
		long tiempoInicio = System.currentTimeMillis();

		int numeroClienteInt= Integer.valueOf(numCliente);
		int estadoInt=Integer.valueOf(idEstado);
		
		try {
			this.timeaiDS.setLoginTimeout(this.propExterno.dbTimeaiTimeoutCONNECTION);
			LOGGER.info(msgMet + "DATA SOURCE (JNDI): [" + this.propExterno.dbTimeaiJNDI + Constantes.CLOSECORCHETE);

			OWNER = this.propExterno.dbTimeaiOWNER;
			PAQUETE = this.propExterno.dbTIMEAIPKGSERVMASIVO;
			PROCEDURE = this.propExterno.spTIMEAISPTRANSMASIVA;

			LOGGER.info(msgMet + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO + PROCEDURE
					+ Constantes.CLOSECORCHETE);

			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue(Constantes.PITACOVCAMPO1, numeroClienteInt, Types.NUMERIC)
					.addValue(Constantes.PITACONIDESTADO, estadoInt, Types.NUMERIC)
					.addValue(Constantes.PIFLAGOPERACION, flagOperacion, Types.CHAR);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "PI_TACOV_CAMPO1: [" + numeroClienteInt + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "PI_TACON_IDESTADO: [" + estadoInt + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "PI_FLAG_OPERACION: [" + flagOperacion + Constantes.CLOSECORCHETE);
			this.objJdbcCall = new SimpleJdbcCall(this.timeaiDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbTimeaiTimeoutEXECUTION);

			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(new SqlParameter(Constantes.PITACOVCAMPO1, Types.NUMERIC),
							new SqlParameter(Constantes.PITACONIDESTADO, Types.NUMERIC),
							new SqlParameter(Constantes.PIFLAGOPERACION, Types.CHAR),
							new SqlOutParameter(Constantes.POCODERROR, Types.VARCHAR),
							new SqlOutParameter(Constantes.PODESERROR, Types.VARCHAR))
					.execute(objParametrosIN);

			LOGGER.info(msgMet + Constantes.PARAMETROOUT + Constantes.OPENCORCHETE + objParametrosOUT
					+ Constantes.CLOSECORCHETE);

			String codeResOUT = (String) objParametrosOUT.get(Constantes.POCODERROR);
			String msgResOUT = (String) objParametrosOUT.get(Constantes.PODESERROR);

			LOGGER.info(msgMet + Constantes.PARAMETROOUT + "PO_COD_ERROR : [" + codeResOUT + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROOUT + "PO_DES_ERROR : [" + msgResOUT + Constantes.CLOSECORCHETE);

			objResponseBean = new ResponseBean();
			objResponseBean.setCodeRes(codeResOUT);
			objResponseBean.setMsgRes(msgResOUT);
		} catch (Exception e) {
			LOGGER.error(msgMet + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE);
			throw e;
		} finally {
			LOGGER.info(msgMet + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(msgMet + "[FIN] - METODO: [actualizarTransMasiva - DAO] ");
		}

		return objResponseBean;
	}

	@Override
	public ResponseBean actualizarProgramacion(String msgTxId, String p_servi_cod, String p_servv_msisdn,
			String p_servd_fecha_prog, String p_servv_id_batch, String p_servd_fecha_ejec, String p_servc_estado,
			String p_servv_men_error, String p_servv_cod_error) throws Exception {

		String msgMet = msgTxId + "[actualizarProgramacion]";
		LOGGER.info(msgMet + " Actualiza estado programacion");
		LOGGER.info(msgMet + "[INICIO] - METODO: [actualizarProgramacion - DAO] ");

		JdbcTemplate objJdbcTemplate = null;
		ResponseBean objResponseBean = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;
		long tiempoInicio = System.currentTimeMillis();

		try {

			this.timeaiDS.setLoginTimeout(this.propExterno.dbTimeaiTimeoutCONNECTION);
			LOGGER.info(msgMet + "DATA SOURCE (JNDI): [" + this.propExterno.dbTimeaiJNDI + Constantes.CLOSECORCHETE);

			OWNER = this.propExterno.dbTimeaiOWNER;
			PAQUETE = this.propExterno.dbTIMEAIPKGPPPROGRAMACIONSERV;
			PROCEDURE = this.propExterno.spTIMEAISPACTUALIZAPROGRAMACION;

			LOGGER.info(msgMet + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO + PROCEDURE
					+ Constantes.CLOSECORCHETE);

			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue(Constantes.PSERVICOD, p_servi_cod, Types.VARCHAR)
					.addValue(Constantes.PSERVVMSISDN, p_servv_msisdn, Types.VARCHAR)
					.addValue(Constantes.PSERVDFECHAPROG, p_servd_fecha_prog, Types.VARCHAR)
					.addValue(Constantes.PSERVVIDBATCH, p_servv_id_batch, Types.VARCHAR)
					.addValue(Constantes.PSERVDFECHAEJEC, p_servd_fecha_ejec, Types.VARCHAR)
					.addValue(Constantes.PSERVCESTADO, p_servc_estado, Types.VARCHAR)
					.addValue(Constantes.PSERVVMENERROR,
							p_servv_men_error.replace(Constantes.SIMBDIERESIS, Constantes.VACIO), Types.VARCHAR)
					.addValue(Constantes.PSERVVCODERROR, p_servv_cod_error, Types.VARCHAR);

			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_servi_cod: [" + p_servi_cod + Constantes.CLOSECORCHETE);
			LOGGER.info(
					msgMet + Constantes.PARAMETROIN + "p_servv_msisdn: [" + p_servv_msisdn + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_servd_fecha_prog: [" + p_servd_fecha_prog
					+ Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_servv_id_batch: [" + p_servv_id_batch
					+ Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_servd_fecha_ejec: [" + p_servd_fecha_ejec
					+ Constantes.CLOSECORCHETE);
			LOGGER.info(
					msgMet + Constantes.PARAMETROIN + "p_servc_estado: [" + p_servc_estado + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_servv_men_error: ["
					+ p_servv_men_error.replace(Constantes.SIMBDIERESIS, Constantes.VACIO) + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_servv_cod_error: [" + p_servv_cod_error
					+ Constantes.CLOSECORCHETE);

			this.objJdbcCall = new SimpleJdbcCall(this.timeaiDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbTimeaiTimeoutEXECUTION);

			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(new SqlParameter(Constantes.PSERVICOD, Types.VARCHAR),
							new SqlParameter(Constantes.PSERVVMSISDN, Types.VARCHAR),
							new SqlParameter(Constantes.PSERVDFECHAPROG, Types.VARCHAR),
							new SqlParameter(Constantes.PSERVVIDBATCH, Types.VARCHAR),
							new SqlParameter(Constantes.PSERVDFECHAEJEC, Types.VARCHAR),
							new SqlParameter(Constantes.PSERVCESTADO, Types.VARCHAR),
							new SqlParameter(Constantes.PSERVVMENERROR, Types.VARCHAR),
							new SqlParameter(Constantes.PSERVVCODERROR, Types.VARCHAR),
							new SqlOutParameter(Constantes.PCODERROR, Types.VARCHAR),
							new SqlOutParameter(Constantes.PMENERROR, Types.VARCHAR))
					.execute(objParametrosIN);

			LOGGER.info(msgMet + Constantes.PARAMETROOUT + Constantes.OPENCORCHETE + objParametrosOUT
					+ Constantes.CLOSECORCHETE);

			String codeResOUT = (String) objParametrosOUT.get(Constantes.PCODERROR);
			String msgResOUT = (String) objParametrosOUT.get(Constantes.PMENERROR);

			LOGGER.info(msgMet + Constantes.PARAMETROOUT + "p_cod_error : [" + codeResOUT + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROOUT + "p_men_error : [" + msgResOUT + Constantes.CLOSECORCHETE);

			objResponseBean = new ResponseBean();
			objResponseBean.setCodeRes(codeResOUT);
			objResponseBean.setMsgRes(msgResOUT);

		} catch (Exception e) {
			LOGGER.error(msgMet + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE);
			throw e;
		} finally {
			LOGGER.info(msgMet + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(msgMet + "[FIN] - METODO: [actualizarProgramacion - DAO] ");
		}

		return objResponseBean;
	}

	@Override
	public ResponseBean actualizarEstadoMigracion(String msgTxId, String p_id_proceso, String p_co_id, String p_msisdn,
			String p_estado, String p_codigo_error, String p_mensaje_error) throws Exception {

		String msgMet = msgTxId + "[actualizaEstadoMigracion] ";

		LOGGER.info(msgMet + " Actualiza estado Migracion");
		LOGGER.info(msgMet + "[INICIO] - METODO: [actualizaEstadoMigracion - DAO] ");

		JdbcTemplate objJdbcTemplate = null;
		ResponseBean objResponseBean = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;
		long tiempoInicio = System.currentTimeMillis();

		try {

			this.timeaiDS.setLoginTimeout(this.propExterno.dbTimeaiTimeoutCONNECTION);
			LOGGER.info(msgMet + "DATA SOURCE (JNDI): [" + this.propExterno.dbTimeaiJNDI + Constantes.CLOSECORCHETE);

			OWNER = this.propExterno.dbTimeaiOWNER;
			PAQUETE = this.propExterno.dbTIMEAIPKGMIGRACIONPLANPOST;
			PROCEDURE = this.propExterno.spTIMEAISPACTESTADOMIGRACION;

			LOGGER.info(msgMet + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO + PROCEDURE
					+ Constantes.CLOSECORCHETE);

			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue(Constantes.PIDPROCESO, p_id_proceso, Types.VARCHAR)
					.addValue(Constantes.PCOID, p_co_id, Types.VARCHAR)
					.addValue(Constantes.PMSISDN, p_msisdn, Types.VARCHAR)
					.addValue(Constantes.PESTADO, p_estado, Types.VARCHAR)
					.addValue(Constantes.PCODIGOERROR, p_codigo_error, Types.VARCHAR)
					.addValue(Constantes.PMENSAJEERROR, p_mensaje_error, Types.VARCHAR);

			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_id_proceso: [" + p_id_proceso + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_co_id: [" + p_co_id + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_msisdn: [" + p_msisdn + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_estado: [" + p_estado + Constantes.CLOSECORCHETE);
			LOGGER.info(
					msgMet + Constantes.PARAMETROIN + "p_codigo_error: [" + p_codigo_error + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROIN + "p_mensaje_error: [" + p_mensaje_error
					+ Constantes.CLOSECORCHETE);

			this.objJdbcCall = new SimpleJdbcCall(this.timeaiDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbTimeaiTimeoutEXECUTION);

			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(new SqlParameter(Constantes.PIDPROCESO, Types.VARCHAR),
							new SqlParameter(Constantes.PCOID, Types.VARCHAR),
							new SqlParameter(Constantes.PMSISDN, Types.VARCHAR),
							new SqlParameter(Constantes.PESTADO, Types.VARCHAR),
							new SqlParameter(Constantes.PCODIGOERROR, Types.VARCHAR),
							new SqlParameter(Constantes.PMENSAJEERROR, Types.VARCHAR),
							new SqlOutParameter(Constantes.PRESULTADO, Types.VARCHAR),
							new SqlOutParameter(Constantes.PMENSAJE, Types.VARCHAR))
					.execute(objParametrosIN);

			LOGGER.info(msgMet + Constantes.PARAMETROOUT + Constantes.OPENCORCHETE + objParametrosOUT
					+ Constantes.CLOSECORCHETE);

			String codeResOUT = (String) objParametrosOUT.get(Constantes.PRESULTADO);
			String msgResOUT = (String) objParametrosOUT.get(Constantes.PMENSAJE);

			LOGGER.info(msgMet + Constantes.PARAMETROOUT + "p_resultado : [" + codeResOUT + Constantes.CLOSECORCHETE);
			LOGGER.info(msgMet + Constantes.PARAMETROOUT + "p_mensaje : [" + msgResOUT + Constantes.CLOSECORCHETE);

			objResponseBean = new ResponseBean();
			objResponseBean.setCodeRes(codeResOUT);
			objResponseBean.setMsgRes(msgResOUT);

		} catch (Exception e) {
			LOGGER.error(msgMet + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE);
			throw e;
		} finally {
			LOGGER.info(msgMet + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(msgMet + "[FIN] - METODO: [actualizaEstadoMigracion - DAO] ");
		}

		return objResponseBean;
	}

	public SPRegistraMigracionResponseBean registrarMigracion(String msgTxId, String idProceso, String coId,
			String msisdn, String fechaProgramacion, String escenarioMigracion, String estado) {
		String cadMensaje = msgTxId + "[registraMigracion]";

		LOGGER.info(cadMensaje + "[INICIO] - METODO: [registraMigracion - DAO] ");

		JdbcTemplate objJdbcTemplate = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;

		long tiempoInicio = System.currentTimeMillis();
		SPRegistraMigracionResponseBean response = new SPRegistraMigracionResponseBean();
		try {

			this.timeaiDS.setLoginTimeout(this.propExterno.dbTimeaiTimeoutCONNECTION);
			LOGGER.info(
					cadMensaje + "DATA SOURCE (JNDI): [" + this.propExterno.dbTimeaiJNDI + Constantes.CLOSECORCHETE);

			OWNER = this.propExterno.dbTimeaiOWNER;
			PAQUETE = this.propExterno.dbTIMEAIPKGMIGRACIONPLANPOST;
			PROCEDURE = this.propExterno.spTIMEAISPREGISTRAMIGRACION;

			LOGGER.info(cadMensaje + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO + PROCEDURE
					+ Constantes.CLOSECORCHETE);

			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue(Constantes.PIDPROCESO, idProceso, Types.VARCHAR)
					.addValue(Constantes.PCOID, coId, Types.VARCHAR)
					.addValue(Constantes.PMSISDN, msisdn, Types.VARCHAR)
					.addValue(Constantes.PFECHAPROGRAMACION2, fechaProgramacion, Types.DATE)
					.addValue(Constantes.PESCENARIOMIGRACION, escenarioMigracion, Types.VARCHAR)
					.addValue(Constantes.PESTADO, estado, Types.VARCHAR)
					.addValue(Constantes.PSERVICOD2, this.propExterno.realTranServiCod, Types.VARCHAR);

			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_id_proceso: [" + idProceso + Constantes.CLOSECORCHETE);
			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_co_id: [" + coId + Constantes.CLOSECORCHETE);
			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_msisdn: [" + msisdn + Constantes.CLOSECORCHETE);
			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_fechaprogramacion: [" + fechaProgramacion	+ Constantes.CLOSECORCHETE);
			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_escenario_migracion: [" + escenarioMigracion + Constantes.CLOSECORCHETE);
			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_estado: [" + estado + Constantes.CLOSECORCHETE);
			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_servicod: [" + this.propExterno.realTranServiCod + Constantes.CLOSECORCHETE);

			this.objJdbcCall = new SimpleJdbcCall(this.timeaiDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbTimeaiTimeoutEXECUTION);

			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(new SqlParameter(Constantes.PIDPROCESO, Types.VARCHAR),
							new SqlParameter(Constantes.PCOID, Types.VARCHAR),
							new SqlParameter(Constantes.PMSISDN, Types.VARCHAR),
							new SqlParameter(Constantes.PFECHAPROGRAMACION2, Types.DATE),
							new SqlParameter(Constantes.PESCENARIOMIGRACION, Types.VARCHAR),
							new SqlParameter(Constantes.PESTADO, Types.VARCHAR),
							new SqlParameter(Constantes.PSERVICOD2, Types.VARCHAR),
							new SqlOutParameter(Constantes.PRESULTADO, Types.VARCHAR),
							new SqlOutParameter(Constantes.PMENSAJE, Types.VARCHAR))
					.execute(objParametrosIN);
			LOGGER.info(cadMensaje + "PARAMETROS [OUPUT]: ");

			response.setResultado(objParametrosOUT.get(Constantes.PRESULTADO).toString());
			LOGGER.info(cadMensaje + "p_resultado: [" + response.getResultado() + Constantes.CLOSECORCHETE);
			response.setMensaje(objParametrosOUT.get(Constantes.PMENSAJE).toString());
			LOGGER.info(cadMensaje + "p_mensaje: [" + response.getMensaje() + Constantes.CLOSECORCHETE);
		} catch (Exception e) {
			response = null;
			LOGGER.error(cadMensaje + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE);
		} finally {
			LOGGER.info(cadMensaje + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(cadMensaje + "[FIN] - METODO: [registraMigracion - DAO] ");
		}
		return response;
	}

	@Override
	public SPBuscarDetServicioMasivo buscarDetServicioMasivo(String msgTxId,String fecha) throws Exception {
		String cadMensaje = msgTxId + "[buscarProgramaciones]";

		LOGGER.info(cadMensaje + "[INICIO] - METODO: [buscarDetServicioMasivo - DAO] ");

		JdbcTemplate objJdbcTemplate = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;
		long tiempoInicio = System.currentTimeMillis();
		SPBuscarDetServicioMasivo response = new SPBuscarDetServicioMasivo();
		try {

			this.timeaiDS.setLoginTimeout(this.propExterno.dbTimeaiTimeoutCONNECTION);
			LOGGER.info(
					cadMensaje + "DATA SOURCE (JNDI): [" + this.propExterno.dbTimeaiJNDI + Constantes.CLOSECORCHETE);

			OWNER = this.propExterno.dbTimeaiOWNER;
			PAQUETE = this.propExterno.dbTIMEAIPKGSERVMASIVO;
			PROCEDURE = this.propExterno.spTIMEAISPBUSCARDETSERVICIOMASIVO;

			LOGGER.info(cadMensaje + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO + PROCEDURE
					+ Constantes.CLOSECORCHETE);

			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue("p_fecha_proceso", fecha, Types.VARCHAR);

			LOGGER.info(cadMensaje + Constantes.PARAMETROIN + "p_fecha_proceso: [" + fecha + Constantes.CLOSECORCHETE);

			this.objJdbcCall = new SimpleJdbcCall(this.timeaiDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbTimeaiTimeoutEXECUTION);

			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(new SqlParameter("p_fecha_proceso", Types.VARCHAR),							
							new SqlOutParameter("p_xml", Types.CLOB),
							new SqlOutParameter("p_resultado", Types.VARCHAR),
							new SqlOutParameter("p_mensaje", Types.VARCHAR))
					.execute(objParametrosIN);
			LOGGER.info(cadMensaje + "PARAMETROS [OUPUT]: ");
			LOGGER.info(cadMensaje + "p_xml: [" + objParametrosOUT.get("p_xml").toString() + Constantes.CLOSECORCHETE);
			response.setCodError(objParametrosOUT.get("p_resultado").toString());
			LOGGER.info(cadMensaje + "p_resultado: [" + response.getCodError() + Constantes.CLOSECORCHETE);
			response.setMenError(objParametrosOUT.get("p_mensaje").toString());
			LOGGER.info(cadMensaje + "p_mensaje: [" + response.getMenError() + Constantes.CLOSECORCHETE);
			
			DetalleMasivo detrequest;
			detrequest = (DetalleMasivo) this.eaiUtil.getJaxBFromXmlText(objParametrosOUT.get("p_xml").toString(), DetalleMasivo.class);
			response.setDetalleMasivo(detrequest);
			
		} catch (Exception e) {
			response = null;
			LOGGER.error(cadMensaje + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE);
		} finally {
			LOGGER.info(cadMensaje + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(cadMensaje + "[FIN] - METODO: [buscarDetServicioMasivo - DAO] ");
		}
		return response;
	}

	@Override
	public SPActualizarDetServicioMasivo actualizarDetServicioMasivo(String msgTxId,
			ActualizarDetServicioMasivoRequest request) throws Exception {
		String cadMensaje = msgTxId + "[actualizaDetalleServicioMasivo]";

		LOGGER.info(cadMensaje + "[INICIO] - METODO: [actualizaDetalleServicioMasivo - DAO] ");

		JdbcTemplate objJdbcTemplate = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;
		long tiempoInicio = System.currentTimeMillis();
		SPActualizarDetServicioMasivo objActualizarDetServicioMasivo = new SPActualizarDetServicioMasivo();
		try {

			this.timeaiDS.setLoginTimeout(this.propExterno.dbTimeaiTimeoutCONNECTION);
			LOGGER.info(
					cadMensaje + "DATA SOURCE (JNDI): [" + this.propExterno.dbTimeaiJNDI + Constantes.CLOSECORCHETE);

			OWNER = this.propExterno.dbTimeaiOWNER;
			PAQUETE = this.propExterno.dbTIMEAIPKGSERVMASIVO;
			PROCEDURE = this.propExterno.spTIMEAISPACTUALIZARDETSERVICIOMASIVO;

			LOGGER.info(cadMensaje + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO + PROCEDURE
					+ Constantes.CLOSECORCHETE);

			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue("P_FECHA_PROCESO", request.getFechaProceso(), Types.VARCHAR)
					.addValue("P_SERVI_COD", request.getServiCod(), Types.INTEGER)
					.addValue("P_ID_ESTADO", request.getIdEstado(), Types.NUMERIC)
					.addValue("PI_TACOV_CAMPO1", request.getLineaLogeo(), Types.VARCHAR)
					.addValue("P_ESTADO_PROG", request.getEstadoProgramacion(), Types.VARCHAR);

			LOGGER.info(cadMensaje + Constantes.PARAMETROIN );
			LOGGER.info(cadMensaje + Constantes.OPENCORCHETE+" = P_FECHA_PROCESO: " + Constantes.CLOSECORCHETE+ request.getFechaProceso());
			LOGGER.info(cadMensaje + Constantes.OPENCORCHETE+" = P_SERVI_COD: " + Constantes.CLOSECORCHETE+ request.getServiCod());
			LOGGER.info(cadMensaje + Constantes.OPENCORCHETE+" = P_ID_ESTADO: " + Constantes.CLOSECORCHETE+ request.getIdEstado());
			LOGGER.info(cadMensaje + Constantes.OPENCORCHETE+" = PI_TACOV_CAMPO1: " + Constantes.CLOSECORCHETE+ request.getLineaLogeo());
			LOGGER.info(cadMensaje + Constantes.OPENCORCHETE+" = P_ESTADO_PROG: " + Constantes.CLOSECORCHETE+ request.getEstadoProgramacion());
			

			this.objJdbcCall = new SimpleJdbcCall(this.timeaiDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbTimeaiTimeoutEXECUTION);

			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(
							new SqlParameter("P_FECHA_PROCESO", Types.VARCHAR),							
							new SqlParameter("P_SERVI_COD", Types.INTEGER),							
							new SqlParameter("P_ID_ESTADO", Types.NUMERIC),							
							new SqlParameter("PI_TACOV_CAMPO1", Types.VARCHAR),							
							new SqlParameter("P_ESTADO_PROG", Types.VARCHAR),
							new SqlOutParameter("P_RESULTADO", Types.VARCHAR),
							new SqlOutParameter("P_MENSAJE", Types.VARCHAR))
					.execute(objParametrosIN);
			
			LOGGER.info(cadMensaje + "Se invoco con exito el SP  :  " + OWNER +  Constantes.PUNTO  + PAQUETE+  Constantes.PUNTO +  PROCEDURE);
			
			
			if (objParametrosOUT == null || objParametrosOUT.isEmpty()) {
				LOGGER.info(cadMensaje + "No se encontraron datos para procesar.");
			} else {
				objActualizarDetServicioMasivo.setCodRespuesta(objParametrosOUT.get("P_RESULTADO").toString());
				objActualizarDetServicioMasivo.setMsjRespuesta(objParametrosOUT.get("P_MENSAJE").toString());
				
				LOGGER.info(cadMensaje + "PARAMETROS [OUTPUT]:");
				LOGGER.info(cadMensaje + "P_RESULTADO: [" + objActualizarDetServicioMasivo.getCodRespuesta() + Constantes.CLOSECORCHETE);
				LOGGER.info(cadMensaje + "P_MENSAJE: [" + objActualizarDetServicioMasivo.getMsjRespuesta() + Constantes.CLOSECORCHETE);
			}
			
			LOGGER.info(cadMensaje + "PARAMETROS [OUPUT]: ");
			
				
		} catch (Exception e) {
			objActualizarDetServicioMasivo = null;
			LOGGER.error(cadMensaje + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE);
		} finally {
			LOGGER.info(cadMensaje + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(cadMensaje + "[FIN] - METODO: [buscarDetServicioMasivo - DAO] ");
		}
		return objActualizarDetServicioMasivo;
	}

}
