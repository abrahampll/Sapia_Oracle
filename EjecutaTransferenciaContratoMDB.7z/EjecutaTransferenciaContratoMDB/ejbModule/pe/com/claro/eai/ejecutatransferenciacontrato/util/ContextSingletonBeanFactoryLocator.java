package pe.com.claro.eai.ejecutatransferenciacontrato.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.access.BeanFactoryLocator;
import org.springframework.beans.factory.access.SingletonBeanFactoryLocator;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternUtils;

public class ContextSingletonBeanFactoryLocator extends SingletonBeanFactoryLocator{    
	 
      @Override
      protected BeanFactory createDefinition( String resourceLocation, String factoryKey ){
 
		        final ClassPathXmlApplicationContext objAplicationContext = new ClassPathXmlApplicationContext( new String[]{ resourceLocation }, false );
		        final ClassLoader                    objClassLoader       = this.getClass().getClassLoader();
		          
		        objAplicationContext.setClassLoader( objClassLoader );
		        
		        return objAplicationContext;
      }
  
    private static final String UBICACIONEJBSPRINGCONTEXT = Constantes.EJBSPRING;
    
    private static final Map<Object, Object> TABLAINSTANCIAS = new HashMap<Object, Object>();   

      public static BeanFactoryLocator getInstance() throws BeansException{
    	     BeanFactoryLocator objFactoryLocator = getInstance( UBICACIONEJBSPRINGCONTEXT ); 
    	     logger.debug( "objFactoryLocator [Instancia]#1: " + objFactoryLocator );
  
             return objFactoryLocator;
      }

      public static BeanFactoryLocator getInstance( String selector ) throws BeansException {
          String select = selector;
                 if( !( ResourcePatternUtils.isUrl( select ) )){
	             select = (ResourcePatternResolver.CLASSPATH_ALL_URL_PREFIX + select);	             
	         }
	
	         synchronized( TABLAINSTANCIAS ){
		          if( logger.isDebugEnabled() ){
		              logger.debug( "ContextSingletonBeanFactoryLocator.getInstance(): instances.hashCode=[" +
		                             TABLAINSTANCIAS.hashCode() + "], instances=[" + TABLAINSTANCIAS + "]" );
		          }
		          
		          BeanFactoryLocator objFactoryLocator = (BeanFactoryLocator)TABLAINSTANCIAS.get( select );
		          logger.debug( "objFactoryLocator [Instancia]#2: " + objFactoryLocator );
 
		          if( objFactoryLocator == null ){
		              objFactoryLocator = new ContextSingletonBeanFactoryLocator( select );
		              TABLAINSTANCIAS.put( select, objFactoryLocator );
		          }
		          
		          return objFactoryLocator;
	         }
      }

      protected ContextSingletonBeanFactoryLocator(){
                super( UBICACIONEJBSPRINGCONTEXT );
      }
     
      protected ContextSingletonBeanFactoryLocator( String nombreRecurso ){ 
                super( nombreRecurso );
      }
     
      protected void initializeDefinition( BeanFactory objBeanFactory ) throws BeansException{
		        if( objBeanFactory instanceof ConfigurableApplicationContext ){
		            ((ConfigurableApplicationContext) objBeanFactory).refresh();
		        }
      }
      
      protected void destroyDefinition( BeanFactory objBeanFactory, String nombreRecurso ) throws BeansException{
		        if( objBeanFactory instanceof ConfigurableApplicationContext ){
		            if( logger.isDebugEnabled() ){
		                logger.debug( "ContextSingletonBeanFactoryLocator group with resourceName=['" + nombreRecurso + "'] being released, as there are no more references" );  
		            }
		            ( (ConfigurableApplicationContext)objBeanFactory ).close();
		        }
      }
}
