package pe.com.claro.eai.ejecutatransferenciacontrato.dao;

import pe.com.claro.eai.ejecutatransferenciacontrato.dto.InteraccionPlusRequestBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.InteraccionRequestBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.InteraccionResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPObtenerCustomerBean;

public interface ClarifyDAO {

	InteraccionResponseBean crearInteraccion(String mensajeLog, InteraccionRequestBean requestBean) throws Exception;
	
	InteraccionResponseBean crearInteraccionPlus(String mensajeLog, InteraccionPlusRequestBean requestBean) throws Exception;
	
	SPObtenerCustomerBean obtenerCustomer(String mensajeLog,String phone,int flag) throws Exception; 
	
}
