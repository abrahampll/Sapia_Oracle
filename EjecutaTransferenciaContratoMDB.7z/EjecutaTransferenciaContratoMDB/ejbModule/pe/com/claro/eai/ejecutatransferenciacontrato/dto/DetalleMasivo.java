package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement (name="DetalleMasivo")
public class DetalleMasivo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String clase;
	private String subClase;
	private String SEC;
	private String descripcionProceso;
	private String apellidoRepresentanteLeg;
	private String nombreRepresentanteLeg;
	
	public String getClase() {
		return clase;
	}
	@XmlElement(name = "clase")
	public void setClase(String clase) {
		this.clase = clase;
	}
	public String getSubClase() {
		return subClase;
	}
	@XmlElement(name = "subClase")
	public void setSubClase(String subClase) {
		this.subClase = subClase;
	}
	public String getSEC() {
		return SEC;
	}
	@XmlElement(name = "SEC")
	public void setSEC(String sEC) {
		SEC = sEC;
	}
	public String getDescripcionProceso() {
		return descripcionProceso;
	}
	@XmlElement(name = "descripcionProceso")
	public void setDescripcionProceso(String descripcionProceso) {
		this.descripcionProceso = descripcionProceso;
	}
	public String getApellidoRepresentanteLeg() {
		return apellidoRepresentanteLeg;
	}
	@XmlElement(name = "apellidoRepresentanteLeg")
	public void setApellidoRepresentanteLeg(String apellidoRepresentanteLeg) {
		this.apellidoRepresentanteLeg = apellidoRepresentanteLeg;
	}
	public String getNombreRepresentanteLeg() {
		return nombreRepresentanteLeg;
	}
	@XmlElement(name = "nombreRepresentanteLeg")
	public void setNombreRepresentanteLeg(String nombreRepresentanteLeg) {
		this.nombreRepresentanteLeg = nombreRepresentanteLeg;
	}

}
