package pe.com.claro.eai.ejecutatransferenciacontrato.dao.mapper;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlReturnType;

import pe.com.claro.eai.ejecutatransferenciacontrato.dto.CursorCustomer;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.Constantes;

public class CursorCustomerSqlReturnType implements SqlReturnType{
	private final Logger LOGGER = Logger.getLogger(this.getClass().getName());

    //@SuppressWarnings("rawtypes")
    private RowMapper<CursorCustomer> rowMapper = new RowMapper<CursorCustomer>() {

        public CursorCustomer mapRow(ResultSet rs, int numeroFila) throws SQLException {
        	
        	CursorCustomer objBean = new CursorCustomer();

            objBean.setObjid_contacto(rs.getString("OBJID_CONTACTO"));
            objBean.setObjid_site(rs.getString("OBJID_SITE"));
            objBean.setTelefono(rs.getString("TELEFONO"));
            objBean.setCuenta(rs.getString("CUENTA"));
            objBean.setModalidad(rs.getString("MODALIDAD"));
            objBean.setSegmento(rs.getString("SEGMENTO"));
            objBean.setRol_contacto(rs.getString("ROL_CONTACTO"));
            objBean.setEstado_contacto(rs.getString("ESTADO_CONTACTO"));
            objBean.setEstado_contrato(rs.getString("ESTADO_CONTRATO"));
            objBean.setEstado_site(rs.getString("ESTADO_SITE"));
            objBean.setS_nombre(rs.getString("S_NOMBRES"));
            objBean.setS_apellidos(rs.getString("S_APELLIDOS"));
            objBean.setNombres(rs.getString("NOMBRES"));
            objBean.setApellidos(rs.getString("APELLIDOS"));
            objBean.setDomicilio(rs.getString("DOMICILIO"));
            objBean.setUrbanizacion(rs.getString("URBANIZACION"));
            objBean.setReferencia(rs.getString("REFERENCIA"));
            objBean.setCiudad(rs.getString("CIUDAD"));
            objBean.setDistrito(rs.getString("DISTRITO"));
            objBean.setDepartamento(rs.getString("DEPARTAMENTO"));
            objBean.setZipcode(rs.getString("ZIPCODE"));
            objBean.setEmail(rs.getString("EMAIL"));
            objBean.setTelef_referencia(rs.getString("TELEF_REFERENCIA"));
            objBean.setFax(rs.getString("FAX"));
            objBean.setFecha_nac(rs.getDate("FECHA_NAC"));
            objBean.setSexo(rs.getString("SEXO"));
            objBean.setEstado_civil(rs.getString("ESTADO_CIVIL"));
            objBean.setTipo_doc(rs.getString("TIPO_DOC"));
            objBean.setNro_doc(rs.getString("NRO_DOC"));
            objBean.setFecha_act(rs.getDate("FECHA_ACT"));
            objBean.setPunto_venta(rs.getString("PUNTO_VENTA"));
            objBean.setFlag_registrado(rs.getInt("FLAG_REGISTRADO"));
            objBean.setOcupacion(rs.getString("OCUPACION"));
            objBean.setCant_reg(rs.getString("CANT_REG"));
            objBean.setFlag_email(rs.getString("FLAG_EMAIL"));
            objBean.setMotivo_registro(rs.getString("MOTIVO_REGISTRO"));
            objBean.setFuncion(rs.getString("FUNCION"));
            objBean.setCargo(rs.getString("CARGO"));
            objBean.setLugar_nac(rs.getString("LUGAR_NAC"));
            return objBean;
        }
    };

    //@SuppressWarnings( { "rawtypes", "unchecked" })
    @Override
    public Object getTypeValue(CallableStatement cs, int ix, int sqlType, String typeName) throws SQLException {
        ResultSet rs = null;
        
        try {
            rs = (ResultSet)cs.getObject(ix);
            List<CursorCustomer> lista = new ArrayList<CursorCustomer>();
            
            for (int i = 0; rs.next(); i++) {
                lista.add(rowMapper.mapRow(rs, i));
            }
            return lista;
        } catch (SQLException e) {
            LOGGER.error("ERROR [SQLException]: " + e.getMessage());
            if ((e.getMessage() != null) && (e.getMessage().startsWith(Constantes.EXCEPTIONBDEJECUCION03))) {

                LOGGER.error("[Cursor is closed]: ");
                return new ArrayList<CursorCustomer>();
            } else {
                throw e;
            }
        } finally {
            if (rs != null)
                rs.close();
        }
    }
}
