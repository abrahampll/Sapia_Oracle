package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

public class ResponseBean {
    private String codeRes;
    private String msgRes;
    private Object objetoRespuesta;

    public void setCodeRes(String codeRes) {
        this.codeRes = codeRes;
    }

    public String getCodeRes() {
        return codeRes;
    }

    public void setMsgRes(String msgRes) {
        this.msgRes = msgRes;
    }

    public String getMsgRes() {
        return msgRes;
    }

    public Object getObjetoRespuesta() {
        return objetoRespuesta;
    }

    public void setObjetoRespuesta(Object objetoRespuesta) {
        this.objetoRespuesta = objetoRespuesta;
    }
}
