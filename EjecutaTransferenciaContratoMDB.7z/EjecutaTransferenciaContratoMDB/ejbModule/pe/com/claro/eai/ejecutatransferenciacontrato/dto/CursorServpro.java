package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

public class CursorServpro {

    @SuppressWarnings("compatibility:-3731418951957465822")
    private static final long serialVersionUID = 1L;
    private String servvMsisdn;
    private String servdFechaProg;
    private String coId;
    private String servvIdEeaiSw;
    private String servvUsuarioAplicacion;
    private String servvEmailUsuarioApp;
    private String servvUsuarioSistema;
    private String servdFechaReg;
    private String servdFechaEjec;
    private String servcEstado;
    private String servcEsbatch;
    private String servvIdBatch;
    private String servvMenError;
    private String servvCodError;
    private String servvXmslEntrada;
    
	public String getServvMsisdn() {
		return servvMsisdn;
	}
	public void setServvMsisdn(String servvMsisdn) {
		this.servvMsisdn = servvMsisdn;
	}
	public String getServdFechaProg() {
		return servdFechaProg;
	}
	public void setServdFechaProg(String servdFechaProg) {
		this.servdFechaProg = servdFechaProg;
	}
	public String getCoId() {
		return coId;
	}
	public void setCoId(String coId) {
		this.coId = coId;
	}
	public String getServvIdEeaiSw() {
		return servvIdEeaiSw;
	}
	public void setServvIdEeaiSw(String servvIdEeaiSw) {
		this.servvIdEeaiSw = servvIdEeaiSw;
	}
	public String getServvUsuarioAplicacion() {
		return servvUsuarioAplicacion;
	}
	public void setServvUsuarioAplicacion(String servvUsuarioAplicacion) {
		this.servvUsuarioAplicacion = servvUsuarioAplicacion;
	}
	public String getServvEmailUsuarioApp() {
		return servvEmailUsuarioApp;
	}
	public void setServvEmailUsuarioApp(String servvEmailUsuarioApp) {
		this.servvEmailUsuarioApp = servvEmailUsuarioApp;
	}
	public String getServvUsuarioSistema() {
		return servvUsuarioSistema;
	}
	public void setServvUsuarioSistema(String servvUsuarioSistema) {
		this.servvUsuarioSistema = servvUsuarioSistema;
	}
	public String getServdFechaReg() {
		return servdFechaReg;
	}
	public void setServdFechaReg(String servdFechaReg) {
		this.servdFechaReg = servdFechaReg;
	}
	public String getServdFechaEjec() {
		return servdFechaEjec;
	}
	public void setServdFechaEjec(String servdFechaEjec) {
		this.servdFechaEjec = servdFechaEjec;
	}
	public String getServcEstado() {
		return servcEstado;
	}
	public void setServcEstado(String servcEstado) {
		this.servcEstado = servcEstado;
	}
	public String getServcEsbatch() {
		return servcEsbatch;
	}
	public void setServcEsbatch(String servcEsbatch) {
		this.servcEsbatch = servcEsbatch;
	}
	public String getServvIdBatch() {
		return servvIdBatch;
	}
	public void setServvIdBatch(String servvIdBatch) {
		this.servvIdBatch = servvIdBatch;
	}
	public String getServvMenError() {
		return servvMenError;
	}
	public void setServvMenError(String servvMenError) {
		this.servvMenError = servvMenError;
	}
	public String getServvCodError() {
		return servvCodError;
	}
	public void setServvCodError(String servvCodError) {
		this.servvCodError = servvCodError;
	}
	public String getServvXmslEntrada() {
		return servvXmslEntrada;
	}
	public void setServvXmslEntrada(String servvXmslEntrada) {
		this.servvXmslEntrada = servvXmslEntrada;
	}
    
}
