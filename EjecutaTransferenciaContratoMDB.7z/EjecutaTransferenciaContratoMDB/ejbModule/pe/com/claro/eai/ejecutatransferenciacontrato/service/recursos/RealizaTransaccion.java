package pe.com.claro.eai.ejecutatransferenciacontrato.service.recursos;

import java.util.Date;

public interface RealizaTransaccion {
  	public void registrarExito(String msgTxId,  String p_id_proceso,
		  String p_co_id, 
		  String p_msisdn,
		  String p_estado,
		  String p_codigo_error,
		  String p_mensaje_error,
		  String p_escenario);

	public void registrarError(String msgTxId,
		String p_id_proceso,
		String p_co_id, 
		String p_msisdn,
		String p_estado,
		String p_codigo_error,
		String p_mensaje_error,
		String p_servi_cod,
		Date p_servd_fecha_prog,
		String p_servv_id_batch, 
		Date p_servd_fecha_ejec, 
		String p_servc_estado,
		String p_servv_cod_error,
		String p_servv_men_error,
		String p_codigo_errorActMig,
		String p_codigo_mensajeActMig,String ipApp,String usuApp,String p_escenario);
}
