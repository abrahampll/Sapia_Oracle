package pe.com.claro.eai.ejecutatransferenciacontrato.proxy;

import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ResponseBean;
import pe.com.claro.eai.messagingservices.mail.enviomail.EnvioMail_Type;

public interface EnvioMailService {
	 public ResponseBean enviarEmail(String mensajeTransaccion, EnvioMail_Type inParameters) throws Exception;
}
