package pe.com.claro.eai.ejecutatransferenciacontrato.dto;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="audit" type="{http://claro.com.pe/eai/ebs/unionseparacionrecibos/ws/types}audiTypeRequest"/>
 *         &lt;element name="msisdn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="coId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="customerId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="customerIdDestino" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="tipoClarity" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="flagLimiteCredito" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cuenta" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cuentaPadre" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="usuarioSistema" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="fase" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="fechaProgramacion" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="cac" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="escenario" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="planTarifario" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="listaOpcionalRequest" type="{http://claro.com.pe/eai/ebs/unionseparacionrecibos/ws/types}ListaRequestOpcional"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "audit",
    "msisdn",
    "coId",
    "customerId",
    "customerIdDestino",
    "tipoClarity",
    "flagLimiteCredito",
    "cuenta",
    "cuentaPadre",
    "usuarioSistema",
    "fase",
    "fechaProgramacion",
    "cac",
    "escenario",
    "planTarifario",
    "listaOpcionalRequest"
})
@XmlRootElement(name = "realizarTransaccionRequest")
public class RealizarTransaccionRequest {

    @XmlElement(required = true)
    protected AudiTypeRequest audit;
    @XmlElement(required = true)
    protected String msisdn;
    @XmlElement(required = true)
    protected String coId;
    protected long customerId;
    protected long customerIdDestino;
    @XmlElement(required = true)
    protected String tipoClarity;
    @XmlElement(required = true)
    protected String flagLimiteCredito;
    @XmlElement(required = true)
    protected String cuenta;
    protected Long cuentaPadre;
    @XmlElement(required = true)
    protected String usuarioSistema;
    @XmlElement(required = true)
    protected String fase;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fechaProgramacion;
    @XmlElement(required = true)
    protected String cac;
    @XmlElement(required = true)
    protected String escenario;
    protected long planTarifario;
    @XmlElement(required = true)
    protected ListaRequestOpcional listaOpcionalRequest;

    /**
     * Gets the value of the audit property.
     * 
     * @return
     *     possible object is
     *     {@link AudiTypeRequest }
     *     
     */
    public AudiTypeRequest getAudit() {
        return audit;
    }

    /**
     * Sets the value of the audit property.
     * 
     * @param value
     *     allowed object is
     *     {@link AudiTypeRequest }
     *     
     */
    public void setAudit(AudiTypeRequest value) {
        this.audit = value;
    }

    /**
     * Gets the value of the msisdn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsisdn() {
        return msisdn;
    }

    /**
     * Sets the value of the msisdn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsisdn(String value) {
        this.msisdn = value;
    }

    /**
     * Gets the value of the coId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoId() {
        return coId;
    }

    /**
     * Sets the value of the coId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoId(String value) {
        this.coId = value;
    }

    /**
     * Gets the value of the customerId property.
     * 
     */
    public long getCustomerId() {
        return customerId;
    }

    /**
     * Sets the value of the customerId property.
     * 
     */
    public void setCustomerId(long value) {
        this.customerId = value;
    }

    /**
     * Gets the value of the customerIdDestino property.
     * 
     */
    public long getCustomerIdDestino() {
        return customerIdDestino;
    }

    /**
     * Sets the value of the customerIdDestino property.
     * 
     */
    public void setCustomerIdDestino(long value) {
        this.customerIdDestino = value;
    }

    /**
     * Gets the value of the tipoClarity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoClarity() {
        return tipoClarity;
    }

    /**
     * Sets the value of the tipoClarity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoClarity(String value) {
        this.tipoClarity = value;
    }

    /**
     * Gets the value of the flagLimiteCredito property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlagLimiteCredito() {
        return flagLimiteCredito;
    }

    /**
     * Sets the value of the flagLimiteCredito property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlagLimiteCredito(String value) {
        this.flagLimiteCredito = value;
    }

    /**
     * Gets the value of the cuenta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuenta() {
        return cuenta;
    }

    /**
     * Sets the value of the cuenta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuenta(String value) {
        this.cuenta = value;
    }

    /**
     * Gets the value of the cuentaPadre property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCuentaPadre() {
        return cuentaPadre;
    }

    /**
     * Sets the value of the cuentaPadre property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCuentaPadre(Long value) {
        this.cuentaPadre = value;
    }

    /**
     * Gets the value of the usuarioSistema property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUsuarioSistema() {
        return usuarioSistema;
    }

    /**
     * Sets the value of the usuarioSistema property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUsuarioSistema(String value) {
        this.usuarioSistema = value;
    }

    /**
     * Gets the value of the fase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFase() {
        return fase;
    }

    /**
     * Sets the value of the fase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFase(String value) {
        this.fase = value;
    }

    /**
     * Gets the value of the fechaProgramacion property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFechaProgramacion() {
        return fechaProgramacion;
    }

    /**
     * Sets the value of the fechaProgramacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaProgramacion(XMLGregorianCalendar value) {
        this.fechaProgramacion = value;
    }

    /**
     * Gets the value of the cac property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCac() {
        return cac;
    }

    /**
     * Sets the value of the cac property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCac(String value) {
        this.cac = value;
    }

    /**
     * Gets the value of the escenario property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEscenario() {
        return escenario;
    }

    /**
     * Sets the value of the escenario property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEscenario(String value) {
        this.escenario = value;
    }

    /**
     * Gets the value of the planTarifario property.
     * 
     */
    public long getPlanTarifario() {
        return planTarifario;
    }

    /**
     * Sets the value of the planTarifario property.
     * 
     */
    public void setPlanTarifario(long value) {
        this.planTarifario = value;
    }

    /**
     * Gets the value of the listaOpcionalRequest property.
     * 
     * @return
     *     possible object is
     *     {@link ListaRequestOpcional }
     *     
     */
    public ListaRequestOpcional getListaOpcionalRequest() {
        return listaOpcionalRequest;
    }

    /**
     * Sets the value of the listaOpcionalRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListaRequestOpcional }
     *     
     */
    public void setListaOpcionalRequest(ListaRequestOpcional value) {
        this.listaOpcionalRequest = value;
    }

}
