package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.util.Date;

public class InteraccionPlusRequestBean {

	private String p_nro_interaccion;
	private String p_inter_1;
	private String p_inter_2;
	private String p_inter_3;
	private String p_inter_4;
	private String p_inter_5;
	private String p_inter_6;
	private String p_inter_7;
	private String p_inter_8;
	private String p_inter_9;
	private String p_inter_10;
	private String p_inter_11;
	private String p_inter_12;
	private String p_inter_13;
	private String p_inter_14;
	private String p_inter_15;
	private String p_inter_16;
	private String p_inter_17;
	private String p_inter_18;
	private String p_inter_19;
	private String p_inter_20;
	private String p_inter_21;
	private String p_inter_22;
	private String p_inter_23;
	private String p_inter_24;
	private String p_inter_25;
	private String p_inter_26;
	private String p_inter_27;
	private String p_inter_28;
	private String p_inter_29;
	private String p_inter_30;
	private String p_plus_inter2interact;
	private String p_adjustment_amount;
	private String p_adjustment_reason;
	private String p_address;
	private String p_amount_unit;
	private Date p_birthday;
	private String p_clarify_interaction;
	private String p_claro_ldn1;
	private String p_claro_ldn2;
	private String p_claro_ldn3;
	private String p_claro_ldn4;
	private String p_clarolocal1;
	private String p_clarolocal2;
	private String p_clarolocal3;
	private String p_clarolocal4;
	private String p_clarolocal5;
	private String p_clarolocal6;
	private String p_contact_phone;
	private String p_dni_legal_rep;
	private String p_document_number;
	private String p_email;
	private String p_first_name;
	private String p_fixed_number;
	private String p_flag_change_user;
	private String p_flag_legal_rep;
	private String p_flag_other;
	private String p_flag_titular;
	private String p_imei;
	private String p_last_name;
	private String p_lastname_rep;
	private String p_ldi_number;
	private String p_name_legal_rep;
	private String p_old_claro_ldn1;
	private String p_old_claro_ldn2;
	private String p_old_claro_ldn3;
	private String p_old_claro_ldn4;
	private String p_old_clarolocal1;
	private String p_old_clarolocal2;
	private String p_old_clarolocal3;
	private String p_old_clarolocal4;
	private String p_old_clarolocal5;
	private String p_old_clarolocal6;
	private String p_old_doc_number;
	private String p_old_first_name;
	private String p_old_fixed_phone;
	private String p_old_last_name;
	private String p_old_ldi_number;
	private String p_old_fixed_number;
	private String p_operation_type;
	private String p_other_doc_number;
	private String p_other_first_name;
	private String p_other_last_name;
	private String p_other_phone;
	private String p_phone_legal_rep;
	private String p_reference_phone;
	private String p_reason;
	private String p_model;
	private String p_lot_code;
	private String p_flag_registered;
	private String p_registration_reason;
	private String p_claro_number;
	private String p_month;
	private String p_ost_number;
	private String p_basket;
	private Date p_expire_date;
	//
	private String p_ADDRESS5;
	private String p_CHARGE_AMOUNT;
	private String p_CITY;
	private String p_CONTACT_SEX;
	private String p_DEPARTMENT;
	private String p_DISTRICT;
	private String p_EMAIL_CONFIRMATION;
	private String p_FAX;
	private String p_FLAG_CHARGE;
	private String p_MARITAL_STATUS;
	private String p_OCCUPATION;
	private String p_POSITION;
	private String p_REFERENCE_ADDRESS;
	private String p_TYPE_DOCUMENT;
	private String p_ZIPCODE;
	private String p_iccid;
	
	public String getP_nro_interaccion() {
		return p_nro_interaccion;
	}
	public void setP_nro_interaccion(String p_nro_interaccion) {
		this.p_nro_interaccion = p_nro_interaccion;
	}
	public String getP_inter_1() {
		return p_inter_1;
	}
	public void setP_inter_1(String p_inter_1) {
		this.p_inter_1 = p_inter_1;
	}
	public String getP_inter_2() {
		return p_inter_2;
	}
	public void setP_inter_2(String p_inter_2) {
		this.p_inter_2 = p_inter_2;
	}
	public String getP_inter_3() {
		return p_inter_3;
	}
	public void setP_inter_3(String p_inter_3) {
		this.p_inter_3 = p_inter_3;
	}
	public String getP_inter_4() {
		return p_inter_4;
	}
	public void setP_inter_4(String p_inter_4) {
		this.p_inter_4 = p_inter_4;
	}
	public String getP_inter_5() {
		return p_inter_5;
	}
	public void setP_inter_5(String p_inter_5) {
		this.p_inter_5 = p_inter_5;
	}
	public String getP_inter_6() {
		return p_inter_6;
	}
	public void setP_inter_6(String p_inter_6) {
		this.p_inter_6 = p_inter_6;
	}
	public String getP_inter_7() {
		return p_inter_7;
	}
	public void setP_inter_7(String p_inter_7) {
		this.p_inter_7 = p_inter_7;
	}
	public String getP_inter_8() {
		return p_inter_8;
	}
	public void setP_inter_8(String p_inter_8) {
		this.p_inter_8 = p_inter_8;
	}
	public String getP_inter_9() {
		return p_inter_9;
	}
	public void setP_inter_9(String p_inter_9) {
		this.p_inter_9 = p_inter_9;
	}
	public String getP_inter_10() {
		return p_inter_10;
	}
	public void setP_inter_10(String p_inter_10) {
		this.p_inter_10 = p_inter_10;
	}
	public String getP_inter_11() {
		return p_inter_11;
	}
	public void setP_inter_11(String p_inter_11) {
		this.p_inter_11 = p_inter_11;
	}
	public String getP_inter_12() {
		return p_inter_12;
	}
	public void setP_inter_12(String p_inter_12) {
		this.p_inter_12 = p_inter_12;
	}
	public String getP_inter_13() {
		return p_inter_13;
	}
	public void setP_inter_13(String p_inter_13) {
		this.p_inter_13 = p_inter_13;
	}
	public String getP_inter_14() {
		return p_inter_14;
	}
	public void setP_inter_14(String p_inter_14) {
		this.p_inter_14 = p_inter_14;
	}
	public String getP_inter_15() {
		return p_inter_15;
	}
	public void setP_inter_15(String p_inter_15) {
		this.p_inter_15 = p_inter_15;
	}
	public String getP_inter_16() {
		return p_inter_16;
	}
	public void setP_inter_16(String p_inter_16) {
		this.p_inter_16 = p_inter_16;
	}
	public String getP_inter_17() {
		return p_inter_17;
	}
	public void setP_inter_17(String p_inter_17) {
		this.p_inter_17 = p_inter_17;
	}
	public String getP_inter_18() {
		return p_inter_18;
	}
	public void setP_inter_18(String p_inter_18) {
		this.p_inter_18 = p_inter_18;
	}
	public String getP_inter_19() {
		return p_inter_19;
	}
	public void setP_inter_19(String p_inter_19) {
		this.p_inter_19 = p_inter_19;
	}
	public String getP_inter_20() {
		return p_inter_20;
	}
	public void setP_inter_20(String p_inter_20) {
		this.p_inter_20 = p_inter_20;
	}
	public String getP_inter_21() {
		return p_inter_21;
	}
	public void setP_inter_21(String p_inter_21) {
		this.p_inter_21 = p_inter_21;
	}
	public String getP_inter_22() {
		return p_inter_22;
	}
	public void setP_inter_22(String p_inter_22) {
		this.p_inter_22 = p_inter_22;
	}
	public String getP_inter_23() {
		return p_inter_23;
	}
	public void setP_inter_23(String p_inter_23) {
		this.p_inter_23 = p_inter_23;
	}
	public String getP_inter_24() {
		return p_inter_24;
	}
	public void setP_inter_24(String p_inter_24) {
		this.p_inter_24 = p_inter_24;
	}
	public String getP_inter_25() {
		return p_inter_25;
	}
	public void setP_inter_25(String p_inter_25) {
		this.p_inter_25 = p_inter_25;
	}
	public String getP_inter_26() {
		return p_inter_26;
	}
	public void setP_inter_26(String p_inter_26) {
		this.p_inter_26 = p_inter_26;
	}
	public String getP_inter_27() {
		return p_inter_27;
	}
	public void setP_inter_27(String p_inter_27) {
		this.p_inter_27 = p_inter_27;
	}
	public String getP_inter_28() {
		return p_inter_28;
	}
	public void setP_inter_28(String p_inter_28) {
		this.p_inter_28 = p_inter_28;
	}
	public String getP_inter_29() {
		return p_inter_29;
	}
	public void setP_inter_29(String p_inter_29) {
		this.p_inter_29 = p_inter_29;
	}
	public String getP_inter_30() {
		return p_inter_30;
	}
	public void setP_inter_30(String p_inter_30) {
		this.p_inter_30 = p_inter_30;
	}
	public String getP_plus_inter2interact() {
		return p_plus_inter2interact;
	}
	public void setP_plus_inter2interact(String p_plus_inter2interact) {
		this.p_plus_inter2interact = p_plus_inter2interact;
	}
	public String getP_adjustment_amount() {
		return p_adjustment_amount;
	}
	public void setP_adjustment_amount(String p_adjustment_amount) {
		this.p_adjustment_amount = p_adjustment_amount;
	}
	public String getP_adjustment_reason() {
		return p_adjustment_reason;
	}
	public void setP_adjustment_reason(String p_adjustment_reason) {
		this.p_adjustment_reason = p_adjustment_reason;
	}
	public String getP_address() {
		return p_address;
	}
	public void setP_address(String p_address) {
		this.p_address = p_address;
	}
	public String getP_amount_unit() {
		return p_amount_unit;
	}
	public void setP_amount_unit(String p_amount_unit) {
		this.p_amount_unit = p_amount_unit;
	}
	public Date getP_birthday() {
		return p_birthday;
	}
	public void setP_birthday(Date p_birthday) {
		this.p_birthday = p_birthday;
	}
	public String getP_clarify_interaction() {
		return p_clarify_interaction;
	}
	public void setP_clarify_interaction(String p_clarify_interaction) {
		this.p_clarify_interaction = p_clarify_interaction;
	}
	public String getP_claro_ldn1() {
		return p_claro_ldn1;
	}
	public void setP_claro_ldn1(String p_claro_ldn1) {
		this.p_claro_ldn1 = p_claro_ldn1;
	}
	public String getP_claro_ldn2() {
		return p_claro_ldn2;
	}
	public void setP_claro_ldn2(String p_claro_ldn2) {
		this.p_claro_ldn2 = p_claro_ldn2;
	}
	public String getP_claro_ldn3() {
		return p_claro_ldn3;
	}
	public void setP_claro_ldn3(String p_claro_ldn3) {
		this.p_claro_ldn3 = p_claro_ldn3;
	}
	public String getP_claro_ldn4() {
		return p_claro_ldn4;
	}
	public void setP_claro_ldn4(String p_claro_ldn4) {
		this.p_claro_ldn4 = p_claro_ldn4;
	}
	public String getP_clarolocal1() {
		return p_clarolocal1;
	}
	public void setP_clarolocal1(String p_clarolocal1) {
		this.p_clarolocal1 = p_clarolocal1;
	}
	public String getP_clarolocal2() {
		return p_clarolocal2;
	}
	public void setP_clarolocal2(String p_clarolocal2) {
		this.p_clarolocal2 = p_clarolocal2;
	}
	public String getP_clarolocal3() {
		return p_clarolocal3;
	}
	public void setP_clarolocal3(String p_clarolocal3) {
		this.p_clarolocal3 = p_clarolocal3;
	}
	public String getP_clarolocal4() {
		return p_clarolocal4;
	}
	public void setP_clarolocal4(String p_clarolocal4) {
		this.p_clarolocal4 = p_clarolocal4;
	}
	public String getP_clarolocal5() {
		return p_clarolocal5;
	}
	public void setP_clarolocal5(String p_clarolocal5) {
		this.p_clarolocal5 = p_clarolocal5;
	}
	public String getP_clarolocal6() {
		return p_clarolocal6;
	}
	public void setP_clarolocal6(String p_clarolocal6) {
		this.p_clarolocal6 = p_clarolocal6;
	}
	public String getP_contact_phone() {
		return p_contact_phone;
	}
	public void setP_contact_phone(String p_contact_phone) {
		this.p_contact_phone = p_contact_phone;
	}
	public String getP_dni_legal_rep() {
		return p_dni_legal_rep;
	}
	public void setP_dni_legal_rep(String p_dni_legal_rep) {
		this.p_dni_legal_rep = p_dni_legal_rep;
	}
	public String getP_document_number() {
		return p_document_number;
	}
	public void setP_document_number(String p_document_number) {
		this.p_document_number = p_document_number;
	}
	public String getP_email() {
		return p_email;
	}
	public void setP_email(String p_email) {
		this.p_email = p_email;
	}
	public String getP_first_name() {
		return p_first_name;
	}
	public void setP_first_name(String p_first_name) {
		this.p_first_name = p_first_name;
	}
	public String getP_fixed_number() {
		return p_fixed_number;
	}
	public void setP_fixed_number(String p_fixed_number) {
		this.p_fixed_number = p_fixed_number;
	}
	public String getP_flag_change_user() {
		return p_flag_change_user;
	}
	public void setP_flag_change_user(String p_flag_change_user) {
		this.p_flag_change_user = p_flag_change_user;
	}
	public String getP_flag_legal_rep() {
		return p_flag_legal_rep;
	}
	public void setP_flag_legal_rep(String p_flag_legal_rep) {
		this.p_flag_legal_rep = p_flag_legal_rep;
	}
	public String getP_flag_other() {
		return p_flag_other;
	}
	public void setP_flag_other(String p_flag_other) {
		this.p_flag_other = p_flag_other;
	}
	public String getP_flag_titular() {
		return p_flag_titular;
	}
	public void setP_flag_titular(String p_flag_titular) {
		this.p_flag_titular = p_flag_titular;
	}
	public String getP_imei() {
		return p_imei;
	}
	public void setP_imei(String p_imei) {
		this.p_imei = p_imei;
	}
	public String getP_last_name() {
		return p_last_name;
	}
	public void setP_last_name(String p_last_name) {
		this.p_last_name = p_last_name;
	}
	public String getP_lastname_rep() {
		return p_lastname_rep;
	}
	public void setP_lastname_rep(String p_lastname_rep) {
		this.p_lastname_rep = p_lastname_rep;
	}
	public String getP_ldi_number() {
		return p_ldi_number;
	}
	public void setP_ldi_number(String p_ldi_number) {
		this.p_ldi_number = p_ldi_number;
	}
	public String getP_name_legal_rep() {
		return p_name_legal_rep;
	}
	public void setP_name_legal_rep(String p_name_legal_rep) {
		this.p_name_legal_rep = p_name_legal_rep;
	}
	public String getP_old_claro_ldn1() {
		return p_old_claro_ldn1;
	}
	public void setP_old_claro_ldn1(String p_old_claro_ldn1) {
		this.p_old_claro_ldn1 = p_old_claro_ldn1;
	}
	public String getP_old_claro_ldn2() {
		return p_old_claro_ldn2;
	}
	public void setP_old_claro_ldn2(String p_old_claro_ldn2) {
		this.p_old_claro_ldn2 = p_old_claro_ldn2;
	}
	public String getP_old_claro_ldn3() {
		return p_old_claro_ldn3;
	}
	public void setP_old_claro_ldn3(String p_old_claro_ldn3) {
		this.p_old_claro_ldn3 = p_old_claro_ldn3;
	}
	public String getP_old_claro_ldn4() {
		return p_old_claro_ldn4;
	}
	public void setP_old_claro_ldn4(String p_old_claro_ldn4) {
		this.p_old_claro_ldn4 = p_old_claro_ldn4;
	}
	public String getP_old_clarolocal1() {
		return p_old_clarolocal1;
	}
	public void setP_old_clarolocal1(String p_old_clarolocal1) {
		this.p_old_clarolocal1 = p_old_clarolocal1;
	}
	public String getP_old_clarolocal2() {
		return p_old_clarolocal2;
	}
	public void setP_old_clarolocal2(String p_old_clarolocal2) {
		this.p_old_clarolocal2 = p_old_clarolocal2;
	}
	public String getP_old_clarolocal3() {
		return p_old_clarolocal3;
	}
	public void setP_old_clarolocal3(String p_old_clarolocal3) {
		this.p_old_clarolocal3 = p_old_clarolocal3;
	}
	public String getP_old_clarolocal4() {
		return p_old_clarolocal4;
	}
	public void setP_old_clarolocal4(String p_old_clarolocal4) {
		this.p_old_clarolocal4 = p_old_clarolocal4;
	}
	public String getP_old_clarolocal5() {
		return p_old_clarolocal5;
	}
	public void setP_old_clarolocal5(String p_old_clarolocal5) {
		this.p_old_clarolocal5 = p_old_clarolocal5;
	}
	public String getP_old_clarolocal6() {
		return p_old_clarolocal6;
	}
	public void setP_old_clarolocal6(String p_old_clarolocal6) {
		this.p_old_clarolocal6 = p_old_clarolocal6;
	}
	public String getP_old_doc_number() {
		return p_old_doc_number;
	}
	public void setP_old_doc_number(String p_old_doc_number) {
		this.p_old_doc_number = p_old_doc_number;
	}
	public String getP_old_first_name() {
		return p_old_first_name;
	}
	public void setP_old_first_name(String p_old_first_name) {
		this.p_old_first_name = p_old_first_name;
	}
	public String getP_old_fixed_phone() {
		return p_old_fixed_phone;
	}
	public void setP_old_fixed_phone(String p_old_fixed_phone) {
		this.p_old_fixed_phone = p_old_fixed_phone;
	}
	public String getP_old_last_name() {
		return p_old_last_name;
	}
	public void setP_old_last_name(String p_old_last_name) {
		this.p_old_last_name = p_old_last_name;
	}
	public String getP_old_ldi_number() {
		return p_old_ldi_number;
	}
	public void setP_old_ldi_number(String p_old_ldi_number) {
		this.p_old_ldi_number = p_old_ldi_number;
	}
	public String getP_old_fixed_number() {
		return p_old_fixed_number;
	}
	public void setP_old_fixed_number(String p_old_fixed_number) {
		this.p_old_fixed_number = p_old_fixed_number;
	}
	public String getP_operation_type() {
		return p_operation_type;
	}
	public void setP_operation_type(String p_operation_type) {
		this.p_operation_type = p_operation_type;
	}
	public String getP_other_doc_number() {
		return p_other_doc_number;
	}
	public void setP_other_doc_number(String p_other_doc_number) {
		this.p_other_doc_number = p_other_doc_number;
	}
	public String getP_other_first_name() {
		return p_other_first_name;
	}
	public void setP_other_first_name(String p_other_first_name) {
		this.p_other_first_name = p_other_first_name;
	}
	public String getP_other_last_name() {
		return p_other_last_name;
	}
	public void setP_other_last_name(String p_other_last_name) {
		this.p_other_last_name = p_other_last_name;
	}
	public String getP_other_phone() {
		return p_other_phone;
	}
	public void setP_other_phone(String p_other_phone) {
		this.p_other_phone = p_other_phone;
	}
	public String getP_phone_legal_rep() {
		return p_phone_legal_rep;
	}
	public void setP_phone_legal_rep(String p_phone_legal_rep) {
		this.p_phone_legal_rep = p_phone_legal_rep;
	}
	public String getP_reference_phone() {
		return p_reference_phone;
	}
	public void setP_reference_phone(String p_reference_phone) {
		this.p_reference_phone = p_reference_phone;
	}
	public String getP_reason() {
		return p_reason;
	}
	public void setP_reason(String p_reason) {
		this.p_reason = p_reason;
	}
	public String getP_model() {
		return p_model;
	}
	public void setP_model(String p_model) {
		this.p_model = p_model;
	}
	public String getP_lot_code() {
		return p_lot_code;
	}
	public void setP_lot_code(String p_lot_code) {
		this.p_lot_code = p_lot_code;
	}
	public String getP_flag_registered() {
		return p_flag_registered;
	}
	public void setP_flag_registered(String p_flag_registered) {
		this.p_flag_registered = p_flag_registered;
	}
	public String getP_registration_reason() {
		return p_registration_reason;
	}
	public void setP_registration_reason(String p_registration_reason) {
		this.p_registration_reason = p_registration_reason;
	}
	public String getP_claro_number() {
		return p_claro_number;
	}
	public void setP_claro_number(String p_claro_number) {
		this.p_claro_number = p_claro_number;
	}
	public String getP_month() {
		return p_month;
	}
	public void setP_month(String p_month) {
		this.p_month = p_month;
	}
	public String getP_ost_number() {
		return p_ost_number;
	}
	public void setP_ost_number(String p_ost_number) {
		this.p_ost_number = p_ost_number;
	}
	public String getP_basket() {
		return p_basket;
	}
	public void setP_basket(String p_basket) {
		this.p_basket = p_basket;
	}
	public Date getP_expire_date() {
		return p_expire_date;
	}
	public void setP_expire_date(Date p_expire_date) {
		this.p_expire_date = p_expire_date;
	}
	public String getP_ADDRESS5() {
		return p_ADDRESS5;
	}
	public void setP_ADDRESS5(String p_ADDRESS5) {
		this.p_ADDRESS5 = p_ADDRESS5;
	}
	public String getP_CHARGE_AMOUNT() {
		return p_CHARGE_AMOUNT;
	}
	public void setP_CHARGE_AMOUNT(String p_CHARGE_AMOUNT) {
		this.p_CHARGE_AMOUNT = p_CHARGE_AMOUNT;
	}
	public String getP_CITY() {
		return p_CITY;
	}
	public void setP_CITY(String p_CITY) {
		this.p_CITY = p_CITY;
	}
	public String getP_CONTACT_SEX() {
		return p_CONTACT_SEX;
	}
	public void setP_CONTACT_SEX(String p_CONTACT_SEX) {
		this.p_CONTACT_SEX = p_CONTACT_SEX;
	}
	public String getP_DEPARTMENT() {
		return p_DEPARTMENT;
	}
	public void setP_DEPARTMENT(String p_DEPARTMENT) {
		this.p_DEPARTMENT = p_DEPARTMENT;
	}
	public String getP_DISTRICT() {
		return p_DISTRICT;
	}
	public void setP_DISTRICT(String p_DISTRICT) {
		this.p_DISTRICT = p_DISTRICT;
	}
	public String getP_EMAIL_CONFIRMATION() {
		return p_EMAIL_CONFIRMATION;
	}
	public void setP_EMAIL_CONFIRMATION(String p_EMAIL_CONFIRMATION) {
		this.p_EMAIL_CONFIRMATION = p_EMAIL_CONFIRMATION;
	}
	public String getP_FAX() {
		return p_FAX;
	}
	public void setP_FAX(String p_FAX) {
		this.p_FAX = p_FAX;
	}
	public String getP_FLAG_CHARGE() {
		return p_FLAG_CHARGE;
	}
	public void setP_FLAG_CHARGE(String p_FLAG_CHARGE) {
		this.p_FLAG_CHARGE = p_FLAG_CHARGE;
	}
	public String getP_MARITAL_STATUS() {
		return p_MARITAL_STATUS;
	}
	public void setP_MARITAL_STATUS(String p_MARITAL_STATUS) {
		this.p_MARITAL_STATUS = p_MARITAL_STATUS;
	}
	public String getP_OCCUPATION() {
		return p_OCCUPATION;
	}
	public void setP_OCCUPATION(String p_OCCUPATION) {
		this.p_OCCUPATION = p_OCCUPATION;
	}
	public String getP_POSITION() {
		return p_POSITION;
	}
	public void setP_POSITION(String p_POSITION) {
		this.p_POSITION = p_POSITION;
	}
	public String getP_REFERENCE_ADDRESS() {
		return p_REFERENCE_ADDRESS;
	}
	public void setP_REFERENCE_ADDRESS(String p_REFERENCE_ADDRESS) {
		this.p_REFERENCE_ADDRESS = p_REFERENCE_ADDRESS;
	}
	public String getP_TYPE_DOCUMENT() {
		return p_TYPE_DOCUMENT;
	}
	public void setP_TYPE_DOCUMENT(String p_TYPE_DOCUMENT) {
		this.p_TYPE_DOCUMENT = p_TYPE_DOCUMENT;
	}
	public String getP_ZIPCODE() {
		return p_ZIPCODE;
	}
	public void setP_ZIPCODE(String p_ZIPCODE) {
		this.p_ZIPCODE = p_ZIPCODE;
	}
	public String getP_iccid() {
		return p_iccid;
	}
	public void setP_iccid(String p_iccid) {
		this.p_iccid = p_iccid;
	}
	
}
