package pe.com.claro.eai.ejecutatransferenciacontrato.dao;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import oracle.jdbc.OracleTypes;
import pe.com.claro.eai.ejecutatransferenciacontrato.dao.mapper.CursorCustomerSqlReturnType;
import pe.com.claro.eai.ejecutatransferenciacontrato.dao.mapper.CursorServproSqlReturnType;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.CursorCustomer;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.InteraccionPlusRequestBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.InteraccionRequestBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.InteraccionResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPObtenerCustomerBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.Constantes;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.PropertiesExterno;

@Repository
public class ClarifyDAOImpl implements ClarifyDAO {
	
	private final Logger LOGGER = Logger.getLogger( this.getClass().getName() );
	
	@Autowired
	@Qualifier(value = "clarifyDS")
	private DataSource clarifyDS;
	
	@Autowired
	private PropertiesExterno propExterno;
	
	private SimpleJdbcCall objJdbcCall;

	@Override
	public InteraccionResponseBean crearInteraccion(String mensajeLog, InteraccionRequestBean requestBean) throws Exception {
		String cadenaMensaje = mensajeLog + "[crearInteraccion]";
		LOGGER.info(cadenaMensaje + "[INICIO] - METODO: [crearInteraccion - DAO] ");

		JdbcTemplate objJdbcTemplate = null;
		InteraccionResponseBean responseBean = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;
		long tiempoInicio = System.currentTimeMillis();
		
		try {
			clarifyDS.setLoginTimeout(this.propExterno.dbClarifyTimeOutCONNECTION);
			
			LOGGER.info(cadenaMensaje + "DATA SOURCE (JNDI): [" + this.propExterno.dbClarifyJNDI + Constantes.CLOSECORCHETE);
			
			OWNER = this.propExterno.dbClarifyOWNER;
			PAQUETE = this.propExterno.pkgCLARIFYPCKINTERACTCLFY;
			PROCEDURE = this.propExterno.spCLARIFYSPCREATEINTERACT;
			
			LOGGER.info(cadenaMensaje + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO
					+ PROCEDURE + Constantes.CLOSECORCHETE);
			
			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue("p_contactobjid_1", requestBean.getP_contactobjid_1(), OracleTypes.NUMBER)
					.addValue("p_siteobjid_1", requestBean.getP_siteobjid_1(), OracleTypes.NUMBER)
					.addValue("p_account", requestBean.getP_account(), OracleTypes.VARCHAR)
					.addValue("p_phone", requestBean.getP_phone(), OracleTypes.VARCHAR)
					.addValue("p_tipo", requestBean.getP_tipo(), OracleTypes.VARCHAR)
					.addValue("p_clase", requestBean.getP_clase(), OracleTypes.VARCHAR)
					.addValue("p_subclase", requestBean.getP_subclase(), OracleTypes.VARCHAR)
					.addValue("p_metodo_contacto", requestBean.getP_metodo_contacto(), OracleTypes.VARCHAR)
					.addValue("p_tipo_inter", requestBean.getP_tipo_inter(), OracleTypes.VARCHAR)
					.addValue("p_agente", requestBean.getP_agente(), OracleTypes.VARCHAR)
					.addValue("p_usr_proceso", requestBean.getP_usr_proceso(), OracleTypes.VARCHAR)
					.addValue("p_hecho_en_uno", requestBean.getP_hecho_en_uno(), OracleTypes.NUMBER)
					.addValue("p_notas", requestBean.getP_notas(), OracleTypes.VARCHAR)
					.addValue("p_flag_caso", requestBean.getP_flag_caso(), OracleTypes.VARCHAR)
					.addValue("p_resultado", requestBean.getP_resultado(), OracleTypes.VARCHAR);
			
			LOGGER.info(cadenaMensaje + Constantes.PARAMETROIN 
					+ "p_contactobjid_1: [" + requestBean.getP_contactobjid_1() + Constantes.CLOSECORCHETE
					+ "p_siteobjid_1: [" + requestBean.getP_siteobjid_1() + Constantes.CLOSECORCHETE
					+ "p_account: [" + requestBean.getP_account() + Constantes.CLOSECORCHETE
					+ "p_phone: [" + requestBean.getP_phone() + Constantes.CLOSECORCHETE
					+ "p_tipo: [" + requestBean.getP_tipo() + Constantes.CLOSECORCHETE
					+ "p_clase: [" + requestBean.getP_clase() + Constantes.CLOSECORCHETE
					+ "p_subclase: [" + requestBean.getP_subclase() + Constantes.CLOSECORCHETE
					+ "p_metodo_contacto: [" + requestBean.getP_metodo_contacto() + Constantes.CLOSECORCHETE
					+ "p_tipo_inter: [" + requestBean.getP_tipo_inter() + Constantes.CLOSECORCHETE
					+ "p_agente: [" + requestBean.getP_agente() + Constantes.CLOSECORCHETE
					+ "p_usr_proceso: [" + requestBean.getP_usr_proceso() + Constantes.CLOSECORCHETE
					+ "p_hecho_en_uno: [" + requestBean.getP_hecho_en_uno() + Constantes.CLOSECORCHETE
					+ "p_notas: [" + requestBean.getP_notas() + Constantes.CLOSECORCHETE
					+ "p_flag_caso: [" + requestBean.getP_flag_caso() + Constantes.CLOSECORCHETE
					+ "p_resultado: [" + requestBean.getP_resultado() + Constantes.CLOSECORCHETE);
			
			this.objJdbcCall = new SimpleJdbcCall(this.clarifyDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbClarifyTimeOutEXECUTION);
			
			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(
							new SqlParameter("p_contactobjid_1", OracleTypes.NUMBER),
							new SqlParameter("p_siteobjid_1", OracleTypes.NUMBER),
							new SqlParameter("p_account", OracleTypes.VARCHAR),
							new SqlParameter("p_phone", OracleTypes.VARCHAR),
							new SqlParameter("p_tipo", OracleTypes.VARCHAR),
							new SqlParameter("p_clase", OracleTypes.VARCHAR),
							new SqlParameter("p_subclase", OracleTypes.VARCHAR),
							new SqlParameter("p_metodo_contacto", OracleTypes.VARCHAR),
							new SqlParameter("p_tipo_inter", OracleTypes.VARCHAR),
							new SqlParameter("p_agente", OracleTypes.VARCHAR),
							new SqlParameter("p_usr_proceso", OracleTypes.VARCHAR),
							new SqlParameter("p_hecho_en_uno", OracleTypes.NUMBER),
							new SqlParameter("p_notas", OracleTypes.VARCHAR),
							new SqlParameter("p_flag_caso", OracleTypes.VARCHAR),
							new SqlParameter("p_resultado", OracleTypes.VARCHAR),
							new SqlOutParameter("id_interaccion", OracleTypes.VARCHAR),
							new SqlOutParameter("flag_creacion", OracleTypes.VARCHAR),
							new SqlOutParameter("msg_text", OracleTypes.VARCHAR))
					.execute(objParametrosIN);
			
			String flagCreacion = objParametrosOUT.get("flag_creacion").toString();
			String msgText="";
			if(!flagCreacion.equals(Constantes.OK)){
				msgText = objParametrosOUT.get("msg_text").toString();
			}			
			LOGGER.info(cadenaMensaje + Constantes.PARAMETROOUT 
					+ "id_interaccion: " + Constantes.OPENCORCHETE + objParametrosOUT.get("id_interaccion") + Constantes.CLOSECORCHETE
					+ "flag_creacion: " + Constantes.OPENCORCHETE + flagCreacion + Constantes.CLOSECORCHETE
					+ "msg_text: " + Constantes.OPENCORCHETE + msgText + Constantes.CLOSECORCHETE);
			
			responseBean = new InteraccionResponseBean();
			responseBean.setCodeRes(this.propExterno.codigoEstandarExito);
			responseBean.setMsgRes(this.propExterno.mensajeEstandarExito);
			responseBean.setFlag_creacion(flagCreacion);
			responseBean.setMsg_text(msgText);
			
			if (objParametrosOUT.get("id_interaccion") == null || objParametrosOUT.get("id_interaccion").toString().equals(Constantes.VACIO)) {
				responseBean.setCodeRes(this.propExterno.codigoEstandarError);
				responseBean.setMsgRes(null);
			} else {
				responseBean.setId_interaccion(objParametrosOUT.get("id_interaccion").toString());
			}
		} catch (Exception e) {
			LOGGER.error(cadenaMensaje + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE, e);
			throw e;
		} finally {
			LOGGER.info(cadenaMensaje + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(cadenaMensaje + "[FIN] - METODO: [crearInteraccion - DAO] ");
		}
		
		return responseBean;
	}

	@Override
	public InteraccionResponseBean crearInteraccionPlus(String mensajeLog, InteraccionPlusRequestBean requestBean)
			throws Exception {
		String cadenaMensaje = mensajeLog + "[crearInteraccionPlus]";
		LOGGER.info(cadenaMensaje + "[INICIO] - METODO: [crearInteraccionPlus - DAO] ");
		
		JdbcTemplate objJdbcTemplate = null;
		InteraccionResponseBean responseBean = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;
		long tiempoInicio = System.currentTimeMillis();
		
		try {
			clarifyDS.setLoginTimeout(this.propExterno.dbClarifyTimeOutCONNECTION);
			
			LOGGER.info(cadenaMensaje + "DATA SOURCE (JNDI): [" + this.propExterno.dbClarifyJNDI + Constantes.CLOSECORCHETE);
			
			OWNER = this.propExterno.dbClarifyOWNER;
			PAQUETE = this.propExterno.pkgCLARIFYPCKINTERACTCLFY;
			PROCEDURE = this.propExterno.spCLARIFYSPCREATEPLUSINTER;
			
			LOGGER.info(cadenaMensaje + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO
					+ PROCEDURE + Constantes.CLOSECORCHETE);
			
			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue("p_nro_interaccion", requestBean.getP_nro_interaccion(), OracleTypes.VARCHAR)
					.addValue("p_inter_1", requestBean.getP_inter_1(), OracleTypes.VARCHAR)
					.addValue("p_inter_2", requestBean.getP_inter_2(), OracleTypes.VARCHAR)
					.addValue("p_inter_3", requestBean.getP_inter_3(), OracleTypes.VARCHAR)
					.addValue("p_inter_4", requestBean.getP_inter_4(), OracleTypes.VARCHAR)
					.addValue("p_inter_5", requestBean.getP_inter_5(), OracleTypes.VARCHAR)
					.addValue("p_inter_6", requestBean.getP_inter_6(), OracleTypes.VARCHAR)
					.addValue("p_inter_7", requestBean.getP_inter_7(), OracleTypes.VARCHAR)
					.addValue("p_inter_8", requestBean.getP_inter_8(), OracleTypes.VARCHAR)
					.addValue("p_inter_9", requestBean.getP_inter_9(), OracleTypes.VARCHAR)
					.addValue("p_inter_10", requestBean.getP_inter_10(), OracleTypes.VARCHAR)
					.addValue("p_inter_11", requestBean.getP_inter_11(), OracleTypes.VARCHAR)
					.addValue("p_inter_12", requestBean.getP_inter_12(), OracleTypes.VARCHAR)
					.addValue("p_inter_13", requestBean.getP_inter_13(), OracleTypes.VARCHAR)
					.addValue("p_inter_14", requestBean.getP_inter_14(), OracleTypes.VARCHAR)
					.addValue("p_inter_15", requestBean.getP_inter_15(), OracleTypes.VARCHAR)
					.addValue("p_inter_16", requestBean.getP_inter_16(), OracleTypes.VARCHAR)
					.addValue("p_inter_17", requestBean.getP_inter_17(), OracleTypes.VARCHAR)
					.addValue("p_inter_18", requestBean.getP_inter_18(), OracleTypes.VARCHAR)
					.addValue("p_inter_19", requestBean.getP_inter_19(), OracleTypes.VARCHAR)
					.addValue("p_inter_20", requestBean.getP_inter_20(), OracleTypes.VARCHAR)
					.addValue("p_inter_21", requestBean.getP_inter_21(), OracleTypes.VARCHAR)
					.addValue("p_inter_22", requestBean.getP_inter_22(), OracleTypes.VARCHAR)
					.addValue("p_inter_23", requestBean.getP_inter_23(), OracleTypes.VARCHAR)
					.addValue("p_inter_24", requestBean.getP_inter_24(), OracleTypes.VARCHAR)
					.addValue("p_inter_25", requestBean.getP_inter_25(), OracleTypes.VARCHAR)
					.addValue("p_inter_26", requestBean.getP_inter_26(), OracleTypes.VARCHAR)
					.addValue("p_inter_27", requestBean.getP_inter_27(), OracleTypes.VARCHAR)
					.addValue("p_inter_28", requestBean.getP_inter_28(), OracleTypes.VARCHAR)
					.addValue("p_inter_29", requestBean.getP_inter_29(), OracleTypes.VARCHAR)
					.addValue("p_inter_30", requestBean.getP_inter_30(), OracleTypes.CLOB)
					.addValue("p_plus_inter2interact", requestBean.getP_plus_inter2interact(), OracleTypes.VARCHAR)
					.addValue("p_adjustment_amount", requestBean.getP_adjustment_amount(), OracleTypes.VARCHAR)
					.addValue("p_adjustment_reason", requestBean.getP_adjustment_reason(), OracleTypes.VARCHAR)
					.addValue("p_address", requestBean.getP_address(), OracleTypes.VARCHAR)
					.addValue("p_amount_unit", requestBean.getP_amount_unit(), OracleTypes.VARCHAR)
					.addValue("p_birthday", requestBean.getP_birthday(), OracleTypes.DATE)
					.addValue("p_clarify_interaction", requestBean.getP_clarify_interaction(), OracleTypes.VARCHAR)
					.addValue("p_claro_ldn1", requestBean.getP_claro_ldn1(), OracleTypes.VARCHAR)
					.addValue("p_claro_ldn2", requestBean.getP_claro_ldn2(), OracleTypes.VARCHAR)
					.addValue("p_claro_ldn3", requestBean.getP_claro_ldn3(), OracleTypes.VARCHAR)
					.addValue("p_claro_ldn4", requestBean.getP_claro_ldn4(), OracleTypes.VARCHAR)
					.addValue("p_clarolocal1", requestBean.getP_clarolocal1(), OracleTypes.VARCHAR)
					.addValue("p_clarolocal2", requestBean.getP_clarolocal2(), OracleTypes.VARCHAR)
					.addValue("p_clarolocal3", requestBean.getP_clarolocal3(), OracleTypes.VARCHAR)
					.addValue("p_clarolocal4", requestBean.getP_clarolocal4(), OracleTypes.VARCHAR)
					.addValue("p_clarolocal5", requestBean.getP_clarolocal5(), OracleTypes.VARCHAR)
					.addValue("p_clarolocal6", requestBean.getP_clarolocal6(), OracleTypes.VARCHAR)
					.addValue("p_contact_phone", requestBean.getP_contact_phone(), OracleTypes.VARCHAR)
					.addValue("p_dni_legal_rep", requestBean.getP_dni_legal_rep(), OracleTypes.VARCHAR)
					.addValue("p_document_number", requestBean.getP_document_number(), OracleTypes.VARCHAR)
					.addValue("p_email", requestBean.getP_email(), OracleTypes.VARCHAR)
					.addValue("p_first_name", requestBean.getP_first_name(), OracleTypes.VARCHAR)
					.addValue("p_fixed_number", requestBean.getP_fixed_number(), OracleTypes.VARCHAR)
					.addValue("p_flag_change_user", requestBean.getP_flag_change_user(), OracleTypes.VARCHAR)
					.addValue("p_flag_legal_rep", requestBean.getP_flag_legal_rep(), OracleTypes.VARCHAR)
					.addValue("p_flag_other", requestBean.getP_flag_other(), OracleTypes.VARCHAR)
					.addValue("p_flag_titular", requestBean.getP_flag_titular(), OracleTypes.VARCHAR)
					.addValue("p_imei", requestBean.getP_imei(), OracleTypes.VARCHAR)
					.addValue("p_last_name", requestBean.getP_last_name(), OracleTypes.VARCHAR)
					.addValue("p_lastname_rep", requestBean.getP_lastname_rep(), OracleTypes.VARCHAR)
					.addValue("p_ldi_number", requestBean.getP_ldi_number(), OracleTypes.VARCHAR)
					.addValue("p_name_legal_rep", requestBean.getP_name_legal_rep(), OracleTypes.VARCHAR)
					.addValue("p_old_claro_ldn1", requestBean.getP_old_claro_ldn1(), OracleTypes.VARCHAR)
					.addValue("p_old_claro_ldn2", requestBean.getP_old_claro_ldn2(), OracleTypes.VARCHAR)
					.addValue("p_old_claro_ldn3", requestBean.getP_old_claro_ldn3(), OracleTypes.VARCHAR)
					.addValue("p_old_claro_ldn4", requestBean.getP_old_claro_ldn4(), OracleTypes.VARCHAR)
					.addValue("p_old_clarolocal1", requestBean.getP_old_clarolocal1(), OracleTypes.VARCHAR)
					.addValue("p_old_clarolocal2", requestBean.getP_old_clarolocal2(), OracleTypes.VARCHAR)
					.addValue("p_old_clarolocal3", requestBean.getP_old_clarolocal3(), OracleTypes.VARCHAR)
					.addValue("p_old_clarolocal4", requestBean.getP_old_clarolocal4(), OracleTypes.VARCHAR)
					.addValue("p_old_clarolocal5", requestBean.getP_old_clarolocal5(), OracleTypes.VARCHAR)
					.addValue("p_old_clarolocal6", requestBean.getP_old_clarolocal6(), OracleTypes.VARCHAR)
					.addValue("p_old_doc_number", requestBean.getP_old_doc_number(), OracleTypes.VARCHAR)
					.addValue("p_old_first_name", requestBean.getP_old_first_name(), OracleTypes.VARCHAR)
					.addValue("p_old_fixed_phone", requestBean.getP_old_fixed_phone(), OracleTypes.VARCHAR)
					.addValue("p_old_last_name", requestBean.getP_old_last_name(), OracleTypes.VARCHAR)
					.addValue("p_old_ldi_number", requestBean.getP_old_ldi_number(), OracleTypes.VARCHAR)
					.addValue("p_old_fixed_number", requestBean.getP_old_fixed_number(), OracleTypes.VARCHAR)
					.addValue("p_operation_type", requestBean.getP_operation_type(), OracleTypes.VARCHAR)
					.addValue("p_other_doc_number", requestBean.getP_other_doc_number(), OracleTypes.VARCHAR)
					.addValue("p_other_first_name", requestBean.getP_other_first_name(), OracleTypes.VARCHAR)
					.addValue("p_other_last_name", requestBean.getP_other_last_name(), OracleTypes.VARCHAR)
					.addValue("p_other_phone", requestBean.getP_other_phone(), OracleTypes.VARCHAR)
					.addValue("p_phone_legal_rep", requestBean.getP_phone_legal_rep(), OracleTypes.VARCHAR)
					.addValue("p_reference_phone", requestBean.getP_reference_phone(), OracleTypes.VARCHAR)
					.addValue("p_reason", requestBean.getP_reason(), OracleTypes.VARCHAR)
					.addValue("p_model", requestBean.getP_model(), OracleTypes.VARCHAR)
					.addValue("p_lot_code", requestBean.getP_lot_code(), OracleTypes.VARCHAR)
					.addValue("p_flag_registered", requestBean.getP_flag_registered(), OracleTypes.VARCHAR)
					.addValue("p_registration_reason", requestBean.getP_registration_reason(), OracleTypes.VARCHAR)
					.addValue("p_claro_number", requestBean.getP_claro_number(), OracleTypes.VARCHAR)
					.addValue("p_month", requestBean.getP_month(), OracleTypes.VARCHAR)
					.addValue("p_ost_number", requestBean.getP_ost_number(), OracleTypes.VARCHAR)
					.addValue("p_basket", requestBean.getP_basket(), OracleTypes.VARCHAR)
					.addValue("p_expire_date", requestBean.getP_expire_date(), OracleTypes.DATE)
					.addValue("p_ADDRESS5", requestBean.getP_ADDRESS5(), OracleTypes.VARCHAR)
					.addValue("p_CHARGE_AMOUNT", requestBean.getP_CHARGE_AMOUNT(), OracleTypes.VARCHAR)
					.addValue("p_CITY", requestBean.getP_CITY(), OracleTypes.VARCHAR)
					.addValue("p_CONTACT_SEX", requestBean.getP_CONTACT_SEX(), OracleTypes.VARCHAR)
					.addValue("p_DEPARTMENT", requestBean.getP_DEPARTMENT(), OracleTypes.VARCHAR)
					.addValue("p_DISTRICT", requestBean.getP_DISTRICT(), OracleTypes.VARCHAR)
					.addValue("p_EMAIL_CONFIRMATION", requestBean.getP_EMAIL_CONFIRMATION(), OracleTypes.VARCHAR)
					.addValue("p_FAX", requestBean.getP_FAX(), OracleTypes.VARCHAR)
					.addValue("p_FLAG_CHARGE", requestBean.getP_FLAG_CHARGE(), OracleTypes.VARCHAR)
					.addValue("p_MARITAL_STATUS", requestBean.getP_MARITAL_STATUS(), OracleTypes.VARCHAR)
					.addValue("p_OCCUPATION", requestBean.getP_OCCUPATION(), OracleTypes.VARCHAR)
					.addValue("p_POSITION", requestBean.getP_POSITION(), OracleTypes.VARCHAR)
					.addValue("p_REFERENCE_ADDRESS", requestBean.getP_REFERENCE_ADDRESS(), OracleTypes.VARCHAR)
					.addValue("p_TYPE_DOCUMENT", requestBean.getP_TYPE_DOCUMENT(), OracleTypes.VARCHAR)
					.addValue("p_ZIPCODE", requestBean.getP_ZIPCODE(), OracleTypes.VARCHAR)
					.addValue("p_iccid", requestBean.getP_iccid(), OracleTypes.VARCHAR);
			
			LOGGER.info(cadenaMensaje + Constantes.PARAMETROIN 
					+ "p_nro_interaccion: [" + requestBean.getP_nro_interaccion() + Constantes.CLOSECORCHETE
					+ "p_inter_1: [" + requestBean.getP_inter_1() + Constantes.CLOSECORCHETE
					+ "p_inter_2: [" + requestBean.getP_inter_2() + Constantes.CLOSECORCHETE
					+ "p_inter_3: [" + requestBean.getP_inter_3() + Constantes.CLOSECORCHETE
					+ "p_inter_4: [" + requestBean.getP_inter_4() + Constantes.CLOSECORCHETE
					+ "p_inter_5: [" + requestBean.getP_inter_5() + Constantes.CLOSECORCHETE
					+ "p_inter_6: [" + requestBean.getP_inter_6() + Constantes.CLOSECORCHETE
					+ "p_inter_7: [" + requestBean.getP_inter_7() + Constantes.CLOSECORCHETE
					+ "p_inter_8: [" + requestBean.getP_inter_8() + Constantes.CLOSECORCHETE
					+ "p_inter_9: [" + requestBean.getP_inter_9() + Constantes.CLOSECORCHETE
					+ "p_inter_10: [" + requestBean.getP_inter_10() + Constantes.CLOSECORCHETE
					+ "p_inter_11: [" + requestBean.getP_inter_11() + Constantes.CLOSECORCHETE
					+ "p_inter_12: [" + requestBean.getP_inter_12() + Constantes.CLOSECORCHETE
					+ "p_inter_13: [" + requestBean.getP_inter_13() + Constantes.CLOSECORCHETE
					+ "p_inter_14: [" + requestBean.getP_inter_14() + Constantes.CLOSECORCHETE
					+ "p_inter_15: [" + requestBean.getP_inter_15() + Constantes.CLOSECORCHETE
					+ "p_inter_16: [" + requestBean.getP_inter_16() + Constantes.CLOSECORCHETE
					+ "p_inter_17: [" + requestBean.getP_inter_17() + Constantes.CLOSECORCHETE
					+ "p_inter_18: [" + requestBean.getP_inter_18() + Constantes.CLOSECORCHETE
					+ "p_inter_19: [" + requestBean.getP_inter_19() + Constantes.CLOSECORCHETE
					+ "p_inter_20: [" + requestBean.getP_inter_20() + Constantes.CLOSECORCHETE
					+ "p_inter_21: [" + requestBean.getP_inter_21() + Constantes.CLOSECORCHETE
					+ "p_inter_22: [" + requestBean.getP_inter_22() + Constantes.CLOSECORCHETE
					+ "p_inter_23: [" + requestBean.getP_inter_23() + Constantes.CLOSECORCHETE
					+ "p_inter_24: [" + requestBean.getP_inter_24() + Constantes.CLOSECORCHETE
					+ "p_inter_25: [" + requestBean.getP_inter_25() + Constantes.CLOSECORCHETE
					+ "p_inter_26: [" + requestBean.getP_inter_26() + Constantes.CLOSECORCHETE
					+ "p_inter_27: [" + requestBean.getP_inter_27() + Constantes.CLOSECORCHETE
					+ "p_inter_28: [" + requestBean.getP_inter_28() + Constantes.CLOSECORCHETE
					+ "p_inter_29: [" + requestBean.getP_inter_29() + Constantes.CLOSECORCHETE
					+ "p_inter_30: [" + requestBean.getP_inter_30() + Constantes.CLOSECORCHETE
					+ "p_plus_inter2interact: [" + requestBean.getP_plus_inter2interact() + Constantes.CLOSECORCHETE
					+ "p_adjustment_amount: [" + requestBean.getP_adjustment_amount() + Constantes.CLOSECORCHETE
					+ "p_adjustment_reason: [" + requestBean.getP_adjustment_reason() + Constantes.CLOSECORCHETE
					+ "p_address: [" + requestBean.getP_address() + Constantes.CLOSECORCHETE
					+ "p_amount_unit: [" + requestBean.getP_amount_unit() + Constantes.CLOSECORCHETE
					+ "p_birthday: [" + requestBean.getP_birthday() + Constantes.CLOSECORCHETE
					+ "p_clarify_interaction: [" + requestBean.getP_clarify_interaction() + Constantes.CLOSECORCHETE
					+ "p_claro_ldn1: [" + requestBean.getP_claro_ldn1() + Constantes.CLOSECORCHETE
					+ "p_claro_ldn2: [" + requestBean.getP_claro_ldn2() + Constantes.CLOSECORCHETE
					+ "p_claro_ldn3: [" + requestBean.getP_claro_ldn3() + Constantes.CLOSECORCHETE
					+ "p_claro_ldn4: [" + requestBean.getP_claro_ldn4() + Constantes.CLOSECORCHETE
					+ "p_clarolocal1: [" + requestBean.getP_clarolocal1() + Constantes.CLOSECORCHETE
					+ "p_clarolocal2: [" + requestBean.getP_clarolocal2() + Constantes.CLOSECORCHETE
					+ "p_clarolocal3: [" + requestBean.getP_clarolocal3() + Constantes.CLOSECORCHETE
					+ "p_clarolocal4: [" + requestBean.getP_clarolocal4() + Constantes.CLOSECORCHETE
					+ "p_clarolocal5: [" + requestBean.getP_clarolocal5() + Constantes.CLOSECORCHETE
					+ "p_clarolocal6: [" + requestBean.getP_clarolocal6() + Constantes.CLOSECORCHETE
					+ "p_contact_phone: [" + requestBean.getP_contact_phone() + Constantes.CLOSECORCHETE
					+ "p_dni_legal_rep: [" + requestBean.getP_dni_legal_rep() + Constantes.CLOSECORCHETE
					+ "p_document_number: [" + requestBean.getP_document_number() + Constantes.CLOSECORCHETE
					+ "p_email: [" + requestBean.getP_email() + Constantes.CLOSECORCHETE
					+ "p_first_name: [" + requestBean.getP_first_name() + Constantes.CLOSECORCHETE
					+ "p_fixed_number: [" + requestBean.getP_fixed_number() + Constantes.CLOSECORCHETE
					+ "p_flag_change_user: [" + requestBean.getP_flag_change_user() + Constantes.CLOSECORCHETE
					+ "p_flag_legal_rep: [" + requestBean.getP_flag_legal_rep() + Constantes.CLOSECORCHETE
					+ "p_flag_other: [" + requestBean.getP_flag_other() + Constantes.CLOSECORCHETE
					+ "p_flag_titular: [" + requestBean.getP_flag_titular() + Constantes.CLOSECORCHETE
					+ "p_imei: [" + requestBean.getP_imei() + Constantes.CLOSECORCHETE
					+ "p_last_name: [" + requestBean.getP_last_name() + Constantes.CLOSECORCHETE
					+ "p_lastname_rep: [" + requestBean.getP_lastname_rep() + Constantes.CLOSECORCHETE
					+ "p_ldi_number: [" + requestBean.getP_ldi_number() + Constantes.CLOSECORCHETE
					+ "p_name_legal_rep: [" + requestBean.getP_name_legal_rep() + Constantes.CLOSECORCHETE
					+ "p_old_claro_ldn1: [" + requestBean.getP_old_claro_ldn1() + Constantes.CLOSECORCHETE
					+ "p_old_claro_ldn2: [" + requestBean.getP_old_claro_ldn2() + Constantes.CLOSECORCHETE
					+ "p_old_claro_ldn3: [" + requestBean.getP_old_claro_ldn3() + Constantes.CLOSECORCHETE
					+ "p_old_claro_ldn4: [" + requestBean.getP_old_claro_ldn4() + Constantes.CLOSECORCHETE
					+ "p_old_clarolocal1: [" + requestBean.getP_old_clarolocal1() + Constantes.CLOSECORCHETE
					+ "p_old_clarolocal2: [" + requestBean.getP_old_clarolocal2() + Constantes.CLOSECORCHETE
					+ "p_old_clarolocal3: [" + requestBean.getP_old_clarolocal3() + Constantes.CLOSECORCHETE
					+ "p_old_clarolocal4: [" + requestBean.getP_old_clarolocal4() + Constantes.CLOSECORCHETE
					+ "p_old_clarolocal5: [" + requestBean.getP_old_clarolocal5() + Constantes.CLOSECORCHETE
					+ "p_old_clarolocal6: [" + requestBean.getP_old_clarolocal6() + Constantes.CLOSECORCHETE
					+ "p_old_doc_number: [" + requestBean.getP_old_doc_number() + Constantes.CLOSECORCHETE
					+ "p_old_first_name: [" + requestBean.getP_old_first_name() + Constantes.CLOSECORCHETE
					+ "p_old_fixed_phone: [" + requestBean.getP_old_fixed_phone() + Constantes.CLOSECORCHETE
					+ "p_old_last_name: [" + requestBean.getP_old_last_name() + Constantes.CLOSECORCHETE
					+ "p_old_ldi_number: [" + requestBean.getP_old_ldi_number() + Constantes.CLOSECORCHETE
					+ "p_old_fixed_number: [" + requestBean.getP_old_fixed_number() + Constantes.CLOSECORCHETE
					+ "p_operation_type: [" + requestBean.getP_operation_type() + Constantes.CLOSECORCHETE
					+ "p_other_doc_number: [" + requestBean.getP_other_doc_number() + Constantes.CLOSECORCHETE
					+ "p_other_first_name: [" + requestBean.getP_other_first_name() + Constantes.CLOSECORCHETE
					+ "p_other_last_name: [" + requestBean.getP_other_last_name() + Constantes.CLOSECORCHETE
					+ "p_other_phone: [" + requestBean.getP_other_phone() + Constantes.CLOSECORCHETE
					+ "p_phone_legal_rep: [" + requestBean.getP_phone_legal_rep() + Constantes.CLOSECORCHETE
					+ "p_reference_phone: [" + requestBean.getP_reference_phone() + Constantes.CLOSECORCHETE
					+ "p_reason: [" + requestBean.getP_reason() + Constantes.CLOSECORCHETE
					+ "p_model: [" + requestBean.getP_model() + Constantes.CLOSECORCHETE
					+ "p_lot_code: [" + requestBean.getP_lot_code() + Constantes.CLOSECORCHETE
					+ "p_flag_registered: [" + requestBean.getP_flag_registered() + Constantes.CLOSECORCHETE
					+ "p_registration_reason: [" + requestBean.getP_registration_reason() + Constantes.CLOSECORCHETE
					+ "p_claro_number: [" + requestBean.getP_claro_number() + Constantes.CLOSECORCHETE
					+ "p_month: [" + requestBean.getP_month() + Constantes.CLOSECORCHETE
					+ "p_ost_number: [" + requestBean.getP_ost_number() + Constantes.CLOSECORCHETE
					+ "p_basket: [" + requestBean.getP_basket() + Constantes.CLOSECORCHETE
					+ "p_expire_date: [" + requestBean.getP_expire_date() + Constantes.CLOSECORCHETE
					+ "p_ADDRESS5: [" + requestBean.getP_ADDRESS5() + Constantes.CLOSECORCHETE
					+ "p_CHARGE_AMOUNT: [" + requestBean.getP_CHARGE_AMOUNT() + Constantes.CLOSECORCHETE
					+ "p_CITY: [" + requestBean.getP_CITY() + Constantes.CLOSECORCHETE
					+ "p_CONTACT_SEX: [" + requestBean.getP_CONTACT_SEX() + Constantes.CLOSECORCHETE
					+ "p_DEPARTMENT: [" + requestBean.getP_DEPARTMENT() + Constantes.CLOSECORCHETE
					+ "p_DISTRICT: [" + requestBean.getP_DISTRICT() + Constantes.CLOSECORCHETE
					+ "p_EMAIL_CONFIRMATION: [" + requestBean.getP_EMAIL_CONFIRMATION() + Constantes.CLOSECORCHETE
					+ "p_FAX: [" + requestBean.getP_FAX() + Constantes.CLOSECORCHETE
					+ "p_FLAG_CHARGE: [" + requestBean.getP_FLAG_CHARGE() + Constantes.CLOSECORCHETE
					+ "p_MARITAL_STATUS: [" + requestBean.getP_MARITAL_STATUS() + Constantes.CLOSECORCHETE
					+ "p_OCCUPATION: [" + requestBean.getP_OCCUPATION() + Constantes.CLOSECORCHETE
					+ "p_POSITION: [" + requestBean.getP_POSITION() + Constantes.CLOSECORCHETE
					+ "p_REFERENCE_ADDRESS: [" + requestBean.getP_REFERENCE_ADDRESS() + Constantes.CLOSECORCHETE
					+ "p_TYPE_DOCUMENT: [" + requestBean.getP_TYPE_DOCUMENT() + Constantes.CLOSECORCHETE
					+ "p_ZIPCODE: [" + requestBean.getP_ZIPCODE() + Constantes.CLOSECORCHETE
					+ "p_iccid: [" + requestBean.getP_iccid() + Constantes.CLOSECORCHETE);
			
			this.objJdbcCall = new SimpleJdbcCall(this.clarifyDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbClarifyTimeOutEXECUTION);
			
			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(
							new SqlParameter("p_nro_interaccion", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_1", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_2", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_3", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_4", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_5", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_6", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_7", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_8", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_9", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_10", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_11", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_12", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_13", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_14", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_15", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_16", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_17", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_18", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_19", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_20", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_21", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_22", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_23", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_24", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_25", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_26", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_27", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_28", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_29", OracleTypes.VARCHAR),
							new SqlParameter("p_inter_30", OracleTypes.VARCHAR),
							new SqlParameter("p_plus_inter2interact", OracleTypes.VARCHAR),
							new SqlParameter("p_adjustment_amount", OracleTypes.VARCHAR),
							new SqlParameter("p_adjustment_reason", OracleTypes.VARCHAR),
							new SqlParameter("p_address", OracleTypes.VARCHAR),
							new SqlParameter("p_amount_unit", OracleTypes.VARCHAR),
							new SqlParameter("p_birthday", OracleTypes.DATE),
							new SqlParameter("p_clarify_interaction", OracleTypes.VARCHAR),
							new SqlParameter("p_claro_ldn1", OracleTypes.VARCHAR),
							new SqlParameter("p_claro_ldn2", OracleTypes.VARCHAR),
							new SqlParameter("p_claro_ldn3", OracleTypes.VARCHAR),
							new SqlParameter("p_claro_ldn4", OracleTypes.VARCHAR),
							new SqlParameter("p_clarolocal1", OracleTypes.VARCHAR),
							new SqlParameter("p_clarolocal2", OracleTypes.VARCHAR),
							new SqlParameter("p_clarolocal3", OracleTypes.VARCHAR),
							new SqlParameter("p_clarolocal4", OracleTypes.VARCHAR),
							new SqlParameter("p_clarolocal5", OracleTypes.VARCHAR),
							new SqlParameter("p_clarolocal6", OracleTypes.VARCHAR),
							new SqlParameter("p_contact_phone", OracleTypes.VARCHAR),
							new SqlParameter("p_dni_legal_rep", OracleTypes.VARCHAR),
							new SqlParameter("p_document_number", OracleTypes.VARCHAR),
							new SqlParameter("p_email", OracleTypes.VARCHAR),
							new SqlParameter("p_first_name", OracleTypes.VARCHAR),
							new SqlParameter("p_fixed_number", OracleTypes.VARCHAR),
							new SqlParameter("p_flag_change_user", OracleTypes.VARCHAR),
							new SqlParameter("p_flag_legal_rep", OracleTypes.VARCHAR),
							new SqlParameter("p_flag_other", OracleTypes.VARCHAR),
							new SqlParameter("p_flag_titular", OracleTypes.VARCHAR),
							new SqlParameter("p_imei", OracleTypes.VARCHAR),
							new SqlParameter("p_last_name", OracleTypes.VARCHAR),
							new SqlParameter("p_lastname_rep", OracleTypes.VARCHAR),
							new SqlParameter("p_ldi_number", OracleTypes.VARCHAR),
							new SqlParameter("p_name_legal_rep", OracleTypes.VARCHAR),
							new SqlParameter("p_old_claro_ldn1", OracleTypes.VARCHAR),
							new SqlParameter("p_old_claro_ldn2", OracleTypes.VARCHAR),
							new SqlParameter("p_old_claro_ldn3", OracleTypes.VARCHAR),
							new SqlParameter("p_old_claro_ldn4", OracleTypes.VARCHAR),
							new SqlParameter("p_old_clarolocal1", OracleTypes.VARCHAR),
							new SqlParameter("p_old_clarolocal2", OracleTypes.VARCHAR),
							new SqlParameter("p_old_clarolocal3", OracleTypes.VARCHAR),
							new SqlParameter("p_old_clarolocal4", OracleTypes.VARCHAR),
							new SqlParameter("p_old_clarolocal5", OracleTypes.VARCHAR),
							new SqlParameter("p_old_clarolocal6", OracleTypes.VARCHAR),
							new SqlParameter("p_old_doc_number", OracleTypes.VARCHAR),
							new SqlParameter("p_old_first_name", OracleTypes.VARCHAR),
							new SqlParameter("p_old_fixed_phone", OracleTypes.VARCHAR),
							new SqlParameter("p_old_last_name", OracleTypes.VARCHAR),
							new SqlParameter("p_old_ldi_number", OracleTypes.VARCHAR),
							new SqlParameter("p_old_fixed_number", OracleTypes.VARCHAR),
							new SqlParameter("p_operation_type", OracleTypes.VARCHAR),
							new SqlParameter("p_other_doc_number", OracleTypes.VARCHAR),
							new SqlParameter("p_other_first_name", OracleTypes.VARCHAR),
							new SqlParameter("p_other_last_name", OracleTypes.VARCHAR),
							new SqlParameter("p_other_phone", OracleTypes.VARCHAR),
							new SqlParameter("p_phone_legal_rep", OracleTypes.VARCHAR),
							new SqlParameter("p_reference_phone", OracleTypes.VARCHAR),
							new SqlParameter("p_reason", OracleTypes.VARCHAR),
							new SqlParameter("p_model", OracleTypes.VARCHAR),
							new SqlParameter("p_lot_code", OracleTypes.VARCHAR),
							new SqlParameter("p_flag_registered", OracleTypes.VARCHAR),
							new SqlParameter("p_registration_reason", OracleTypes.VARCHAR),
							new SqlParameter("p_claro_number", OracleTypes.VARCHAR),
							new SqlParameter("p_month", OracleTypes.VARCHAR),
							new SqlParameter("p_ost_number", OracleTypes.VARCHAR),
							new SqlParameter("p_basket", OracleTypes.VARCHAR),
							new SqlParameter("p_expire_date", OracleTypes.DATE),
							new SqlParameter("p_ADDRESS5", OracleTypes.VARCHAR),
							new SqlParameter("p_CHARGE_AMOUNT", OracleTypes.VARCHAR),
							new SqlParameter("p_CITY", OracleTypes.VARCHAR),
							new SqlParameter("p_CONTACT_SEX", OracleTypes.VARCHAR),
							new SqlParameter("p_DEPARTMENT", OracleTypes.VARCHAR),
							new SqlParameter("p_DISTRICT", OracleTypes.VARCHAR),
							new SqlParameter("p_EMAIL_CONFIRMATION", OracleTypes.VARCHAR),
							new SqlParameter("p_FAX", OracleTypes.VARCHAR),
							new SqlParameter("p_FLAG_CHARGE", OracleTypes.VARCHAR),
							new SqlParameter("p_MARITAL_STATUS", OracleTypes.VARCHAR),
							new SqlParameter("p_OCCUPATION", OracleTypes.VARCHAR),
							new SqlParameter("p_POSITION", OracleTypes.VARCHAR),
							new SqlParameter("p_REFERENCE_ADDRESS", OracleTypes.VARCHAR),
							new SqlParameter("p_TYPE_DOCUMENT", OracleTypes.VARCHAR),
							new SqlParameter("p_ZIPCODE", OracleTypes.VARCHAR),
							new SqlParameter("p_iccid", OracleTypes.VARCHAR),
							new SqlOutParameter("id_interaccion", OracleTypes.VARCHAR),
							new SqlOutParameter("flag_creacion", OracleTypes.VARCHAR),
							new SqlOutParameter("msg_text", OracleTypes.VARCHAR))
					.execute(objParametrosIN);
			
			String flagCreacion = objParametrosOUT.get("flag_creacion").toString();
			String msgText = "";
			if(!flagCreacion.equals(Constantes.OK)){
			msgText = objParametrosOUT.get("msg_text").toString();
			}
			
			LOGGER.info(cadenaMensaje + Constantes.PARAMETROOUT 
					+ "id_interaccion: " + Constantes.OPENCORCHETE + objParametrosOUT.get("id_interaccion") + Constantes.CLOSECORCHETE
					+ "flag_creacion: " + Constantes.OPENCORCHETE + flagCreacion + Constantes.CLOSECORCHETE
					+ "msg_text: " + Constantes.OPENCORCHETE + msgText + Constantes.CLOSECORCHETE);
			
			responseBean = new InteraccionResponseBean();
			responseBean.setCodeRes(this.propExterno.codigoEstandarExito);
			responseBean.setMsgRes(this.propExterno.mensajeEstandarExito);
			responseBean.setFlag_creacion(flagCreacion);
			responseBean.setMsg_text(msgText);
			
			if (objParametrosOUT.get("id_interaccion") == null || objParametrosOUT.get("id_interaccion").toString().equals(Constantes.VACIO)) {
				responseBean.setCodeRes(this.propExterno.codigoEstandarError);
				responseBean.setMsgRes(null);
			} else {
				responseBean.setId_interaccion(objParametrosOUT.get("id_interaccion").toString());
			}
		} catch (Exception e) {
			LOGGER.error(cadenaMensaje + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE, e);
			throw e;
		} finally {
			LOGGER.info(cadenaMensaje + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(cadenaMensaje + "[FIN] - METODO: [crearInteraccionPlus - DAO] ");
		}
		return responseBean;
	}

	@Override
	public SPObtenerCustomerBean obtenerCustomer(String mensajeLog,String phone, int flag) throws Exception {
		String cadenaMensaje = mensajeLog + "[obtenerCustomer]";
		LOGGER.info(cadenaMensaje + "[INICIO] - METODO: [obtenerCustomer - DAO] ");

		JdbcTemplate objJdbcTemplate = null;
		SPObtenerCustomerBean responseBean = null;
		String OWNER = null;
		String PAQUETE = null;
		String PROCEDURE = null;
		long tiempoInicio = System.currentTimeMillis();
		
		try {
			clarifyDS.setLoginTimeout(this.propExterno.dbClarifyTimeOutCONNECTION);
			
			LOGGER.info(cadenaMensaje + "DATA SOURCE (JNDI): [" + this.propExterno.dbClarifyJNDI + Constantes.CLOSECORCHETE);
			
			OWNER = this.propExterno.dbClarifyOWNER;
			PAQUETE = this.propExterno.pkgCLARIFYCUSTOMER;
			PROCEDURE = this.propExterno.spCLARIFYSPCUSTOMER;
			
			LOGGER.info(cadenaMensaje + "PROCEDURE: [" + OWNER + Constantes.PUNTO + PAQUETE + Constantes.PUNTO
					+ PROCEDURE + Constantes.CLOSECORCHETE);
			
			SqlParameterSource objParametrosIN = new MapSqlParameterSource()
					.addValue("p_phone", phone, OracleTypes.VARCHAR)
					.addValue("p_account", Constantes.VACIO, OracleTypes.VARCHAR)
					.addValue("p_contactobjid_1", Constantes.VACIO, OracleTypes.VARCHAR)//NUMBER
					.addValue("p_flag_reg", flag, OracleTypes.NUMBER);
			
			LOGGER.info(cadenaMensaje + Constantes.PARAMETROIN 
					+ "p_phone: [" + phone + Constantes.CLOSECORCHETE
					+ "p_account: [" + Constantes.VACIO + Constantes.CLOSECORCHETE
					+ "p_contactobjid_1: [" + Constantes.VACIO + Constantes.CLOSECORCHETE
					+ "p_flag_reg: [" + flag + Constantes.CLOSECORCHETE);
			
			this.objJdbcCall = new SimpleJdbcCall(this.clarifyDS);
			objJdbcTemplate = this.objJdbcCall.getJdbcTemplate();
			objJdbcTemplate.setQueryTimeout(this.propExterno.dbClarifyTimeOutEXECUTION);
			
			Map<String, Object> objParametrosOUT = this.objJdbcCall.withoutProcedureColumnMetaDataAccess()
					.withSchemaName(OWNER).withCatalogName(PAQUETE).withProcedureName(PROCEDURE)
					.declareParameters(
							new SqlParameter("p_phone", OracleTypes.VARCHAR),
							new SqlParameter("p_account", OracleTypes.VARCHAR),
							new SqlParameter("p_contactobjid_1", OracleTypes.VARCHAR),
							new SqlParameter("p_flag_reg", OracleTypes.NUMBER),
							new SqlOutParameter("p_flag_consulta", OracleTypes.VARCHAR),
							new SqlOutParameter("p_msg_text", OracleTypes.VARCHAR),
							new SqlOutParameter("customer", oracle.jdbc.OracleTypes.CURSOR, null, new CursorCustomerSqlReturnType()))
					.execute(objParametrosIN);
			
			String flagConsulta = objParametrosOUT.get("p_flag_consulta").toString();
			String msgText ="";
			if(!flagConsulta.equals(Constantes.OK)){
				msgText = objParametrosOUT.get("p_msg_text").toString();
			}
			LOGGER.info(cadenaMensaje + Constantes.PARAMETROOUT 
					+ "p_flag_consulta: " + Constantes.OPENCORCHETE + flagConsulta + Constantes.CLOSECORCHETE
					+ "p_msg_text: " + Constantes.OPENCORCHETE + msgText + Constantes.CLOSECORCHETE);
			
			responseBean = new SPObtenerCustomerBean();
			responseBean.setFlag_Consulta(objParametrosOUT.get("p_flag_consulta").toString());
			LOGGER.info(cadenaMensaje + "p_flag_consulta: [" + responseBean.getFlag_Consulta() + Constantes.CLOSECORCHETE);
			if(!flagConsulta.equals(Constantes.OK)){
			responseBean.setMentext(objParametrosOUT.get("p_msg_text").toString());
			}else{responseBean.setMentext("");}
			
			LOGGER.info(cadenaMensaje + "p_msg_text: [" + responseBean.getMentext() + Constantes.CLOSECORCHETE);
			responseBean.setListaCustomer((List<CursorCustomer>) objParametrosOUT.get("customer"));
			if (responseBean.getListaCustomer() != null)
				LOGGER.info(responseBean + "customer [TAMANO]: [" + responseBean.getListaCustomer().size()
						+ Constantes.CLOSECORCHETE);
		} catch (Exception e) {
			LOGGER.error(cadenaMensaje + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE, e);
			throw e;
		} finally {
			LOGGER.info(cadenaMensaje + "Tiempo TOTAL Proceso: [" + (System.currentTimeMillis() - tiempoInicio)
					+ " milisegundos ]");
			LOGGER.info(cadenaMensaje + "[FIN] - METODO: [obtenerCustomer - DAO] ");
		}
		
		return responseBean;
	}

}
