package pe.com.claro.eai.ejecutatransferenciacontrato.service.recursos;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.com.claro.eai.ejecutatransferenciacontrato.dao.TimEaiDao;

import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.proxy.EnvioMailService;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.Constantes;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.EaiUtil;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.PropertiesExterno;
import pe.com.claro.eai.messagingservices.mail.enviomail.EnvioMail_Type;

@Service
public class RealizaTransaccionImpl implements RealizaTransaccion {
	private final static  Logger LOGGER = Logger.getLogger(RealizaTransaccionImpl.class);
	private String codError, msjError, nombreSP, nombreBD, nombreWS,nombreEJB;
    
	@Autowired
    private TimEaiDao timeaiDAO;
	
	@Autowired
	private EnvioMailService envioMailService;
	   
    @Autowired
    private PropertiesExterno propExterno;
    
	@Override
	public void registrarExito(String msgTxId, String p_id_proceso, String p_co_id, String p_msisdn, String p_estado,
			String p_codigo_error, String p_mensaje_error,String p_escenario) {
        String cadenaMsg = msgTxId + "[registrarEXITO]";

        LOGGER.info(cadenaMsg + "================entrando a registrar exito======");
        LOGGER.info(cadenaMsg + "3.3 Inicio Metodo registro Exito");
        ResponseBean resRegistrarEstadoMigracion = null;
        ResponseBean resActualizarTransMasiva = null;
        try {
        	LOGGER.info(cadenaMsg + " 3.3.1 Registrar estado Migracion Postpago");
        	resRegistrarEstadoMigracion = timeaiDAO.registrarEstadoMigracion(cadenaMsg, p_id_proceso, p_co_id, p_msisdn, p_estado, p_codigo_error, p_mensaje_error);
            if (!this.propExterno.codigoEstandarExito.equalsIgnoreCase(resRegistrarEstadoMigracion.getCodeRes())){
            	LOGGER.info(cadenaMsg + "Error al Registrar de estado de migracion exitoso");
            	return;
            }
            LOGGER.info(cadenaMsg + "3.3.2. Actualizar Transaccion Masiva");
            resActualizarTransMasiva = timeaiDAO.actualizarTransMasiva(msgTxId, p_msisdn, propExterno.EstadoTransMasivaExito,p_escenario);
        if (this.propExterno.codigoEstandarExito.equalsIgnoreCase(resActualizarTransMasiva.getCodeRes()))
            LOGGER.info(cadenaMsg + "se actualizo transaccion masiva correctamente");
        else
            LOGGER.info(cadenaMsg + "Error al actualizar transaccion masiva");
        } catch (Exception e) {
            LOGGER.error(cadenaMsg + "ERROR: "+e.getMessage());
        }finally{
        LOGGER.info(cadenaMsg + "================fin de registrar exito======");
        }
	}

	@Override
	public void registrarError(String msgTxId, String p_id_proceso, String p_co_id, String p_msisdn, String p_estado,
			String p_codigo_error, String p_mensaje_error, String p_servi_cod, Date p_servd_fecha_prog,
			String p_servv_id_batch, Date p_servd_fecha_ejec, String p_servc_estado, String p_servv_cod_error,
			String p_servv_men_error, String p_codigo_errorActMig, String p_codigo_mensajeActMig, String ipApp,
			String usuApp,String p_escenario) {
		
        String cadenaMsg = msgTxId + "[registrarError]";
        LOGGER.info(cadenaMsg + "3.4 Inicio Metodo Registrar Error");
        LOGGER.info(cadenaMsg + "================entrando a registrar error======");
        ResponseBean respBeanRegistrarEstadoMig = null;
        ResponseBean respBeanActualizarProg = null;
        ResponseBean respBeanActualizarEstadoMig = null;
        ResponseBean respBeanActualizaTransaccionMasiva = null;
        ResponseBean outEnviaCorreo = null;

        String men_error = EaiUtil.limpiarComillas(p_servv_men_error);

        try {
            try {
            	LOGGER.info(cadenaMsg + " 3.4.1 Registrar estado Migracion Postpago");
                respBeanRegistrarEstadoMig =
                        timeaiDAO.registrarEstadoMigracion(cadenaMsg, p_id_proceso, p_co_id, p_msisdn, p_estado, p_codigo_error, (p_mensaje_error.length() >
                                                                                                                                       Constantes.INT100 ?
                                                                                                                                       p_mensaje_error.substring(Constantes.INT0,
                                                                                                                                                                 Constantes.INT99) :
                                                                                                                                       p_mensaje_error));

            } catch (Exception e) {
                LOGGER.error(cadenaMsg + "[ERROR] AL REGISTRAR ESTADO MIGRACION: "+e.getMessage());
            }
            if (!this.propExterno.codigoEstandarExito.equals(respBeanRegistrarEstadoMig.getCodeRes())) {
                LOGGER.info(cadenaMsg + respBeanRegistrarEstadoMig.getMsgRes());
            } else {
                LOGGER.info(cadenaMsg + "ResgistrarEstadoMigracion exitoso");
            }
            try {

                String fechaProgString = EaiUtil.formatDateObject(Constantes.FORMATDATE, p_servd_fecha_prog);
                String fechaEjecString = EaiUtil.formatDateObject(Constantes.FORMATDATE, p_servd_fecha_ejec);
                LOGGER.info(cadenaMsg + "3.4.2. Actualizar Estado Programacion");
                respBeanActualizarProg =
                        timeaiDAO.actualizarProgramacion(cadenaMsg, p_servi_cod, p_msisdn, fechaProgString, p_servv_id_batch, fechaEjecString, p_servc_estado,
                                                              (men_error.length() > Constantes.INT100 ? men_error.substring(Constantes.INT0, Constantes.INT99) : men_error),
                            p_servv_cod_error);

            } catch (Exception e) {
                LOGGER.error(cadenaMsg + "[ERROR] AL ACTUALIZAR PROGRAMACION, se continua con el proceso: "+e.getMessage());
            }
            if (!this.propExterno.codigoEstandarExito.equals(respBeanActualizarProg.getCodeRes())) {
                LOGGER.info(cadenaMsg + respBeanActualizarProg.getMsgRes());
            } else {
                LOGGER.info(cadenaMsg + "ActualizarProgramacion exitoso");
            }
            try {
            	LOGGER.info(cadenaMsg + "3.4.3. Actualizar Estado Migracion");
                respBeanActualizarEstadoMig = timeaiDAO.actualizarEstadoMigracion(cadenaMsg, p_id_proceso, p_co_id, p_msisdn, p_estado, p_codigo_errorActMig,
                            (p_codigo_mensajeActMig.length() > Constantes.INT100 ? p_codigo_mensajeActMig.substring(Constantes.INT0, Constantes.INT99) :
                             p_codigo_mensajeActMig));
            } catch (Exception e) {
                LOGGER.error(cadenaMsg + "[ERROR] AL ACTUALIZAR ESTADO MIGRACION, se continua con el proceso: "+e.getMessage());
            }
            if (!this.propExterno.codigoEstandarExito.equals(respBeanActualizarEstadoMig.getCodeRes())) {
                LOGGER.info(cadenaMsg + respBeanActualizarEstadoMig.getMsgRes());
            } else {
                LOGGER.info(cadenaMsg + "ActualizaEstadoMigracion exitoso");
            }
            
            LOGGER.info(msgTxId + " 3.4.4. Actualizar Transaccion Masiva ");
            respBeanActualizaTransaccionMasiva=timeaiDAO.actualizarTransMasiva(msgTxId, p_msisdn, propExterno.EstadoTransMasivaError,p_escenario);
            if(respBeanActualizaTransaccionMasiva.getCodeRes().equals(propExterno.codigoEstandarExito)){
            	LOGGER.info(msgTxId + " Se actualizo correctamente la transaccion masiva ");
            }else{
            	LOGGER.info(cadenaMsg + respBeanActualizarEstadoMig.getMsgRes());
            }
            
            try {

                LOGGER.info(cadenaMsg + " 3.4.5. Envio email");
                LOGGER.info(cadenaMsg + " [INICIANDO] - METODO:[envioMailService.envioEmail]");
                EnvioMail_Type outEnvioMailType = new EnvioMail_Type();
                outEnvioMailType.setTxId(p_id_proceso);
                outEnvioMailType.setIpApp(ipApp);
                outEnvioMailType.setUsrApp(usuApp);
                outEnvioMailType.setRemitente(this.propExterno.envioEmailRemitente);
                outEnvioMailType.setDestinatario(this.propExterno.envioEmailDestinatario);
                outEnvioMailType.setAsunto(this.propExterno.envioEmailAsunto);
                outEnvioMailType.setMensaje(this.propExterno.envioEmailMensajeERROR + p_id_proceso + "|" + p_msisdn + "|" + p_co_id + "|" + p_codigo_mensajeActMig);
                outEnvioMailType.setFlagHtml(Integer.parseInt(propExterno.envioEmailFlagHTML));

                outEnviaCorreo = envioMailService.enviarEmail(cadenaMsg, outEnvioMailType);

            } catch (Exception e) {
                LOGGER.error(cadenaMsg + "ERROR AL ENVIAR LA NOTIFICACION: "+e.getMessage());

                if (this.msjError == null) {
                    this.msjError = "ERROR EN EL PROCESO";
                } else {
                    this.msjError = e.getMessage();
                }
            }
            if (!this.propExterno.codigoEstandarExito.equals(outEnviaCorreo.getCodeRes())) {
                LOGGER.info(cadenaMsg + "ERROR AL ENVIAR LA NOTIFICACION ...");
                LOGGER.info(cadenaMsg + "[ CODIGO RESPUESTA ]..." + outEnviaCorreo.getCodeRes());
                LOGGER.info(cadenaMsg + "[ MENSAJE RESPUESTA ]..." + outEnviaCorreo.getMsgRes());
            } else {
                LOGGER.info(cadenaMsg + "ENVIO DE NOTIFICACION EXITOSO...");
                LOGGER.info(cadenaMsg + "[ CODIGO RESPUESTA ]..." + outEnviaCorreo.getCodeRes());
                LOGGER.info(cadenaMsg + "[ MENSAJE RESPUESTA ]..." + outEnviaCorreo.getMsgRes());
            }
            LOGGER.info(cadenaMsg + " [FINALIZANDO ] - METODO:[envioMailService.envioEmail]");

        } catch (Exception e) {
            LOGGER.error(cadenaMsg + "ERROR [Exception]: "+e.getMessage());
            LOGGER.error(cadenaMsg + "ERROR Generico Al RegistrarError ....., se continua con el proceso");
        }
        LOGGER.info(cadenaMsg + "================fin a registrar error======");
		
	}

}
