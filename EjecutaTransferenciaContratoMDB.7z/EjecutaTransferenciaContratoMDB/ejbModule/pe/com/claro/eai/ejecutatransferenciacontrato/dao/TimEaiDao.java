package pe.com.claro.eai.ejecutatransferenciacontrato.dao;

import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ActualizarDetServicioMasivoRequest;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.BuscarReProcesoBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPActualizarDetServicioMasivo;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPBuscarDetServicioMasivo;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPBuscarProgramacionesResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.SPRegistraMigracionResponseBean;

public interface TimEaiDao {
	
	public SPBuscarProgramacionesResponseBean buscarProgramaciones(String msgTxId, String idProceso, String serviCod,
			String fechaProg,int limite, String servcEstado);
	public BuscarReProcesoBean buscarReProceso(String msgTxId,String serviCod,String servFechaEjec);
	public ResponseBean registrarEstadoMigracion(String msgTxId, String p_id_proceso, String p_co_id, String p_msisdn, String p_estado, String p_codigo_error, String p_mensaje_error) throws Exception;
	public ResponseBean actualizarTransMasiva(String msgTxId,String numCliente, String idEstado,String flagOperacion) throws Exception;
	public ResponseBean actualizarProgramacion(String msgTxId,
              String p_servi_cod,
              String p_servv_msisdn,
              String p_servd_fecha_prog,
              String p_servv_id_batch,
              String p_servd_fecha_ejec,
              String p_servc_estado,
              String p_servv_men_error,
              String p_servv_cod_error) throws Exception;
	 public ResponseBean actualizarEstadoMigracion(String msgTxId, String p_id_proceso,
              String p_co_id,
              String p_msisdn,
              String p_estado,
              String p_codigo_error,
              String p_mensaje_error) throws Exception ;
	 
	  public SPRegistraMigracionResponseBean registrarMigracion(String msgTxId,
              String idProceso,
              String coId,
              String msisdn,
              String fechaProgramacion,
              String escenarioMigracion,
              String estado) throws Exception;
	  
	  public SPBuscarDetServicioMasivo buscarDetServicioMasivo(String msgTxId,String fecha) throws Exception;
	 
	  public SPActualizarDetServicioMasivo actualizarDetServicioMasivo(String msgTxId,ActualizarDetServicioMasivoRequest request) throws Exception;
}
