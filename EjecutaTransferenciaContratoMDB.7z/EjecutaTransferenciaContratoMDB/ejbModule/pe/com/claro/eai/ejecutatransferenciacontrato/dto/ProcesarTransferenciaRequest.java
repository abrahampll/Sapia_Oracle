package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.io.Serializable;

import javax.xml.datatype.XMLGregorianCalendar;

public class ProcesarTransferenciaRequest implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String idTransaccion;
	protected XMLGregorianCalendar fechaEjecucion;

	public XMLGregorianCalendar getFechaEjecucion() {
		return fechaEjecucion;
	}

	public void setFechaEjecucion(XMLGregorianCalendar fechaEjecucion) {
		this.fechaEjecucion = fechaEjecucion;
	}

	public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}
	
}
