package pe.com.claro.eai.ejecutatransferenciacontrato.proxy;

import pe.com.claro.eai.ebs.ejecutatransferenciacontrato.ws.types.RealizarTransaccionRequest;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ResponseBean;

public interface EjecutarTransferenciaContrato {
	public ResponseBean realizarTransferencia(String mensajeTransaccion,RealizarTransaccionRequest request); 
}
