package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

public class InteraccionResponseBean extends ResponseBean {

	private String id_interaccion;
	private String flag_creacion;
	private String msg_text;
	
	public String getId_interaccion() {
		return id_interaccion;
	}
	public void setId_interaccion(String id_interaccion) {
		this.id_interaccion = id_interaccion;
	}
	public String getFlag_creacion() {
		return flag_creacion;
	}
	public void setFlag_creacion(String flag_creacion) {
		this.flag_creacion = flag_creacion;
	}
	public String getMsg_text() {
		return msg_text;
	}
	public void setMsg_text(String msg_text) {
		this.msg_text = msg_text;
	}
	
}
