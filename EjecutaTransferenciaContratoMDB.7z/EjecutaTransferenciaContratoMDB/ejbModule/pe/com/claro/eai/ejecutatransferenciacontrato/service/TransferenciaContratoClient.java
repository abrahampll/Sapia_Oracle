package pe.com.claro.eai.ejecutatransferenciacontrato.service;

import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.dto.TransfereciaContratoMessageBean;

public interface TransferenciaContratoClient {

	ResponseBean procesarTransferencia(String men, TransfereciaContratoMessageBean request) throws Exception;
	
	void relanzarTransferencia(String men, TransfereciaContratoMessageBean request) throws Exception;
	
}
