package pe.com.claro.eai.ejecutatransferenciacontrato.proxy;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.com.claro.eai.ejecutatransferenciacontrato.dto.ResponseBean;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.Constantes;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.EaiUtil;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.PropertiesExterno;
import pe.com.claro.eai.messagingservices.mail.enviomail.EnvioMail;
import pe.com.claro.eai.messagingservices.mail.enviomail.EnvioMailResponse;
import pe.com.claro.eai.messagingservices.mail.enviomail.EnvioMail_Type;

@Service
public class EnvioMailServiceImpl implements EnvioMailService {
    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
    @Autowired
    private EnvioMail ebsEnvioMailPortType;
    @Autowired
    private PropertiesExterno propExterno;
    @Autowired
    private EaiUtil eaiUtil;
    
	@Override
	public ResponseBean enviarEmail(String mensajeTransaccion, EnvioMail_Type inParameters) throws Exception {
        String cadenaMensaje = mensajeTransaccion + "[envioEmail]";
        LOGGER.info(cadenaMensaje + "[INICIO] - METODO: [envioEmail] ");

        ResponseBean outResponseBean = new ResponseBean();

        try {

            EnvioMail_Type inEnvioMail = inParameters;
            EnvioMailResponse outEnvioMail = null;

            LOGGER.info(cadenaMensaje + "CONSUMIENDO WS: [" + this.propExterno.wsUrlENVIOEMAIL + Constantes.CLOSECORCHETE);
            LOGGER.info(cadenaMensaje + "XML [REQUEST]: " + this.eaiUtil.jaxBToXmlText(inEnvioMail));
            outEnvioMail = this.ebsEnvioMailPortType.envioMail(inEnvioMail);


            LOGGER.info(cadenaMensaje + "XML [RESPONSE]: " + this.eaiUtil.jaxBToXmlText(outEnvioMail));
            String codigoRespuesta = outEnvioMail.getAudit().getErrorCode();
            String mensajeRespuesta = outEnvioMail.getAudit().getErrorMsg();

            LOGGER.info(cadenaMensaje + "codigoRespuesta : [" + codigoRespuesta + Constantes.CLOSECORCHETE);
            LOGGER.info(cadenaMensaje + "mensajeRespuesta : [" + mensajeRespuesta + Constantes.CLOSECORCHETE);

            outResponseBean.setCodeRes(codigoRespuesta);
            outResponseBean.setMsgRes(mensajeRespuesta);
            outResponseBean.setObjetoRespuesta(outEnvioMail);


        } catch (Exception e) {
            LOGGER.error(cadenaMensaje + "ERROR: [Exception] - [" + e.getMessage() + Constantes.CLOSECORCHETE);
            throw e;
        } finally {

            LOGGER.info(cadenaMensaje + "codigoRespuesta : [" + outResponseBean.getCodeRes() + Constantes.CLOSECORCHETE);
            LOGGER.info(cadenaMensaje + "mensajeRespuesta : [" + outResponseBean.getMsgRes() + Constantes.CLOSECORCHETE);
            LOGGER.info(cadenaMensaje + "[FIN] - METODO: [envioEmail] ");
        }
        return outResponseBean;
	}

}
