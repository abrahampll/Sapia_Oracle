package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.math.BigDecimal;

public class ObtenerCargoFijoResponse {
	private static final long serialVersionUID = 1L;
	private BigDecimal numFact;
	private BigDecimal cargoFijoActual;
	private BigDecimal cargoFijoMen;
	
	public BigDecimal getNumFact() {
		return numFact;
	}
	public void setNumFact(BigDecimal nroFactura) {
		this.numFact = nroFactura;
	}
	public BigDecimal getCargoFijoActual() {
		return cargoFijoActual;
	}
	public void setCargoFijoActual(BigDecimal cargoFijoActual) {
		this.cargoFijoActual = cargoFijoActual;
	}
	public BigDecimal getCargoFijoMen() {
		return cargoFijoMen;
	}
	public void setCargoFijoMen(BigDecimal cargoFijoMen) {
		this.cargoFijoMen = cargoFijoMen;
	}
}
