package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.io.Serializable;

public class SPRegistraMigracionResponseBean implements Serializable{
	
    @SuppressWarnings("compatibility:-6080589084594671817")
    private static final long serialVersionUID = 1L;
    private String resultado;
    private String mensaje;

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public String getResultado() {
        return resultado;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getMensaje() {
        return mensaje;
    }
    
}
