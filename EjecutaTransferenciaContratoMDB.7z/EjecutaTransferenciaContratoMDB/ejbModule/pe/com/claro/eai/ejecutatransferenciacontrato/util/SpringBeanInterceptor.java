package pe.com.claro.eai.ejecutatransferenciacontrato.util;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.access.BeanFactoryLocator;
import pe.com.claro.eai.ejecutatransferenciacontrato.util.ContextSingletonBeanFactoryLocator;
import org.springframework.ejb.interceptor.SpringBeanAutowiringInterceptor;

public class SpringBeanInterceptor extends SpringBeanAutowiringInterceptor {

	private final Logger logger = Logger.getLogger(this.getClass().getName());

	@Override
	protected BeanFactoryLocator getBeanFactoryLocator(Object target) {
		logger.info("************** OBTENIENDO: [getBeanFactoryLocator] **************");
		BeanFactoryLocator objFactoryLocator = ContextSingletonBeanFactoryLocator.getInstance();
		logger.info("objFactoryLocator 'RETURN': [" + objFactoryLocator + "]");
		return objFactoryLocator;
	}

}
