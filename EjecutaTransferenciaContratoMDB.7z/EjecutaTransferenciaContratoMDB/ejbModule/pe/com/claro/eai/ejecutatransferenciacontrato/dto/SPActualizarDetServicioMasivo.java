package pe.com.claro.eai.ejecutatransferenciacontrato.dto;

import java.io.Serializable;

public class SPActualizarDetServicioMasivo implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	private String codRespuesta;
	private String msjRespuesta;
	
	public String getCodRespuesta() {
		return codRespuesta;
	}
	public void setCodRespuesta(String codRespuesta) {
		this.codRespuesta = codRespuesta;
	}
	public String getMsjRespuesta() {
		return msjRespuesta;
	}
	public void setMsjRespuesta(String msjRespuesta) {
		this.msjRespuesta = msjRespuesta;
	}
	
	
}
